@echo off
title BIC ERP — Dev Mode
color 0B
echo.
echo  Starting BIC ERP in development mode...
echo  (Both React dev server + Electron window will open)
echo.
echo  Press Ctrl+C to stop.
echo.
set ELECTRON_START_URL=http://localhost:3000
call npm start

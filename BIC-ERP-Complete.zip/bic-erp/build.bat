@echo off
title BIC ERP — Windows Build Script
color 0A

echo.
echo  ██████╗ ██╗ ██████╗    ███████╗██████╗ ██████╗ 
echo  ██╔══██╗██║██╔════╝    ██╔════╝██╔══██╗██╔══██╗
echo  ██████╔╝██║██║         █████╗  ██████╔╝██████╔╝
echo  ██╔══██╗██║██║         ██╔══╝  ██╔══██╗██╔═══╝ 
echo  ██████╔╝██║╚██████╗    ███████╗██║  ██║██║     
echo  ╚═════╝ ╚═╝ ╚═════╝    ╚══════╝╚═╝  ╚═╝╚═╝     
echo.
echo  BIC Industries Private Limited — Windows Installer Builder
echo  ============================================================
echo.

:: ── STEP 1: Check Node.js ────────────────────────────────────────────────────
echo [1/7] Checking Node.js installation...
node --version >nul 2>&1
if %errorlevel% neq 0 (
    color 0C
    echo.
    echo  ERROR: Node.js is not installed!
    echo.
    echo  Please install Node.js v18 or higher from:
    echo  https://nodejs.org/en/download
    echo.
    echo  After installing, close this window and run build.bat again.
    echo.
    pause
    exit /b 1
)
for /f "tokens=*" %%i in ('node --version') do set NODE_VER=%%i
echo  Node.js %NODE_VER% found ✓
echo.

:: ── STEP 2: Check npm ────────────────────────────────────────────────────────
echo [2/7] Checking npm...
npm --version >nul 2>&1
if %errorlevel% neq 0 (
    color 0C
    echo  ERROR: npm not found. Please reinstall Node.js.
    pause
    exit /b 1
)
for /f "tokens=*" %%i in ('npm --version') do set NPM_VER=%%i
echo  npm v%NPM_VER% found ✓
echo.

:: ── STEP 3: Install dependencies ─────────────────────────────────────────────
echo [3/7] Installing dependencies (this may take 5-10 minutes)...
echo  Please wait...
echo.
call npm install
if %errorlevel% neq 0 (
    color 0C
    echo.
    echo  ERROR: npm install failed.
    echo  Try running as Administrator or check your internet connection.
    pause
    exit /b 1
)
echo.
echo  Dependencies installed ✓
echo.

:: ── STEP 4: Rebuild native modules for Electron ──────────────────────────────
echo [4/7] Rebuilding SQLite for Electron (native module)...
echo  This is required for the database to work inside Electron.
echo.
call npx electron-rebuild -f -w better-sqlite3
if %errorlevel% neq 0 (
    color 0E
    echo.
    echo  WARNING: electron-rebuild had issues.
    echo  Trying alternative method...
    echo.
    call npm run postinstall
)
echo.
echo  Native modules rebuilt ✓
echo.

:: ── STEP 5: Build React frontend ─────────────────────────────────────────────
echo [5/7] Building React frontend (optimised production build)...
echo  This may take 2-3 minutes...
echo.
call npm run react-build
if %errorlevel% neq 0 (
    color 0C
    echo.
    echo  ERROR: React build failed.
    echo  Check the error messages above for details.
    pause
    exit /b 1
)
echo.
echo  React build complete ✓
echo.

:: ── STEP 6: Build Windows installer ──────────────────────────────────────────
echo [6/7] Building Windows installer (.exe)...
echo  Creating NSIS installer package...
echo.
call npx electron-builder build --win --x64
if %errorlevel% neq 0 (
    color 0C
    echo.
    echo  ERROR: Electron Builder failed.
    echo  Check the error messages above.
    pause
    exit /b 1
)
echo.
echo  Windows installer built ✓
echo.

:: ── STEP 7: Done ─────────────────────────────────────────────────────────────
echo [7/7] Build complete!
echo.
color 0A
echo  ╔══════════════════════════════════════════════════════╗
echo  ║                                                      ║
echo  ║   ✅  BIC ERP Installer created successfully!        ║
echo  ║                                                      ║
echo  ║   📁  Location:  dist\                              ║
echo  ║   📦  File:      BIC ERP Setup 1.0.0.exe            ║
echo  ║                                                      ║
echo  ║   Share this .exe file to install on any            ║
echo  ║   Windows 10/11 computer.                           ║
echo  ║                                                      ║
echo  ╚══════════════════════════════════════════════════════╝
echo.

:: Open the dist folder
echo  Opening dist folder...
start "" dist\
echo.
pause

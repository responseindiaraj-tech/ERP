; BIC ERP — Custom NSIS Installer Script
; This file is included by electron-builder during the Windows build

!macro customHeader
  !system "echo Building BIC ERP installer..."
!macroend

!macro customInit
  ; Check Windows version (require Windows 10+)
  ReadRegStr $0 HKLM "SOFTWARE\Microsoft\Windows NT\CurrentVersion" "CurrentBuildNumber"
  IntCmp $0 19041 win10ok win10ok
    MessageBox MB_OK|MB_ICONEXCLAMATION "BIC ERP requires Windows 10 or Windows 11.$\nPlease upgrade your operating system."
    Abort
  win10ok:
!macroend

!macro customInstall
  ; Create data directory in AppData
  CreateDirectory "$APPDATA\bic-erp"
  
  ; Write registry entry for Add/Remove Programs
  WriteRegStr HKCU "Software\BIC Industries\BIC ERP" "InstallPath" "$INSTDIR"
  WriteRegStr HKCU "Software\BIC Industries\BIC ERP" "Version" "1.0.0"
  WriteRegStr HKCU "Software\BIC Industries\BIC ERP" "Company" "BIC Industries Private Limited"
!macroend

!macro customUnInstall
  ; Remove registry keys on uninstall
  DeleteRegKey HKCU "Software\BIC Industries\BIC ERP"
  
  ; Note: data directory is intentionally NOT deleted to preserve user data
  ; User must manually delete %APPDATA%\bic-erp if they want to remove all data
  MessageBox MB_OK|MB_ICONINFORMATION "BIC ERP has been uninstalled.$\n$\nYour data is preserved at:$\n$APPDATA\bic-erp$\n$\nDelete this folder manually if you want to remove all data."
!macroend

const path = require('path');
const { app } = require('electron');
const bcrypt = require('bcryptjs');

let Database;
try {
  Database = require('better-sqlite3');
} catch (e) {
  console.error('better-sqlite3 not found. Run: npm install better-sqlite3');
}

const DB_PATH = app
  ? path.join(app.getPath('userData'), 'bic-erp.db')
  : path.join(__dirname, '../../data/bic-erp.db');

let db = null;

const schema = `
  -- Company Settings
  CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY,
    company_name TEXT DEFAULT 'BIC Industries Private Limited',
    gstin TEXT,
    pan TEXT,
    address TEXT,
    city TEXT,
    state TEXT,
    state_code TEXT,
    pincode TEXT,
    phone TEXT,
    email TEXT,
    website TEXT,
    bank_name TEXT,
    account_number TEXT,
    ifsc_code TEXT,
    account_holder TEXT,
    logo_path TEXT,
    invoice_prefix TEXT DEFAULT 'BIC',
    invoice_counter INTEGER DEFAULT 1,
    financial_year TEXT DEFAULT '2024-25',
    theme TEXT DEFAULT 'dark',
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  -- Users
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT,
    role TEXT DEFAULT 'admin',
    email TEXT,
    is_active INTEGER DEFAULT 1,
    last_login TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  -- Customers
  CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    company_name TEXT,
    gstin TEXT,
    pan TEXT,
    mobile TEXT,
    alternate_mobile TEXT,
    email TEXT,
    address_line1 TEXT,
    address_line2 TEXT,
    city TEXT,
    state TEXT,
    state_code TEXT,
    pincode TEXT,
    customer_type TEXT DEFAULT 'B2B',
    credit_limit REAL DEFAULT 0,
    outstanding_amount REAL DEFAULT 0,
    notes TEXT,
    is_active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  -- Invoices
  CREATE TABLE IF NOT EXISTS invoices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_number TEXT UNIQUE NOT NULL,
    invoice_date TEXT NOT NULL,
    due_date TEXT,
    customer_id INTEGER REFERENCES customers(id),
    customer_name TEXT,
    customer_gstin TEXT,
    customer_address TEXT,
    billing_address TEXT,
    shipping_address TEXT,
    place_of_supply TEXT,
    invoice_type TEXT DEFAULT 'TAX_INVOICE',
    supply_type TEXT DEFAULT 'B2B',
    subtotal REAL DEFAULT 0,
    cgst_amount REAL DEFAULT 0,
    sgst_amount REAL DEFAULT 0,
    igst_amount REAL DEFAULT 0,
    total_tax REAL DEFAULT 0,
    discount_amount REAL DEFAULT 0,
    round_off REAL DEFAULT 0,
    grand_total REAL DEFAULT 0,
    amount_paid REAL DEFAULT 0,
    balance_due REAL DEFAULT 0,
    payment_mode TEXT DEFAULT 'CASH',
    payment_status TEXT DEFAULT 'PENDING',
    transport_name TEXT,
    vehicle_number TEXT,
    lr_number TEXT,
    eway_bill TEXT,
    delivery_date TEXT,
    notes TEXT,
    terms_conditions TEXT,
    status TEXT DEFAULT 'DRAFT',
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  -- Invoice Items
  CREATE TABLE IF NOT EXISTS invoice_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER REFERENCES invoices(id) ON DELETE CASCADE,
    item_name TEXT NOT NULL,
    description TEXT,
    hsn_sac TEXT,
    quantity REAL NOT NULL,
    unit TEXT DEFAULT 'NOS',
    rate REAL NOT NULL,
    discount_percent REAL DEFAULT 0,
    discount_amount REAL DEFAULT 0,
    taxable_amount REAL NOT NULL,
    gst_rate REAL DEFAULT 18,
    cgst_rate REAL DEFAULT 9,
    sgst_rate REAL DEFAULT 9,
    igst_rate REAL DEFAULT 0,
    cgst_amount REAL DEFAULT 0,
    sgst_amount REAL DEFAULT 0,
    igst_amount REAL DEFAULT 0,
    total_amount REAL NOT NULL,
    sort_order INTEGER DEFAULT 0
  );

  -- Inventory Categories
  CREATE TABLE IF NOT EXISTS inventory_categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    icon TEXT,
    color TEXT,
    parent_id INTEGER REFERENCES inventory_categories(id),
    created_at TEXT DEFAULT (datetime('now'))
  );

  -- Inventory Items
  CREATE TABLE IF NOT EXISTS inventory_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sku TEXT UNIQUE,
    name TEXT NOT NULL,
    description TEXT,
    category_id INTEGER REFERENCES inventory_categories(id),
    item_type TEXT DEFAULT 'STOCK',
    unit TEXT DEFAULT 'NOS',
    current_stock REAL DEFAULT 0,
    min_stock_level REAL DEFAULT 0,
    max_stock_level REAL DEFAULT 0,
    reorder_point REAL DEFAULT 0,
    purchase_price REAL DEFAULT 0,
    selling_price REAL DEFAULT 0,
    hsn_sac TEXT,
    gst_rate REAL DEFAULT 18,
    location TEXT,
    barcode TEXT,
    serial_number TEXT,
    asset_value REAL DEFAULT 0,
    is_asset INTEGER DEFAULT 0,
    notes TEXT,
    is_active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  -- Stock Movements
  CREATE TABLE IF NOT EXISTS stock_movements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id INTEGER REFERENCES inventory_items(id),
    movement_type TEXT NOT NULL,
    quantity REAL NOT NULL,
    unit_price REAL DEFAULT 0,
    total_value REAL DEFAULT 0,
    reference_type TEXT,
    reference_id INTEGER,
    reference_number TEXT,
    vendor_name TEXT,
    notes TEXT,
    movement_date TEXT DEFAULT (datetime('now')),
    created_by INTEGER REFERENCES users(id),
    created_at TEXT DEFAULT (datetime('now'))
  );

  -- Vendors
  CREATE TABLE IF NOT EXISTS vendors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    company_name TEXT,
    gstin TEXT,
    pan TEXT,
    mobile TEXT,
    email TEXT,
    address TEXT,
    city TEXT,
    state TEXT,
    pincode TEXT,
    bank_name TEXT,
    account_number TEXT,
    ifsc_code TEXT,
    credit_period INTEGER DEFAULT 30,
    notes TEXT,
    is_active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
  );

  -- Expenses
  CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    expense_date TEXT NOT NULL,
    expense_number TEXT,
    category TEXT NOT NULL,
    sub_category TEXT,
    description TEXT,
    vendor_id INTEGER REFERENCES vendors(id),
    vendor_name TEXT,
    vendor_invoice_number TEXT,
    amount REAL NOT NULL,
    gst_amount REAL DEFAULT 0,
    tds_amount REAL DEFAULT 0,
    net_amount REAL NOT NULL,
    payment_mode TEXT DEFAULT 'CASH',
    payment_status TEXT DEFAULT 'PAID',
    bill_image_path TEXT,
    notes TEXT,
    financial_year TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  -- Sales (non-invoice sales entries)
  CREATE TABLE IF NOT EXISTS sales_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sale_date TEXT NOT NULL,
    customer_id INTEGER REFERENCES customers(id),
    customer_name TEXT,
    invoice_id INTEGER REFERENCES invoices(id),
    description TEXT,
    amount REAL NOT NULL,
    gst_amount REAL DEFAULT 0,
    payment_mode TEXT DEFAULT 'CASH',
    payment_status TEXT DEFAULT 'RECEIVED',
    notes TEXT,
    financial_year TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  -- Indexes
  CREATE INDEX IF NOT EXISTS idx_invoices_date ON invoices(invoice_date);
  CREATE INDEX IF NOT EXISTS idx_invoices_customer ON invoices(customer_id);
  CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(payment_status);
  CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date);
  CREATE INDEX IF NOT EXISTS idx_inventory_category ON inventory_items(category_id);
  CREATE INDEX IF NOT EXISTS idx_stock_movements_item ON stock_movements(item_id);
`;

const seedData = `
  INSERT OR IGNORE INTO settings (id, company_name, gstin, address, city, state, state_code, pincode, phone, email, invoice_prefix)
  VALUES (1, 'BIC Industries Private Limited', '19AABCB1234A1Z5', '123, Industrial Area, Block A', 'Durgapur', 'West Bengal', '19', '713201', '+91 9999999999', 'info@bicindustries.com', 'BIC');

  INSERT OR IGNORE INTO inventory_categories (id, name, description, icon, color) VALUES
  (1, 'Printing Materials', 'Papers, sheets and printing supplies', 'printer', '#3b82f6'),
  (2, 'Ink & Consumables', 'Inks, toners and consumables', 'droplet', '#8b5cf6'),
  (3, 'Packaging', 'Packaging materials and supplies', 'package', '#f59e0b'),
  (4, 'Camera Equipment', 'Cameras, lenses and accessories', 'camera', '#10b981'),
  (5, 'Lighting Equipment', 'Lights, stands and accessories', 'sun', '#f97316'),
  (6, 'Storage Media', 'Hard disks, memory cards and storage', 'hard-drive', '#06b6d4'),
  (7, 'Other Assets', 'Miscellaneous business assets', 'box', '#6b7280');
`;

module.exports = {
  initialize() {
    if (!Database) return;
    
    const fs = require('fs');
    const dir = path.dirname(DB_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    db = new Database(DB_PATH);
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');

    // Run schema
    db.exec(schema);
    db.exec(seedData);

    // Create default admin if not exists
    const adminExists = db.prepare('SELECT id FROM users WHERE username = ?').get('admin');
    if (!adminExists) {
      const hash = bcrypt.hashSync('admin123', 10);
      db.prepare(`INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, ?)`)
        .run('admin', hash, 'Administrator', 'admin');
    }

    console.log('Database initialized at:', DB_PATH);
    return db;
  },

  getDB() { return db; },

  // Generic query helpers
  query(sql, params = []) {
    return db.prepare(sql).all(...params);
  },

  queryOne(sql, params = []) {
    return db.prepare(sql).get(...params);
  },

  run(sql, params = []) {
    return db.prepare(sql).run(...params);
  },

  transaction(fn) {
    return db.transaction(fn)();
  }
};

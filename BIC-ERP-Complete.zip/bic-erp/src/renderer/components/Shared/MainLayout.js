import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useApp } from '../../App';

const navItems = [
  { path: '/',          icon: GridIcon,       label: 'Dashboard',       exact: true },
  { path: '/invoices',  icon: FileTextIcon,   label: 'Invoices'         },
  { path: '/customers', icon: UsersIcon,      label: 'Customers'        },
  { path: '/inventory', icon: BoxIcon,        label: 'Inventory'        },
  { path: '/sales',     icon: TrendingUpIcon, label: 'Sales & Expenses' },
  { path: '/vendors',   icon: StoreIcon,      label: 'Vendors'          },
  { path: '/accounting',icon: BookIcon,       label: 'Accounting'       },
];

export default function MainLayout({ children }) {
  const { user, logout, theme, toggleTheme, settings } = useApp();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [profileOpen, setProfileOpen] = useState(false);

  const handleLogout = () => { logout(); navigate('/login'); };

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      {/* Title Bar */}
      <div className={`flex items-center h-10 px-4 drag shrink-0 ${theme === 'dark' ? 'bg-dark-900 border-dark-700' : 'bg-white border-gray-200'} border-b z-50`}>
        <div className="flex items-center gap-2 no-drag">
          <button
            onClick={() => setSidebarOpen(o => !o)}
            className={`p-1 rounded-md transition-colors ${theme === 'dark' ? 'hover:bg-dark-700 text-dark-400' : 'hover:bg-gray-100 text-gray-500'}`}>
            <MenuIcon size={16} />
          </button>
          <div className="flex items-center gap-1.5">
            <div className="w-5 h-5 rounded bg-primary-600 flex items-center justify-center">
              <span className="text-white text-[9px] font-bold">BIC</span>
            </div>
            <span className={`font-display font-bold text-sm ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>BIC ERP</span>
          </div>
        </div>
        <div className="flex-1" />
        <div className="flex items-center gap-1 no-drag">
          <button onClick={toggleTheme} className={`p-1.5 rounded-md transition-colors ${theme === 'dark' ? 'hover:bg-dark-700 text-dark-400' : 'hover:bg-gray-100 text-gray-500'}`}>
            {theme === 'dark' ? <SunIcon size={14} /> : <MoonIcon size={14} />}
          </button>
          <div className="relative">
            <button onClick={() => setProfileOpen(o => !o)} className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-xs transition-colors ${theme === 'dark' ? 'hover:bg-dark-700 text-dark-300' : 'hover:bg-gray-100 text-gray-600'}`}>
              <div className="w-5 h-5 rounded-full bg-primary-600 flex items-center justify-center text-[10px] text-white font-bold">
                {user?.full_name?.[0] || 'A'}
              </div>
              <span>{user?.full_name || 'Admin'}</span>
            </button>
            {profileOpen && (
              <div className={`absolute right-0 top-8 w-48 rounded-xl shadow-xl border z-50 py-1 ${theme === 'dark' ? 'bg-dark-800 border-dark-600' : 'bg-white border-gray-200'}`}>
                <div className={`px-3 py-2 border-b ${theme === 'dark' ? 'border-dark-600' : 'border-gray-100'}`}>
                  <p className={`text-xs font-semibold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>{user?.full_name}</p>
                  <p className={`text-xs ${theme === 'dark' ? 'text-dark-400' : 'text-gray-500'}`}>{user?.role}</p>
                </div>
                <button onClick={() => { navigate('/settings'); setProfileOpen(false); }} className={`w-full text-left px-3 py-2 text-xs transition-colors ${theme === 'dark' ? 'hover:bg-dark-700 text-dark-300' : 'hover:bg-gray-50 text-gray-700'}`}>
                  Settings
                </button>
                <button onClick={handleLogout} className="w-full text-left px-3 py-2 text-xs text-red-400 hover:bg-red-500/10 transition-colors">
                  Sign Out
                </button>
              </div>
            )}
          </div>
          <div className="flex items-center gap-px ml-2">
            <WinButton onClick={() => window.electronAPI?.minimizeWindow()} className="hover:bg-yellow-500/20 text-yellow-500"><MinusIcon size={10} /></WinButton>
            <WinButton onClick={() => window.electronAPI?.maximizeWindow()} className="hover:bg-green-500/20 text-green-500"><SquareIcon size={10} /></WinButton>
            <WinButton onClick={() => window.electronAPI?.closeWindow()} className="hover:bg-red-500/20 text-red-500"><XIcon size={10} /></WinButton>
          </div>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className={`shrink-0 flex flex-col transition-all duration-300 ${sidebarOpen ? 'w-52' : 'w-14'} ${theme === 'dark' ? 'bg-dark-900 border-dark-700' : 'bg-white border-gray-200'} border-r`}>
          {/* Company name */}
          {sidebarOpen && (
            <div className={`px-4 py-3 border-b ${theme === 'dark' ? 'border-dark-700' : 'border-gray-100'}`}>
              <p className={`text-xs font-semibold truncate ${theme === 'dark' ? 'text-dark-400' : 'text-gray-500'}`}>{settings?.company_name || 'BIC Industries'}</p>
            </div>
          )}

          {/* Nav */}
          <nav className="flex-1 p-2 space-y-0.5 overflow-y-auto">
            {navItems.map(({ path, icon: Icon, label, exact }) => (
              <NavLink
                key={path}
                to={path}
                end={exact}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all group
                  ${isActive
                    ? 'bg-primary-600 text-white shadow-md'
                    : theme === 'dark'
                      ? 'text-dark-400 hover:text-white hover:bg-dark-700'
                      : 'text-gray-500 hover:text-gray-900 hover:bg-gray-100'
                  }`
                }>
                {({ isActive }) => (
                  <>
                    <Icon size={18} className="shrink-0" />
                    {sidebarOpen && <span className="truncate">{label}</span>}
                  </>
                )}
              </NavLink>
            ))}
          </nav>

          {/* Bottom */}
          <div className={`p-2 border-t ${theme === 'dark' ? 'border-dark-700' : 'border-gray-100'}`}>
            <NavLink to="/settings"
              className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all
                ${isActive ? 'bg-primary-600 text-white' : theme === 'dark' ? 'text-dark-400 hover:text-white hover:bg-dark-700' : 'text-gray-500 hover:text-gray-900 hover:bg-gray-100'}`}>
              {({ isActive }) => (
                <>
                  <SettingsIcon size={18} className="shrink-0" />
                  {sidebarOpen && <span>Settings</span>}
                </>
              )}
            </NavLink>
          </div>
        </aside>

        {/* Main content */}
        <main className={`flex-1 overflow-hidden flex flex-col ${theme === 'dark' ? 'bg-dark-950' : 'bg-gray-50'}`}>
          <div className="flex-1 overflow-y-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}

const WinButton = ({ children, onClick, className }) => (
  <button onClick={onClick} className={`w-7 h-7 flex items-center justify-center rounded-md transition-colors no-drag ${className}`}>
    {children}
  </button>
);

// Inline SVG Icons
function GridIcon({ size = 18 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>;
}
function FileTextIcon({ size = 18 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14,2 14,8 20,8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10,9 9,9 8,9"/></svg>;
}
function UsersIcon({ size = 18 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>;
}
function BoxIcon({ size = 18 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27,6.96 12,12.01 20.73,6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>;
}
function TrendingUpIcon({ size = 18 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="23,6 13.5,15.5 8.5,10.5 1,18"/><polyline points="17,6 23,6 23,12"/></svg>;
}
function StoreIcon({ size = 18 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9,22 9,12 15,12 15,22"/></svg>;
}
function BookIcon({ size = 18 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>;
}
function SettingsIcon({ size = 18 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>;
}
function MenuIcon({ size = 18 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>;
}
function SunIcon({ size = 14 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>;
}
function MoonIcon({ size = 14 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>;
}
function MinusIcon({ size = 10 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="5" y1="12" x2="19" y2="12"/></svg>;
}
function SquareIcon({ size = 10 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><rect x="4" y="4" width="16" height="16" rx="2"/></svg>;
}
function XIcon({ size = 10 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>;
}

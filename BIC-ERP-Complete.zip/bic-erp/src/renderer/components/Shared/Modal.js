import React, { useEffect, useRef } from 'react';
import { useApp } from '../../App';

/**
 * Reusable modal overlay.
 * Usage:
 *   <Modal open={open} onClose={() => setOpen(false)} title="Edit Customer" size="md">
 *     ...children...
 *   </Modal>
 *
 * sizes: sm (400px)  md (560px)  lg (760px)  xl (960px)
 */
export default function Modal({ open, onClose, title, subtitle, children, size = 'md', footer }) {
  const { theme } = useApp();
  const dark      = theme === 'dark';
  const overlayRef = useRef(null);

  // Close on Escape key
  useEffect(() => {
    if (!open) return;
    const handler = (e) => { if (e.key === 'Escape') onClose?.(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [open, onClose]);

  // Trap scroll on body when open
  useEffect(() => {
    if (open) document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; };
  }, [open]);

  if (!open) return null;

  const widths = { sm: 'max-w-sm', md: 'max-w-xl', lg: 'max-w-2xl', xl: 'max-w-4xl' };

  return (
    <div
      ref={overlayRef}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in"
      onClick={(e) => { if (e.target === overlayRef.current) onClose?.(); }}
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div
        className={`w-full ${widths[size]} rounded-2xl border shadow-2xl flex flex-col max-h-[90vh] animate-slide-up
          ${dark ? 'bg-dark-800 border-dark-600' : 'bg-white border-gray-200'}`}
      >
        {/* Header */}
        <div
          className={`flex items-start justify-between px-5 py-4 border-b shrink-0
            ${dark ? 'border-dark-600' : 'border-gray-100'}`}
        >
          <div>
            <h2
              id="modal-title"
              className={`font-display font-bold text-lg ${dark ? 'text-white' : 'text-gray-900'}`}
            >
              {title}
            </h2>
            {subtitle && (
              <p className={`text-xs mt-0.5 ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{subtitle}</p>
            )}
          </div>
          <button
            onClick={onClose}
            className={`p-2 rounded-xl transition-colors shrink-0 ml-3
              ${dark ? 'hover:bg-dark-700 text-dark-400 hover:text-white' : 'hover:bg-gray-100 text-gray-400 hover:text-gray-700'}`}
            aria-label="Close modal"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-5 py-4">
          {children}
        </div>

        {/* Footer */}
        {footer && (
          <div
            className={`px-5 py-4 border-t shrink-0 flex items-center justify-end gap-3
              ${dark ? 'border-dark-600' : 'border-gray-100'}`}
          >
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Convenience sub-components ────────────────────────────────────────────────

/** Standard Cancel + Action footer */
export function ModalFooter({ onCancel, onConfirm, confirmLabel = 'Save', cancelLabel = 'Cancel', loading = false, destructive = false }) {
  const { theme } = useApp();
  const dark = theme === 'dark';
  return (
    <>
      <button
        onClick={onCancel}
        className={`px-4 py-2 rounded-xl text-sm font-medium border transition-colors
          ${dark ? 'border-dark-600 text-dark-300 hover:bg-dark-700' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}
      >
        {cancelLabel}
      </button>
      <button
        onClick={onConfirm}
        disabled={loading}
        className={`px-5 py-2 rounded-xl text-sm font-semibold text-white transition-colors flex items-center gap-2 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed
          ${destructive
            ? 'bg-red-600 hover:bg-red-500 shadow-red-500/20'
            : 'bg-primary-600 hover:bg-primary-500 shadow-primary-500/20'
          }`}
      >
        {loading && (
          <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
        )}
        {confirmLabel}
      </button>
    </>
  );
}

/** Section divider inside modals */
export function ModalSection({ title }) {
  const { theme } = useApp();
  const dark = theme === 'dark';
  return (
    <p className={`text-xs font-bold uppercase tracking-wider mb-3 mt-1 ${dark ? 'text-dark-500' : 'text-gray-400'}`}>
      {title}
    </p>
  );
}

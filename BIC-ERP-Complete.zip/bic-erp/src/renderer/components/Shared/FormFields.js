import React from 'react';
import { useApp } from '../../App';

/**
 * Shared form components for consistent styling across all pages.
 *
 * Usage:
 *   import { Field, Input, Select, Textarea, FormGrid } from '../components/Shared/FormFields';
 *
 *   <FormGrid cols={2}>
 *     <Field label="Company Name" required>
 *       <Input value={form.name} onChange={f('name')} placeholder="Enter name" />
 *     </Field>
 *   </FormGrid>
 */

function useDark() {
  const { theme } = useApp();
  return theme === 'dark';
}

const baseCls = (dark) =>
  `w-full px-3 py-2 rounded-xl text-sm border focus:outline-none focus:border-primary-500 transition-colors allow-select
   ${dark
     ? 'bg-dark-700 border-dark-600 text-white placeholder-dark-500 focus:bg-dark-700'
     : 'bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400 focus:bg-white'
   }`;

// ── Label ─────────────────────────────────────────────────────────────────────
export function Label({ children, required, htmlFor }) {
  const dark = useDark();
  return (
    <label
      htmlFor={htmlFor}
      className={`block text-xs font-semibold mb-1.5 ${dark ? 'text-dark-300' : 'text-gray-600'}`}
    >
      {children}
      {required && <span className="text-red-400 ml-0.5">*</span>}
    </label>
  );
}

// ── Field wrapper ─────────────────────────────────────────────────────────────
export function Field({ label, required, error, children, className = '' }) {
  return (
    <div className={className}>
      {label && <Label required={required}>{label}</Label>}
      {children}
      {error && <p className="text-xs text-red-400 mt-1">{error}</p>}
    </div>
  );
}

// ── Input ─────────────────────────────────────────────────────────────────────
export const Input = React.forwardRef(function Input(
  { className = '', mono = false, ...props },
  ref
) {
  const dark = useDark();
  return (
    <input
      ref={ref}
      {...props}
      className={`${baseCls(dark)} ${mono ? 'font-mono' : ''} ${className}`}
    />
  );
});

// ── Select ────────────────────────────────────────────────────────────────────
export function Select({ children, className = '', ...props }) {
  const dark = useDark();
  return (
    <select {...props} className={`${baseCls(dark)} ${className}`}>
      {children}
    </select>
  );
}

// ── Textarea ──────────────────────────────────────────────────────────────────
export function Textarea({ rows = 3, className = '', ...props }) {
  const dark = useDark();
  return (
    <textarea
      rows={rows}
      {...props}
      className={`${baseCls(dark)} resize-none ${className}`}
    />
  );
}

// ── Checkbox ──────────────────────────────────────────────────────────────────
export function Checkbox({ label, description, checked, onChange, id }) {
  const dark = useDark();
  return (
    <div
      className={`flex items-start gap-3 p-3 rounded-xl border border-dashed cursor-pointer
        ${dark ? 'border-dark-600 hover:border-dark-500' : 'border-gray-200 hover:border-gray-300'}`}
      onClick={() => onChange?.({ target: { checked: !checked, type: 'checkbox' } })}
    >
      <input
        type="checkbox"
        id={id}
        checked={checked}
        onChange={onChange}
        className="w-4 h-4 mt-0.5 rounded accent-primary-500 cursor-pointer"
        onClick={(e) => e.stopPropagation()}
      />
      <div>
        <label
          htmlFor={id}
          className={`text-xs font-semibold cursor-pointer ${dark ? 'text-dark-200' : 'text-gray-700'}`}
        >
          {label}
        </label>
        {description && (
          <p className={`text-xs mt-0.5 ${dark ? 'text-dark-500' : 'text-gray-400'}`}>{description}</p>
        )}
      </div>
    </div>
  );
}

// ── FormGrid ──────────────────────────────────────────────────────────────────
export function FormGrid({ cols = 2, children, className = '' }) {
  const colMap = { 1: 'grid-cols-1', 2: 'grid-cols-2', 3: 'grid-cols-3', 4: 'grid-cols-4' };
  return (
    <div className={`grid ${colMap[cols] || 'grid-cols-2'} gap-3 ${className}`}>
      {children}
    </div>
  );
}

// ── FormSection ───────────────────────────────────────────────────────────────
export function FormSection({ title, children, className = '' }) {
  const dark = useDark();
  return (
    <div className={className}>
      <p className={`text-xs font-bold uppercase tracking-wider mb-3 ${dark ? 'text-dark-500' : 'text-gray-400'}`}>
        {title}
      </p>
      {children}
    </div>
  );
}

// ── SectionCard ───────────────────────────────────────────────────────────────
export function SectionCard({ title, children, className = '' }) {
  const dark = useDark();
  return (
    <div
      className={`p-5 rounded-2xl border ${className}
        ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}
    >
      {title && (
        <h3 className={`font-semibold text-sm mb-4 ${dark ? 'text-white' : 'text-gray-900'}`}>
          {title}
        </h3>
      )}
      {children}
    </div>
  );
}

// ── StatusBadge ───────────────────────────────────────────────────────────────
const STATUS_STYLES = {
  PAID      : 'bg-green-500/10 text-green-400 border-green-500/20',
  RECEIVED  : 'bg-green-500/10 text-green-400 border-green-500/20',
  PENDING   : 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  PARTIAL   : 'bg-blue-500/10  text-blue-400  border-blue-500/20',
  DRAFT     : 'bg-gray-500/10  text-gray-400  border-gray-500/20',
  CANCELLED : 'bg-red-500/10   text-red-400   border-red-500/20',
  LOW       : 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  OUT       : 'bg-red-500/10   text-red-400   border-red-500/20',
  OK        : 'bg-green-500/10 text-green-400 border-green-500/20',
};

export function StatusBadge({ status }) {
  return (
    <span
      className={`inline-flex items-center text-[10px] font-bold px-2 py-0.5 rounded-md border
        ${STATUS_STYLES[status] || STATUS_STYLES.PENDING}`}
    >
      {status}
    </span>
  );
}

// ── EmptyState ────────────────────────────────────────────────────────────────
export function EmptyState({ icon = '📭', title = 'No data found', subtitle, action }) {
  const dark = useDark();
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
      <div className="text-4xl mb-3">{icon}</div>
      <p className={`font-semibold text-sm ${dark ? 'text-white' : 'text-gray-900'}`}>{title}</p>
      {subtitle && (
        <p className={`text-xs mt-1 ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{subtitle}</p>
      )}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

// ── LoadingSpinner ────────────────────────────────────────────────────────────
export function LoadingSpinner({ size = 6, className = '' }) {
  return (
    <div className={`flex items-center justify-center py-12 ${className}`}>
      <div
        className={`w-${size} h-${size} border-2 border-primary-500 border-t-transparent rounded-full animate-spin`}
      />
    </div>
  );
}

// ── PageHeader ────────────────────────────────────────────────────────────────
export function PageHeader({ title, subtitle, children }) {
  const dark = useDark();
  return (
    <div className="flex items-center justify-between mb-6">
      <div>
        <h1 className={`font-display font-bold text-2xl ${dark ? 'text-white' : 'text-gray-900'}`}>
          {title}
        </h1>
        {subtitle && (
          <p className={`text-sm mt-0.5 ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{subtitle}</p>
        )}
      </div>
      {children && <div className="flex items-center gap-2">{children}</div>}
    </div>
  );
}

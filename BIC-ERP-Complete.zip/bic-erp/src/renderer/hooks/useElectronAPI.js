/**
 * BIC ERP — useElectronAPI hook
 *
 * Wraps window.electronAPI calls with:
 *  - Loading state
 *  - Error handling
 *  - Mock fallback when running in browser (development)
 *
 * Usage:
 *   const { data, loading, error, call } = useElectronAPI();
 *   const customers = await call('getCustomers', { search: 'abc' });
 */

import { useState, useCallback } from 'react';

export function useElectronAPI() {
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState(null);

  const call = useCallback(async (method, ...args) => {
    setLoading(true);
    setError(null);
    try {
      const api = window.electronAPI;
      if (!api || typeof api[method] !== 'function') {
        throw new Error(`API method "${method}" not available (running in browser?)`);
      }
      const result = await api[method](...args);
      return result;
    } catch (err) {
      setError(err.message);
      console.error(`[ElectronAPI] ${method}:`, err);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const isElectron = () =>
    typeof window !== 'undefined' && !!window.electronAPI;

  return { loading, error, call, isElectron };
}

/**
 * useAsyncData — auto-fetch on mount / dep change.
 *
 * Usage:
 *   const { data, loading, refresh } = useAsyncData(
 *     () => window.electronAPI.getCustomers({ search }),
 *     MOCK_CUSTOMERS,
 *     [search]
 *   );
 */
import { useState as uS, useEffect as uE, useCallback as uC } from 'react';

export function useAsyncData(fetcher, fallback = [], deps = []) {
  const [data,    setData]    = uS(fallback);
  const [loading, setLoading] = uS(true);
  const [error,   setError]   = uS(null);

  const load = uC(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await fetcher();
      setData(result ?? fallback);
    } catch (err) {
      console.error('[useAsyncData]', err);
      setError(err.message);
      setData(fallback);
    } finally {
      setLoading(false);
    }
  }, deps); // eslint-disable-line react-hooks/exhaustive-deps

  uE(() => { load(); }, [load]);

  return { data, loading, error, refresh: load, setData };
}

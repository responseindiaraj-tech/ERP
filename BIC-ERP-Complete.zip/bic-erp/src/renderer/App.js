import React, { useState, useEffect, createContext, useContext } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import MainLayout from './components/Shared/MainLayout';
import Dashboard from './pages/Dashboard';
import Invoices from './pages/Invoices';
import Customers from './pages/Customers';
import Inventory from './pages/Inventory';
import SalesExpenses from './pages/SalesExpenses';
import Vendors from './pages/Vendors';
import Accounting from './pages/Accounting';
import Settings from './pages/Settings';
import './index.css';

export const AppContext = createContext(null);

export function useApp() { return useContext(AppContext); }

function App() {
  const [user, setUser] = useState(null);
  const [theme, setTheme] = useState('dark');
  const [loading, setLoading] = useState(true);
  const [settings, setSettings] = useState(null);
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    const saved = localStorage.getItem('bic-user');
    const savedTheme = localStorage.getItem('bic-theme') || 'dark';
    if (saved) setUser(JSON.parse(saved));
    setTheme(savedTheme);
    setLoading(false);
    loadSettings();
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    localStorage.setItem('bic-theme', theme);
  }, [theme]);

  const loadSettings = async () => {
    if (window.electronAPI) {
      const s = await window.electronAPI.getSettings();
      if (s) setSettings(s);
    }
  };

  const login = (userData) => {
    setUser(userData);
    localStorage.setItem('bic-user', JSON.stringify(userData));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('bic-user');
  };

  const addNotification = (message, type = 'success') => {
    const id = Date.now();
    setNotifications(prev => [...prev, { id, message, type }]);
    setTimeout(() => setNotifications(prev => prev.filter(n => n.id !== id)), 4000);
  };

  const toggleTheme = () => setTheme(t => t === 'dark' ? 'light' : 'dark');

  if (loading) return (
    <div className="flex items-center justify-center h-screen bg-dark-950">
      <div className="text-center">
        <div className="w-16 h-16 border-4 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-white font-display text-xl">BIC ERP</p>
      </div>
    </div>
  );

  return (
    <AppContext.Provider value={{ user, login, logout, theme, toggleTheme, settings, loadSettings, addNotification }}>
      <Router>
        <div className={`min-h-screen font-sans ${theme === 'dark' ? 'bg-dark-950 text-white' : 'bg-gray-50 text-gray-900'}`}>
          {/* Global Notifications */}
          <div className="fixed top-4 right-4 z-50 space-y-2 pointer-events-none">
            {notifications.map(n => (
              <div key={n.id} className={`px-4 py-3 rounded-xl shadow-lg text-sm font-medium animate-slide-up pointer-events-auto
                ${n.type === 'success' ? 'bg-green-500 text-white' :
                  n.type === 'error' ? 'bg-red-500 text-white' :
                  n.type === 'warning' ? 'bg-amber-500 text-white' : 'bg-primary-500 text-white'}`}>
                {n.message}
              </div>
            ))}
          </div>

          <Routes>
            <Route path="/login" element={!user ? <LoginPage /> : <Navigate to="/" />} />
            <Route path="/*" element={user ? (
              <MainLayout>
                <Routes>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/invoices/*" element={<Invoices />} />
                  <Route path="/customers/*" element={<Customers />} />
                  <Route path="/inventory/*" element={<Inventory />} />
                  <Route path="/sales/*" element={<SalesExpenses />} />
                  <Route path="/vendors/*" element={<Vendors />} />
                  <Route path="/accounting/*" element={<Accounting />} />
                  <Route path="/settings" element={<Settings />} />
                </Routes>
              </MainLayout>
            ) : <Navigate to="/login" />} />
          </Routes>
        </div>
      </Router>
    </AppContext.Provider>
  );
}

export default App;

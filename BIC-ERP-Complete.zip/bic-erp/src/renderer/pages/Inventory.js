import React, { useState, useEffect } from 'react';
import { useApp } from '../App';

const CATEGORIES = [
  { id: 1, name: 'Printing Materials', icon: '🖨️', color: '#3b82f6' },
  { id: 2, name: 'Ink & Consumables', icon: '🎨', color: '#8b5cf6' },
  { id: 3, name: 'Packaging', icon: '📦', color: '#f59e0b' },
  { id: 4, name: 'Camera Equipment', icon: '📷', color: '#10b981' },
  { id: 5, name: 'Lighting Equipment', icon: '💡', color: '#f97316' },
  { id: 6, name: 'Storage Media', icon: '💾', color: '#06b6d4' },
  { id: 7, name: 'Other Assets', icon: '🗃️', color: '#6b7280' },
];

const MOCK_INVENTORY = [
  { id: 1, sku: 'PM-001', name: 'A4 Photo Paper 260gsm', category_id: 1, category_name: 'Printing Materials', unit: 'PKT', current_stock: 45, reorder_point: 10, min_stock_level: 5, purchase_price: 850, selling_price: 1200, hsn_sac: '4802', gst_rate: 12, is_asset: 0 },
  { id: 2, sku: 'PM-002', name: 'Album Sheets A3 (Pack of 50)', category_id: 1, category_name: 'Printing Materials', unit: 'PKT', current_stock: 8, reorder_point: 15, min_stock_level: 5, purchase_price: 1200, selling_price: 1800, hsn_sac: '4802', gst_rate: 12, is_asset: 0 },
  { id: 3, sku: 'INK-001', name: 'Canon Pro Series Ink Set (6 Colors)', category_id: 2, category_name: 'Ink & Consumables', unit: 'SET', current_stock: 12, reorder_point: 5, min_stock_level: 2, purchase_price: 3500, selling_price: 4800, hsn_sac: '3215', gst_rate: 18, is_asset: 0 },
  { id: 4, sku: 'PKG-001', name: 'Photo Frame Box (10x12")', category_id: 3, category_name: 'Packaging', unit: 'NOS', current_stock: 3, reorder_point: 20, min_stock_level: 10, purchase_price: 85, selling_price: 120, hsn_sac: '4819', gst_rate: 12, is_asset: 0 },
  { id: 5, sku: 'CAM-001', name: 'Canon EOS R6 Mark II', category_id: 4, category_name: 'Camera Equipment', unit: 'NOS', current_stock: 2, reorder_point: 1, min_stock_level: 1, purchase_price: 245000, selling_price: 0, hsn_sac: '8525', gst_rate: 18, is_asset: 1, asset_value: 245000 },
  { id: 6, sku: 'CAM-002', name: 'Canon RF 24-70mm f/2.8L Lens', category_id: 4, category_name: 'Camera Equipment', unit: 'NOS', current_stock: 3, reorder_point: 1, min_stock_level: 1, purchase_price: 165000, selling_price: 0, hsn_sac: '9002', gst_rate: 18, is_asset: 1, asset_value: 165000 },
  { id: 7, sku: 'LGT-001', name: 'Godox SL200W LED Light', category_id: 5, category_name: 'Lighting Equipment', unit: 'NOS', current_stock: 4, reorder_point: 2, min_stock_level: 1, purchase_price: 18500, selling_price: 0, hsn_sac: '9405', gst_rate: 18, is_asset: 1, asset_value: 18500 },
  { id: 8, sku: 'STR-001', name: 'WD 4TB External Hard Disk', category_id: 6, category_name: 'Storage Media', unit: 'NOS', current_stock: 6, reorder_point: 3, min_stock_level: 2, purchase_price: 8500, selling_price: 9800, hsn_sac: '8471', gst_rate: 18, is_asset: 0 },
  { id: 9, sku: 'STR-002', name: 'SanDisk 128GB Memory Card (V60)', category_id: 6, category_name: 'Storage Media', unit: 'NOS', current_stock: 15, reorder_point: 5, min_stock_level: 3, purchase_price: 2800, selling_price: 3500, hsn_sac: '8523', gst_rate: 18, is_asset: 0 },
];

const EMPTY_FORM = {
  sku: '', name: '', description: '', category_id: '', unit: 'NOS',
  current_stock: 0, min_stock_level: 0, max_stock_level: 0, reorder_point: 0,
  purchase_price: 0, selling_price: 0, hsn_sac: '', gst_rate: 18,
  location: '', serial_number: '', asset_value: 0, is_asset: false, notes: ''
};

const fmt = (n) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n || 0);

export default function Inventory() {
  const { theme, addNotification } = useApp();
  const dark = theme === 'dark';
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState('');
  const [lowStockOnly, setLowStockOnly] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [showStockModal, setShowStockModal] = useState(null); // item
  const [editItem, setEditItem] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [stockForm, setStockForm] = useState({ movement_type: 'IN', quantity: 1, unit_price: 0, vendor_name: '', notes: '' });
  const [saving, setSaving] = useState(false);
  const [selected, setSelected] = useState(null);

  useEffect(() => { loadItems(); }, [search, catFilter, lowStockOnly]);

  const loadItems = async () => {
    setLoading(true);
    try {
      let data;
      if (window.electronAPI) {
        data = await window.electronAPI.getInventory({ search, category_id: catFilter, low_stock: lowStockOnly });
      } else {
        data = MOCK_INVENTORY.filter(i => {
          if (search && !i.name.toLowerCase().includes(search.toLowerCase())) return false;
          if (catFilter && i.category_id !== parseInt(catFilter)) return false;
          if (lowStockOnly && i.current_stock > i.reorder_point) return false;
          return true;
        });
      }
      setItems(data);
    } catch { setItems(MOCK_INVENTORY); }
    setLoading(false);
  };

  const openNew = () => { setForm(EMPTY_FORM); setEditItem(null); setShowModal(true); };
  const openEdit = (item) => { setForm({ ...EMPTY_FORM, ...item, is_asset: !!item.is_asset }); setEditItem(item); setShowModal(true); };

  const f = (field) => (e) => setForm(p => ({ ...p, [field]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }));

  const handleSave = async () => {
    if (!form.name || !form.category_id) { addNotification('Name and category are required', 'error'); return; }
    setSaving(true);
    try {
      let result;
      if (window.electronAPI) {
        result = editItem
          ? await window.electronAPI.updateInventoryItem(editItem.id, form)
          : await window.electronAPI.createInventoryItem(form);
      } else { result = { success: true }; }
      if (result.success) {
        addNotification(editItem ? 'Item updated!' : 'Item added!', 'success');
        setShowModal(false); loadItems();
      }
    } catch { addNotification('Error saving item', 'error'); }
    setSaving(false);
  };

  const handleStockMovement = async () => {
    if (!stockForm.quantity || stockForm.quantity <= 0) { addNotification('Enter valid quantity', 'error'); return; }
    setSaving(true);
    try {
      let result;
      if (window.electronAPI) {
        result = await window.electronAPI.stockMovement({ item_id: showStockModal.id, ...stockForm });
      } else { result = { success: true, current_stock: showStockModal.current_stock + (stockForm.movement_type === 'IN' ? 1 : -1) * stockForm.quantity }; }
      if (result.success) {
        addNotification(`Stock updated! New qty: ${result.current_stock}`, 'success');
        setShowStockModal(null); loadItems();
      }
    } catch { addNotification('Error updating stock', 'error'); }
    setSaving(false);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Remove this item?')) return;
    try {
      if (window.electronAPI) await window.electronAPI.deleteInventoryItem(id);
      addNotification('Item removed', 'success');
      loadItems(); if (selected?.id === id) setSelected(null);
    } catch { addNotification('Error', 'error'); }
  };

  const totalValue = items.reduce((s, i) => s + (i.current_stock * i.purchase_price), 0);
  const lowStockCount = items.filter(i => i.current_stock <= i.reorder_point && i.reorder_point > 0).length;
  const assetValue = items.filter(i => i.is_asset).reduce((s, i) => s + (i.asset_value || 0), 0);

  const inputCls = `w-full px-3 py-2 rounded-lg text-xs border focus:outline-none focus:border-primary-500 transition-colors allow-select
    ${dark ? 'bg-dark-700 border-dark-600 text-white placeholder-dark-500' : 'bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400'}`;
  const labelCls = `block text-xs font-semibold mb-1 ${dark ? 'text-dark-300' : 'text-gray-600'}`;

  const stockLevel = (item) => {
    if (item.reorder_point <= 0) return 'ok';
    if (item.current_stock <= 0) return 'out';
    if (item.current_stock <= item.reorder_point) return 'low';
    return 'ok';
  };

  const stockColors = { out: 'text-red-400 bg-red-500/10 border-red-500/20', low: 'text-amber-400 bg-amber-500/10 border-amber-500/20', ok: 'text-green-400 bg-green-500/10 border-green-500/20' };

  return (
    <div className="p-6 space-y-4 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className={`font-display font-bold text-2xl ${dark ? 'text-white' : 'text-gray-900'}`}>Inventory</h1>
          <p className={`text-sm ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{items.length} items · Stock & Asset Management</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setLowStockOnly(v => !v)} className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium border transition-colors
            ${lowStockOnly ? 'bg-amber-500/10 border-amber-500/30 text-amber-400' : dark ? 'border-dark-600 text-dark-400 hover:bg-dark-700' : 'border-gray-200 text-gray-500 hover:bg-gray-50'}`}>
            ⚠️ Low Stock {lowStockCount > 0 && <span className="bg-amber-500 text-white rounded-full w-4 h-4 flex items-center justify-center text-[10px]">{lowStockCount}</span>}
          </button>
          <button onClick={openNew} className="flex items-center gap-2 px-4 py-2 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-sm font-semibold transition-all shadow-lg shadow-primary-500/20">
            + Add Item
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: 'Total Items', value: items.length, color: 'text-primary-400' },
          { label: 'Stock Value', value: fmt(totalValue), color: 'text-green-400' },
          { label: 'Asset Value', value: fmt(assetValue), color: 'text-purple-400' },
          { label: 'Low Stock Alerts', value: lowStockCount, color: 'text-amber-400' },
        ].map((s, i) => (
          <div key={i} className={`p-4 rounded-xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100'}`}>
            <p className={`text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{s.label}</p>
            <p className={`font-display font-bold text-lg mt-1 ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className={`flex items-center gap-2 p-3 rounded-xl border flex-wrap ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100'}`}>
        <div className="relative">
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search items..."
            className={`pl-8 pr-4 py-1.5 rounded-lg text-xs border focus:outline-none focus:border-primary-500 w-48 allow-select
              ${dark ? 'bg-dark-700 border-dark-600 text-white placeholder-dark-500' : 'bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400'}`} />
          <svg className={`absolute left-2.5 top-1/2 -translate-y-1/2 ${dark ? 'text-dark-400' : 'text-gray-400'}`} width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        </div>
        <div className="flex gap-1 flex-wrap">
          <button onClick={() => setCatFilter('')} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${!catFilter ? 'bg-primary-600 text-white' : dark ? 'bg-dark-700 text-dark-400 hover:text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
            All
          </button>
          {CATEGORIES.map(c => (
            <button key={c.id} onClick={() => setCatFilter(catFilter === c.id.toString() ? '' : c.id.toString())}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${catFilter === c.id.toString() ? 'bg-primary-600 text-white' : dark ? 'bg-dark-700 text-dark-400 hover:text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
              {c.icon} {c.name}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className={`rounded-2xl border overflow-hidden ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
        <table className="w-full">
          <thead>
            <tr className={`border-b text-xs font-semibold ${dark ? 'bg-dark-700/50 border-dark-600 text-dark-400' : 'bg-gray-50 border-gray-100 text-gray-500'}`}>
              <th className="text-left px-4 py-3">Item</th>
              <th className="text-left px-4 py-3">Category</th>
              <th className="text-left px-4 py-3">SKU</th>
              <th className="text-center px-4 py-3">Stock</th>
              <th className="text-center px-4 py-3">Status</th>
              <th className="text-right px-4 py-3">Purchase Price</th>
              <th className="text-right px-4 py-3">Stock Value</th>
              <th className="text-center px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody className={`divide-y ${dark ? 'divide-dark-700/40' : 'divide-gray-50'}`}>
            {loading ? (
              <tr><td colSpan={8} className="text-center py-12"><div className="w-6 h-6 border-2 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto" /></td></tr>
            ) : items.length === 0 ? (
              <tr><td colSpan={8} className={`text-center py-12 text-sm ${dark ? 'text-dark-400' : 'text-gray-400'}`}>No items found.</td></tr>
            ) : items.map(item => {
              const sl = stockLevel(item);
              const cat = CATEGORIES.find(c => c.id === item.category_id);
              return (
                <tr key={item.id} className={`transition-colors ${dark ? 'hover:bg-dark-700/30' : 'hover:bg-gray-50'}`}>
                  <td className="px-4 py-3">
                    <p className={`text-xs font-semibold ${dark ? 'text-white' : 'text-gray-900'}`}>{item.name}</p>
                    {item.is_asset === 1 && <span className="text-[10px] text-purple-400 font-medium">📌 Asset</span>}
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-xs">{cat?.icon} <span className={dark ? 'text-dark-300' : 'text-gray-600'}>{item.category_name}</span></span>
                  </td>
                  <td className={`px-4 py-3 text-xs font-mono ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{item.sku || '—'}</td>
                  <td className="px-4 py-3 text-center">
                    <span className={`text-sm font-bold ${sl === 'out' ? 'text-red-400' : sl === 'low' ? 'text-amber-400' : dark ? 'text-white' : 'text-gray-900'}`}>
                      {item.current_stock}
                    </span>
                    <span className={`text-xs ml-1 ${dark ? 'text-dark-400' : 'text-gray-400'}`}>{item.unit}</span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${stockColors[sl]}`}>
                      {sl === 'out' ? 'OUT' : sl === 'low' ? 'LOW' : 'OK'}
                    </span>
                  </td>
                  <td className={`px-4 py-3 text-xs text-right ${dark ? 'text-dark-300' : 'text-gray-600'}`}>{fmt(item.purchase_price)}</td>
                  <td className={`px-4 py-3 text-xs text-right font-semibold ${dark ? 'text-white' : 'text-gray-900'}`}>{fmt(item.current_stock * item.purchase_price)}</td>
                  <td className="px-4 py-3 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => { setShowStockModal(item); setStockForm({ movement_type: 'IN', quantity: 1, unit_price: item.purchase_price, vendor_name: '', notes: '' }); }}
                        className="px-2 py-1 rounded-lg bg-green-500/10 hover:bg-green-500/20 text-green-400 text-[10px] font-semibold transition-colors border border-green-500/20">
                        Stock In/Out
                      </button>
                      <button onClick={() => openEdit(item)} className={`p-1.5 rounded-lg transition-colors ${dark ? 'hover:bg-dark-600 text-dark-400 hover:text-blue-400' : 'hover:bg-gray-100 text-gray-400 hover:text-blue-600'}`}>
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                      </button>
                      <button onClick={() => handleDelete(item.id)} className={`p-1.5 rounded-lg transition-colors ${dark ? 'hover:bg-dark-600 text-dark-400 hover:text-red-400' : 'hover:bg-gray-100 text-gray-400 hover:text-red-500'}`}>
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3,6 5,6 21,6"/><path d="M19,6l-1,14H6L5,6"/><path d="M10,11v6"/><path d="M14,11v6"/><path d="M9,6V4h6v2"/></svg>
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Stock Movement Modal */}
      {showStockModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className={`w-full max-w-md rounded-2xl border shadow-2xl ${dark ? 'bg-dark-800 border-dark-600' : 'bg-white border-gray-200'}`}>
            <div className={`flex items-center justify-between p-5 border-b ${dark ? 'border-dark-600' : 'border-gray-100'}`}>
              <div>
                <h2 className={`font-display font-bold text-lg ${dark ? 'text-white' : 'text-gray-900'}`}>Stock Movement</h2>
                <p className={`text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{showStockModal.name} · Current: <strong>{showStockModal.current_stock} {showStockModal.unit}</strong></p>
              </div>
              <button onClick={() => setShowStockModal(null)} className={`p-2 rounded-xl ${dark ? 'hover:bg-dark-700 text-dark-400' : 'hover:bg-gray-100 text-gray-400'}`}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className={labelCls}>Movement Type</label>
                <div className="flex gap-2">
                  {[['IN', 'Stock In (Purchase)', 'green'], ['OUT', 'Stock Out (Used)', 'red'], ['RETURN_IN', 'Return In', 'blue'], ['ADJUSTMENT', 'Adjustment', 'amber']].map(([v, label, c]) => (
                    <button key={v} onClick={() => setStockForm(f => ({ ...f, movement_type: v }))}
                      className={`flex-1 py-2 rounded-xl text-xs font-semibold border transition-colors
                        ${stockForm.movement_type === v
                          ? `bg-${c}-500/20 text-${c}-400 border-${c}-500/40`
                          : dark ? 'bg-dark-700 text-dark-400 border-dark-600 hover:border-dark-500' : 'bg-gray-50 text-gray-500 border-gray-200'}`}>
                      {label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelCls}>Quantity *</label>
                  <input type="number" min="0.01" step="0.01" value={stockForm.quantity}
                    onChange={e => setStockForm(f => ({ ...f, quantity: parseFloat(e.target.value) || 0 }))}
                    className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>Unit Price (₹)</label>
                  <input type="number" min="0" value={stockForm.unit_price}
                    onChange={e => setStockForm(f => ({ ...f, unit_price: parseFloat(e.target.value) || 0 }))}
                    className={inputCls} />
                </div>
              </div>
              <div>
                <label className={labelCls}>Vendor / Source</label>
                <input value={stockForm.vendor_name} onChange={e => setStockForm(f => ({ ...f, vendor_name: e.target.value }))} className={inputCls} placeholder="Vendor or source name" />
              </div>
              <div>
                <label className={labelCls}>Notes</label>
                <textarea value={stockForm.notes} onChange={e => setStockForm(f => ({ ...f, notes: e.target.value }))} rows={2} className={`${inputCls} resize-none`} />
              </div>
              <div className={`p-3 rounded-xl ${dark ? 'bg-dark-700/50' : 'bg-gray-50'}`}>
                <p className={`text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>New stock will be: <strong className={dark ? 'text-white' : 'text-gray-900'}>
                  {['IN', 'PURCHASE', 'RETURN_IN', 'OPENING'].includes(stockForm.movement_type)
                    ? showStockModal.current_stock + (parseFloat(stockForm.quantity) || 0)
                    : showStockModal.current_stock - (parseFloat(stockForm.quantity) || 0)} {showStockModal.unit}
                </strong></p>
              </div>
            </div>
            <div className={`flex gap-3 p-5 border-t ${dark ? 'border-dark-600' : 'border-gray-100'}`}>
              <button onClick={() => setShowStockModal(null)} className={`flex-1 py-2 rounded-xl text-sm font-medium border transition-colors ${dark ? 'border-dark-600 text-dark-300 hover:bg-dark-700' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}>
                Cancel
              </button>
              <button onClick={handleStockMovement} disabled={saving} className="flex-1 py-2 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-sm font-semibold transition-colors flex items-center justify-center gap-2">
                {saving && <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
                Update Stock
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add/Edit Item Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className={`w-full max-w-2xl rounded-2xl border shadow-2xl max-h-[90vh] overflow-y-auto ${dark ? 'bg-dark-800 border-dark-600' : 'bg-white border-gray-200'}`}>
            <div className={`flex items-center justify-between p-5 border-b sticky top-0 z-10 ${dark ? 'bg-dark-800 border-dark-600' : 'bg-white border-gray-100'}`}>
              <h2 className={`font-display font-bold text-lg ${dark ? 'text-white' : 'text-gray-900'}`}>{editItem ? 'Edit Item' : 'Add Inventory Item'}</h2>
              <button onClick={() => setShowModal(false)} className={`p-2 rounded-xl ${dark ? 'hover:bg-dark-700 text-dark-400' : 'hover:bg-gray-100 text-gray-400'}`}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2"><label className={labelCls}>Item Name *</label><input value={form.name} onChange={f('name')} className={inputCls} placeholder="Item name" /></div>
                <div>
                  <label className={labelCls}>Category *</label>
                  <select value={form.category_id} onChange={f('category_id')} className={inputCls}>
                    <option value="">Select category</option>
                    {CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.icon} {c.name}</option>)}
                  </select>
                </div>
                <div><label className={labelCls}>SKU / Code</label><input value={form.sku} onChange={f('sku')} className={`${inputCls} font-mono`} placeholder="Auto or custom" /></div>
                <div>
                  <label className={labelCls}>Unit</label>
                  <select value={form.unit} onChange={f('unit')} className={inputCls}>
                    {['NOS', 'PCS', 'PKT', 'SET', 'BOX', 'ROLL', 'SHEET', 'KG', 'GM', 'LTR', 'ML', 'MTR'].map(u => <option key={u} value={u}>{u}</option>)}
                  </select>
                </div>
                <div><label className={labelCls}>Opening Stock</label><input type="number" value={form.current_stock} onChange={f('current_stock')} className={inputCls} /></div>
                <div><label className={labelCls}>Min Stock Level</label><input type="number" value={form.min_stock_level} onChange={f('min_stock_level')} className={inputCls} /></div>
                <div><label className={labelCls}>Reorder Point</label><input type="number" value={form.reorder_point} onChange={f('reorder_point')} className={inputCls} /></div>
                <div><label className={labelCls}>Purchase Price (₹)</label><input type="number" value={form.purchase_price} onChange={f('purchase_price')} className={inputCls} /></div>
                <div><label className={labelCls}>Selling Price (₹)</label><input type="number" value={form.selling_price} onChange={f('selling_price')} className={inputCls} /></div>
                <div><label className={labelCls}>HSN/SAC Code</label><input value={form.hsn_sac} onChange={f('hsn_sac')} className={`${inputCls} font-mono`} /></div>
                <div>
                  <label className={labelCls}>GST Rate (%)</label>
                  <select value={form.gst_rate} onChange={f('gst_rate')} className={inputCls}>
                    {[0, 5, 12, 18, 28].map(r => <option key={r} value={r}>{r}%</option>)}
                  </select>
                </div>
                <div><label className={labelCls}>Storage Location</label><input value={form.location} onChange={f('location')} className={inputCls} placeholder="e.g. Shelf A-3" /></div>
                <div><label className={labelCls}>Serial Number</label><input value={form.serial_number} onChange={f('serial_number')} className={`${inputCls} font-mono`} /></div>
                <div className="col-span-2 flex items-center gap-3 p-3 rounded-xl border border-dashed" style={{ borderColor: dark ? '#334155' : '#e2e8f0' }}>
                  <input type="checkbox" id="is_asset" checked={form.is_asset} onChange={f('is_asset')} className="w-4 h-4 rounded accent-primary-500" />
                  <label htmlFor="is_asset" className={`text-xs font-semibold cursor-pointer ${dark ? 'text-dark-200' : 'text-gray-700'}`}>Track as Fixed Asset (Camera, Lens, Equipment etc.)</label>
                </div>
                {form.is_asset && <div className="col-span-2"><label className={labelCls}>Asset Value (₹)</label><input type="number" value={form.asset_value} onChange={f('asset_value')} className={inputCls} /></div>}
                <div className="col-span-2"><label className={labelCls}>Notes</label><textarea value={form.notes} onChange={f('notes')} rows={2} className={`${inputCls} resize-none`} /></div>
              </div>
            </div>
            <div className={`flex gap-3 p-5 border-t sticky bottom-0 ${dark ? 'bg-dark-800 border-dark-600' : 'bg-white border-gray-100'}`}>
              <button onClick={() => setShowModal(false)} className={`flex-1 py-2 rounded-xl text-sm font-medium border transition-colors ${dark ? 'border-dark-600 text-dark-300 hover:bg-dark-700' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}>Cancel</button>
              <button onClick={handleSave} disabled={saving} className="flex-1 py-2 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-sm font-semibold transition-colors flex items-center justify-center gap-2">
                {saving && <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
                {editItem ? 'Update Item' : 'Add Item'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

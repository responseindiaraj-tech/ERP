import React, { useState, useEffect, useRef } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import { useApp } from '../App';
import { generateInvoicePDF } from '../utils/pdfGenerator';

const fmt = (n) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 2 }).format(n || 0);
const GST_RATES = [0, 5, 12, 18, 28];
const UNITS = ['NOS', 'PCS', 'KG', 'GM', 'LTR', 'ML', 'MTR', 'CM', 'SQ.FT', 'BOX', 'SET', 'ROLL', 'SHEET'];

export default function Invoices() {
  return (
    <Routes>
      <Route path="/" element={<InvoiceList />} />
      <Route path="/new" element={<CreateInvoice />} />
      <Route path="/:id" element={<ViewInvoice />} />
      <Route path="/:id/edit" element={<CreateInvoice />} />
    </Routes>
  );
}

// Invoice List
function InvoiceList() {
  const { theme } = useApp();
  const navigate = useNavigate();
  const dark = theme === 'dark';
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [stats, setStats] = useState({ total: 0, paid: 0, pending: 0, count: 0 });

  useEffect(() => { loadInvoices(); }, [search, statusFilter]);

  const loadInvoices = async () => {
    setLoading(true);
    try {
      let data;
      if (window.electronAPI) {
        data = await window.electronAPI.getInvoices({ search, status: statusFilter });
      } else {
        data = MOCK_INVOICES;
      }
      setInvoices(data);
      const total = data.reduce((s, i) => s + i.grand_total, 0);
      const paid = data.filter(i => i.payment_status === 'PAID').reduce((s, i) => s + i.grand_total, 0);
      const pending = data.filter(i => i.payment_status === 'PENDING').reduce((s, i) => s + i.balance_due, 0);
      setStats({ total, paid, pending, count: data.length });
    } catch { setInvoices(MOCK_INVOICES); }
    setLoading(false);
  };

  const statusColors = {
    PAID: 'bg-green-500/10 text-green-400 border-green-500/20',
    PENDING: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    PARTIAL: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    CANCELLED: 'bg-red-500/10 text-red-400 border-red-500/20',
    DRAFT: 'bg-gray-500/10 text-gray-400 border-gray-500/20',
  };

  return (
    <div className="p-6 space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className={`font-display font-bold text-2xl ${dark ? 'text-white' : 'text-gray-900'}`}>Invoices</h1>
          <p className={`text-sm ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{stats.count} invoices · GST Tax Invoices</p>
        </div>
        <button onClick={() => navigate('/invoices/new')} className="flex items-center gap-2 px-4 py-2 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-sm font-semibold transition-all shadow-lg shadow-primary-500/20">
          <span>+</span> New Invoice
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: 'Total Invoiced', value: fmt(stats.total), color: 'text-primary-400' },
          { label: 'Collected', value: fmt(stats.paid), color: 'text-green-400' },
          { label: 'Outstanding', value: fmt(stats.pending), color: 'text-amber-400' },
          { label: 'Invoice Count', value: stats.count, color: 'text-purple-400' },
        ].map((s, i) => (
          <div key={i} className={`p-4 rounded-xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100'}`}>
            <p className={`text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{s.label}</p>
            <p className={`font-display font-bold text-lg mt-1 ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className={`flex items-center gap-3 p-3 rounded-xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100'}`}>
        <div className="relative flex-1 max-w-sm">
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search invoices, customers..."
            className={`w-full pl-9 pr-4 py-2 rounded-lg text-sm border focus:outline-none focus:border-primary-500 transition-colors allow-select
              ${dark ? 'bg-dark-700 border-dark-600 text-white placeholder-dark-500' : 'bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400'}`} />
          <svg className={`absolute left-3 top-1/2 -translate-y-1/2 ${dark ? 'text-dark-400' : 'text-gray-400'}`} width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        </div>
        {['', 'PAID', 'PENDING', 'PARTIAL', 'DRAFT'].map(s => (
          <button key={s} onClick={() => setStatusFilter(s)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${statusFilter === s ? 'bg-primary-600 text-white' : dark ? 'bg-dark-700 text-dark-400 hover:text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
            {s || 'All'}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className={`rounded-2xl border overflow-hidden ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
        <table className="w-full">
          <thead>
            <tr className={`border-b text-xs font-semibold ${dark ? 'bg-dark-700/50 border-dark-600 text-dark-400' : 'bg-gray-50 border-gray-100 text-gray-500'}`}>
              <th className="text-left px-4 py-3">Invoice #</th>
              <th className="text-left px-4 py-3">Date</th>
              <th className="text-left px-4 py-3">Customer</th>
              <th className="text-right px-4 py-3">Amount</th>
              <th className="text-right px-4 py-3">Balance</th>
              <th className="text-center px-4 py-3">Status</th>
              <th className="text-center px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody className={`divide-y ${dark ? 'divide-dark-700/50' : 'divide-gray-50'}`}>
            {loading ? (
              <tr><td colSpan={7} className="text-center py-12"><div className="w-6 h-6 border-2 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto" /></td></tr>
            ) : invoices.length === 0 ? (
              <tr><td colSpan={7} className={`text-center py-12 text-sm ${dark ? 'text-dark-400' : 'text-gray-400'}`}>No invoices found</td></tr>
            ) : invoices.map(inv => (
              <tr key={inv.id} className={`transition-colors cursor-pointer ${dark ? 'hover:bg-dark-700/30' : 'hover:bg-gray-50/80'}`} onClick={() => navigate(`/invoices/${inv.id}`)}>
                <td className={`px-4 py-3 text-xs font-mono font-semibold ${dark ? 'text-primary-400' : 'text-primary-600'}`}>{inv.invoice_number}</td>
                <td className={`px-4 py-3 text-xs ${dark ? 'text-dark-300' : 'text-gray-600'}`}>{inv.invoice_date}</td>
                <td className={`px-4 py-3 text-xs font-medium ${dark ? 'text-white' : 'text-gray-900'}`}>{inv.customer_name}</td>
                <td className={`px-4 py-3 text-xs text-right font-semibold ${dark ? 'text-white' : 'text-gray-900'}`}>{fmt(inv.grand_total)}</td>
                <td className={`px-4 py-3 text-xs text-right ${inv.balance_due > 0 ? 'text-amber-400 font-semibold' : dark ? 'text-dark-400' : 'text-gray-400'}`}>{fmt(inv.balance_due)}</td>
                <td className="px-4 py-3 text-center">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${statusColors[inv.payment_status] || statusColors.PENDING}`}>
                    {inv.payment_status}
                  </span>
                </td>
                <td className="px-4 py-3 text-center" onClick={e => e.stopPropagation()}>
                  <div className="flex items-center justify-center gap-1">
                    <button onClick={() => navigate(`/invoices/${inv.id}`)} className={`p-1.5 rounded-lg transition-colors ${dark ? 'hover:bg-dark-600 text-dark-400 hover:text-white' : 'hover:bg-gray-100 text-gray-400 hover:text-gray-700'}`} title="View">
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                    </button>
                    <button onClick={() => navigate(`/invoices/${inv.id}/edit`)} className={`p-1.5 rounded-lg transition-colors ${dark ? 'hover:bg-dark-600 text-dark-400 hover:text-blue-400' : 'hover:bg-gray-100 text-gray-400 hover:text-blue-600'}`} title="Edit">
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// Create / Edit Invoice
function CreateInvoice() {
  const { theme, addNotification, settings } = useApp();
  const navigate = useNavigate();
  const dark = theme === 'dark';
  const [saving, setSaving] = useState(false);
  const [customerSearch, setCustomerSearch] = useState('');
  const [customerResults, setCustomerResults] = useState([]);
  const [showCustomerDrop, setShowCustomerDrop] = useState(false);

  const [form, setForm] = useState({
    invoice_number: '', invoice_date: new Date().toISOString().split('T')[0],
    due_date: '', customer_id: '', customer_name: '', customer_gstin: '',
    billing_address: '', shipping_address: '', place_of_supply: 'West Bengal',
    supply_type: 'B2B', transport_name: '', vehicle_number: '', lr_number: '',
    eway_bill: '', delivery_date: '', payment_mode: 'BANK_TRANSFER',
    payment_status: 'PENDING', notes: '',
    terms_conditions: '1. Goods once sold will not be taken back.\n2. Interest @ 18% p.a. will be charged on overdue payments.',
  });

  const [items, setItems] = useState([
    { item_name: '', description: '', hsn_sac: '', quantity: 1, unit: 'NOS', rate: 0, discount_percent: 0, gst_rate: 18, supply_type: 'intrastate' }
  ]);

  useEffect(() => {
    loadNextInvoiceNumber();
  }, []);

  const loadNextInvoiceNumber = async () => {
    if (window.electronAPI) {
      const num = await window.electronAPI.getNextInvoiceNumber();
      setForm(f => ({ ...f, invoice_number: num }));
    } else {
      setForm(f => ({ ...f, invoice_number: 'BIC/2024-25/0046' }));
    }
  };

  const searchCustomers = async (q) => {
    setCustomerSearch(q);
    if (!q) { setCustomerResults([]); setShowCustomerDrop(false); return; }
    try {
      const r = window.electronAPI
        ? await window.electronAPI.searchCustomers(q)
        : MOCK_CUSTOMERS.filter(c => c.name.toLowerCase().includes(q.toLowerCase()));
      setCustomerResults(r);
      setShowCustomerDrop(r.length > 0);
    } catch {}
  };

  const selectCustomer = (c) => {
    setForm(f => ({
      ...f, customer_id: c.id, customer_name: c.name,
      customer_gstin: c.gstin || '',
      billing_address: `${c.name}\n${c.address_line1 || ''}\n${c.city || ''}, ${c.state || ''} - ${c.pincode || ''}`.trim(),
      shipping_address: `${c.name}\n${c.address_line1 || ''}\n${c.city || ''}, ${c.state || ''} - ${c.pincode || ''}`.trim(),
    }));
    setCustomerSearch(c.name);
    setShowCustomerDrop(false);
    setCustomerResults([]);
  };

  const calcItem = (item) => {
    const qty = parseFloat(item.quantity) || 0;
    const rate = parseFloat(item.rate) || 0;
    const discPct = parseFloat(item.discount_percent) || 0;
    const gross = qty * rate;
    const discAmt = (gross * discPct) / 100;
    const taxable = gross - discAmt;
    const gst = parseFloat(item.gst_rate) || 18;
    const isInter = form.supply_type === 'B2C' || (form.customer_gstin && form.customer_gstin.slice(0, 2) !== '19');
    const cgst = isInter ? 0 : taxable * (gst / 200);
    const sgst = isInter ? 0 : taxable * (gst / 200);
    const igst = isInter ? taxable * (gst / 100) : 0;
    return { ...item, discount_amount: discAmt, taxable_amount: taxable, cgst_rate: isInter ? 0 : gst / 2, sgst_rate: isInter ? 0 : gst / 2, igst_rate: isInter ? gst : 0, cgst_amount: cgst, sgst_amount: sgst, igst_amount: igst, total_amount: taxable + cgst + sgst + igst };
  };

  const calcItems = items.map(calcItem);

  const totals = calcItems.reduce((acc, i) => ({
    subtotal: acc.subtotal + (i.taxable_amount || 0),
    cgst: acc.cgst + (i.cgst_amount || 0),
    sgst: acc.sgst + (i.sgst_amount || 0),
    igst: acc.igst + (i.igst_amount || 0),
    total: acc.total + (i.total_amount || 0),
  }), { subtotal: 0, cgst: 0, sgst: 0, igst: 0, total: 0 });

  const roundOff = Math.round(totals.total) - totals.total;
  const grandTotal = Math.round(totals.total);

  const addItem = () => setItems(i => [...i, { item_name: '', description: '', hsn_sac: '', quantity: 1, unit: 'NOS', rate: 0, discount_percent: 0, gst_rate: 18 }]);
  const removeItem = (idx) => setItems(i => i.filter((_, j) => j !== idx));
  const updateItem = (idx, field, value) => setItems(i => i.map((item, j) => j === idx ? { ...item, [field]: value } : item));

  const handleSave = async (status = 'FINAL') => {
    if (!form.customer_name) { addNotification('Please select a customer', 'error'); return; }
    if (calcItems.length === 0 || !calcItems[0].item_name) { addNotification('Please add at least one item', 'error'); return; }
    setSaving(true);
    try {
      const payload = {
        ...form, status, items: calcItems,
        subtotal: totals.subtotal, cgst_amount: totals.cgst, sgst_amount: totals.sgst,
        igst_amount: totals.igst, total_tax: totals.cgst + totals.sgst + totals.igst,
        round_off: roundOff, grand_total: grandTotal, balance_due: grandTotal,
      };
      const result = window.electronAPI
        ? await window.electronAPI.createInvoice(payload)
        : { success: true, id: 999, invoice_number: form.invoice_number };
      if (result.success) {
        addNotification(`Invoice ${result.invoice_number} created!`, 'success');
        navigate(`/invoices/${result.id}`);
      }
    } catch (err) { addNotification('Error saving invoice', 'error'); }
    setSaving(false);
  };

  const inputCls = `w-full px-3 py-2 rounded-xl text-sm border focus:outline-none focus:border-primary-500 transition-colors allow-select
    ${dark ? 'bg-dark-700 border-dark-600 text-white placeholder-dark-500' : 'bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400'}`;

  const labelCls = `block text-xs font-semibold mb-1.5 ${dark ? 'text-dark-300' : 'text-gray-600'}`;

  return (
    <div className="p-6 space-y-4 animate-fade-in max-w-6xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/invoices')} className={`p-2 rounded-xl transition-colors ${dark ? 'hover:bg-dark-700 text-dark-400' : 'hover:bg-gray-100 text-gray-500'}`}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15,18 9,12 15,6"/></svg>
          </button>
          <div>
            <h1 className={`font-display font-bold text-xl ${dark ? 'text-white' : 'text-gray-900'}`}>New GST Invoice</h1>
            <p className={`text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>Tax Invoice in Indian Format</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => handleSave('DRAFT')} disabled={saving}
            className={`px-4 py-2 rounded-xl text-sm font-medium border transition-colors ${dark ? 'border-dark-600 text-dark-300 hover:bg-dark-700' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}>
            Save Draft
          </button>
          <button onClick={() => handleSave('FINAL')} disabled={saving}
            className="px-4 py-2 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-sm font-semibold transition-colors shadow-lg shadow-primary-500/20 flex items-center gap-2">
            {saving && <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
            Create Invoice
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {/* Left Column - Invoice Details */}
        <div className={`col-span-2 space-y-4`}>
          {/* Invoice Info */}
          <div className={`p-5 rounded-2xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
            <h3 className={`font-semibold text-sm mb-4 ${dark ? 'text-white' : 'text-gray-900'}`}>Invoice Details</h3>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className={labelCls}>Invoice Number</label>
                <input value={form.invoice_number} onChange={e => setForm(f => ({ ...f, invoice_number: e.target.value }))} className={inputCls} />
              </div>
              <div>
                <label className={labelCls}>Invoice Date *</label>
                <input type="date" value={form.invoice_date} onChange={e => setForm(f => ({ ...f, invoice_date: e.target.value }))} className={inputCls} />
              </div>
              <div>
                <label className={labelCls}>Due Date</label>
                <input type="date" value={form.due_date} onChange={e => setForm(f => ({ ...f, due_date: e.target.value }))} className={inputCls} />
              </div>
              <div>
                <label className={labelCls}>Supply Type</label>
                <select value={form.supply_type} onChange={e => setForm(f => ({ ...f, supply_type: e.target.value }))} className={inputCls}>
                  <option value="B2B">B2B (Registered)</option>
                  <option value="B2C">B2C (Unregistered)</option>
                  <option value="EXPORT">Export</option>
                </select>
              </div>
              <div>
                <label className={labelCls}>Payment Mode</label>
                <select value={form.payment_mode} onChange={e => setForm(f => ({ ...f, payment_mode: e.target.value }))} className={inputCls}>
                  <option value="CASH">Cash</option>
                  <option value="BANK_TRANSFER">Bank Transfer</option>
                  <option value="CHEQUE">Cheque</option>
                  <option value="UPI">UPI</option>
                  <option value="CREDIT">Credit</option>
                </select>
              </div>
              <div>
                <label className={labelCls}>Place of Supply</label>
                <input value={form.place_of_supply} onChange={e => setForm(f => ({ ...f, place_of_supply: e.target.value }))} className={inputCls} placeholder="West Bengal" />
              </div>
            </div>
          </div>

          {/* Customer */}
          <div className={`p-5 rounded-2xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
            <h3 className={`font-semibold text-sm mb-4 ${dark ? 'text-white' : 'text-gray-900'}`}>Customer Details</h3>
            <div className="grid grid-cols-2 gap-3">
              <div className="relative">
                <label className={labelCls}>Customer Name *</label>
                <input value={customerSearch || form.customer_name}
                  onChange={e => searchCustomers(e.target.value)}
                  onFocus={() => customerSearch && setShowCustomerDrop(customerResults.length > 0)}
                  placeholder="Search customer..."
                  className={inputCls} />
                {showCustomerDrop && (
                  <div className={`absolute top-full left-0 right-0 mt-1 rounded-xl border shadow-lg z-20 max-h-40 overflow-y-auto ${dark ? 'bg-dark-800 border-dark-600' : 'bg-white border-gray-200'}`}>
                    {customerResults.map(c => (
                      <button key={c.id} onClick={() => selectCustomer(c)} className={`w-full text-left px-3 py-2 text-xs transition-colors ${dark ? 'hover:bg-dark-700 text-white' : 'hover:bg-gray-50 text-gray-900'}`}>
                        <div className="font-medium">{c.name}</div>
                        {c.company_name && <div className={dark ? 'text-dark-400' : 'text-gray-500'}>{c.company_name}</div>}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div>
                <label className={labelCls}>Customer GSTIN</label>
                <input value={form.customer_gstin} onChange={e => setForm(f => ({ ...f, customer_gstin: e.target.value.toUpperCase() }))} className={`${inputCls} font-mono`} placeholder="22AAAAA0000A1Z5" maxLength={15} />
              </div>
              <div className="col-span-2">
                <label className={labelCls}>Billing Address</label>
                <textarea value={form.billing_address} onChange={e => setForm(f => ({ ...f, billing_address: e.target.value }))} rows={2} className={`${inputCls} resize-none`} />
              </div>
              <div className="col-span-2">
                <label className={labelCls}>Delivery / Shipping Address</label>
                <textarea value={form.shipping_address} onChange={e => setForm(f => ({ ...f, shipping_address: e.target.value }))} rows={2} className={`${inputCls} resize-none`} />
              </div>
            </div>
          </div>

          {/* Items */}
          <div className={`p-5 rounded-2xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
            <div className="flex items-center justify-between mb-4">
              <h3 className={`font-semibold text-sm ${dark ? 'text-white' : 'text-gray-900'}`}>Line Items</h3>
              <button onClick={addItem} className="flex items-center gap-1 px-3 py-1.5 bg-primary-600/10 hover:bg-primary-600/20 text-primary-400 border border-primary-500/30 rounded-lg text-xs font-medium transition-colors">
                + Add Item
              </button>
            </div>

            <div className="space-y-2">
              {/* Header */}
              <div className={`grid text-[10px] font-bold px-2 ${dark ? 'text-dark-400' : 'text-gray-400'}`}
                style={{ gridTemplateColumns: '2fr 0.8fr 0.8fr 1fr 0.8fr 0.7fr 0.8fr 0.4fr' }}>
                <span>Item / Service</span><span>HSN/SAC</span><span>Qty</span><span className="text-right">Rate (₹)</span><span className="text-right">Disc%</span><span className="text-right">GST%</span><span className="text-right">Amount</span><span></span>
              </div>

              {items.map((item, idx) => {
                const calc = calcItem(item);
                return (
                  <div key={idx} className={`grid gap-2 p-2 rounded-xl items-center ${dark ? 'bg-dark-700/50' : 'bg-gray-50'}`}
                    style={{ gridTemplateColumns: '2fr 0.8fr 0.8fr 1fr 0.8fr 0.7fr 0.8fr 0.4fr' }}>
                    <input value={item.item_name} onChange={e => updateItem(idx, 'item_name', e.target.value)} placeholder="Item name"
                      className={`${inputCls} py-1.5 text-xs`} />
                    <input value={item.hsn_sac} onChange={e => updateItem(idx, 'hsn_sac', e.target.value)} placeholder="HSN"
                      className={`${inputCls} py-1.5 text-xs font-mono`} />
                    <input type="number" value={item.quantity} onChange={e => updateItem(idx, 'quantity', e.target.value)} min="0"
                      className={`${inputCls} py-1.5 text-xs text-right`} />
                    <input type="number" value={item.rate} onChange={e => updateItem(idx, 'rate', e.target.value)} min="0"
                      className={`${inputCls} py-1.5 text-xs text-right`} />
                    <input type="number" value={item.discount_percent} onChange={e => updateItem(idx, 'discount_percent', e.target.value)} min="0" max="100"
                      className={`${inputCls} py-1.5 text-xs text-right`} />
                    <select value={item.gst_rate} onChange={e => updateItem(idx, 'gst_rate', parseFloat(e.target.value))}
                      className={`${inputCls} py-1.5 text-xs`}>
                      {GST_RATES.map(r => <option key={r} value={r}>{r}%</option>)}
                    </select>
                    <div className={`text-xs text-right font-semibold ${dark ? 'text-white' : 'text-gray-900'}`}>
                      {new Intl.NumberFormat('en-IN').format(calc.total_amount.toFixed(2))}
                    </div>
                    {items.length > 1 && (
                      <button onClick={() => removeItem(idx)} className="flex justify-center text-red-400 hover:text-red-300 transition-colors">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-4">
          {/* Totals */}
          <div className={`p-5 rounded-2xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
            <h3 className={`font-semibold text-sm mb-4 ${dark ? 'text-white' : 'text-gray-900'}`}>Invoice Summary</h3>
            <div className="space-y-2">
              {[
                ['Subtotal (Taxable)', totals.subtotal],
                ...(totals.cgst > 0 ? [['CGST', totals.cgst]] : []),
                ...(totals.sgst > 0 ? [['SGST', totals.sgst]] : []),
                ...(totals.igst > 0 ? [['IGST', totals.igst]] : []),
                ...(roundOff !== 0 ? [['Round Off', roundOff]] : []),
              ].map(([label, val]) => (
                <div key={label} className="flex justify-between text-xs">
                  <span className={dark ? 'text-dark-400' : 'text-gray-500'}>{label}</span>
                  <span className={dark ? 'text-dark-200' : 'text-gray-700'}>{fmt(val)}</span>
                </div>
              ))}
              <div className={`flex justify-between pt-2 border-t font-bold ${dark ? 'border-dark-600 text-white' : 'border-gray-100 text-gray-900'}`}>
                <span>Grand Total</span>
                <span className="text-lg text-primary-400">{fmt(grandTotal)}</span>
              </div>
            </div>
          </div>

          {/* Transport */}
          <div className={`p-5 rounded-2xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
            <h3 className={`font-semibold text-sm mb-4 ${dark ? 'text-white' : 'text-gray-900'}`}>Transport Details</h3>
            <div className="space-y-3">
              {[
                ['Logistics Company', 'transport_name', 'text', 'DHL / DTDC...'],
                ['Vehicle Number', 'vehicle_number', 'text', 'WB 12A 1234'],
                ['LR Number', 'lr_number', 'text', 'LR-000000'],
                ['E-Way Bill #', 'eway_bill', 'text', 'E-way bill number'],
                ['Delivery Date', 'delivery_date', 'date', ''],
              ].map(([label, field, type, placeholder]) => (
                <div key={field}>
                  <label className={labelCls}>{label}</label>
                  <input type={type} value={form[field]} onChange={e => setForm(f => ({ ...f, [field]: e.target.value }))}
                    placeholder={placeholder} className={inputCls} />
                </div>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div className={`p-5 rounded-2xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
            <h3 className={`font-semibold text-sm mb-3 ${dark ? 'text-white' : 'text-gray-900'}`}>Notes & Terms</h3>
            <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={2}
              placeholder="Additional notes..." className={`${inputCls} resize-none mb-2`} />
            <textarea value={form.terms_conditions} onChange={e => setForm(f => ({ ...f, terms_conditions: e.target.value }))} rows={3}
              placeholder="Terms & Conditions..." className={`${inputCls} resize-none text-xs`} />
          </div>
        </div>
      </div>
    </div>
  );
}

// View Invoice
function ViewInvoice() {
  const { theme, addNotification, settings } = useApp();
  const navigate = useNavigate();
  const dark = theme === 'dark';
  const [invoice, setInvoice] = useState(null);
  const invoiceId = window.location.hash.split('/')[2];

  useEffect(() => {
    loadInvoice();
  }, [invoiceId]);

  const loadInvoice = async () => {
    try {
      const data = window.electronAPI
        ? await window.electronAPI.getInvoice(parseInt(invoiceId))
        : MOCK_INVOICES_DETAIL[0];
      setInvoice(data);
    } catch { setInvoice(MOCK_INVOICES_DETAIL[0]); }
  };

  const handlePrint = async () => {
    if (!invoice) return;
    try {
      await generateInvoicePDF(invoice, settings);
      addNotification('PDF generated successfully!', 'success');
    } catch (err) {
      addNotification('Error generating PDF: ' + err.message, 'error');
    }
  };

  if (!invoice) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  const fmt2 = (n) => new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n || 0);
  const statusColors = { PAID: 'text-green-400 bg-green-500/10 border-green-500/20', PENDING: 'text-amber-400 bg-amber-500/10 border-amber-500/20', PARTIAL: 'text-blue-400 bg-blue-500/10 border-blue-500/20' };

  return (
    <div className="p-6 animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/invoices')} className={`p-2 rounded-xl transition-colors ${dark ? 'hover:bg-dark-700 text-dark-400' : 'hover:bg-gray-100 text-gray-500'}`}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15,18 9,12 15,6"/></svg>
          </button>
          <div>
            <h1 className={`font-display font-bold text-xl ${dark ? 'text-white' : 'text-gray-900'}`}>{invoice.invoice_number}</h1>
            <span className={`text-xs font-bold px-2 py-0.5 rounded-md border ${statusColors[invoice.payment_status] || statusColors.PENDING}`}>
              {invoice.payment_status}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => navigate(`/invoices/${invoiceId}/edit`)} className={`px-4 py-2 rounded-xl text-sm font-medium border transition-colors ${dark ? 'border-dark-600 text-dark-300 hover:bg-dark-700' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}>
            Edit
          </button>
          <button onClick={handlePrint} className="flex items-center gap-2 px-4 py-2 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-sm font-semibold transition-colors shadow-lg shadow-primary-500/20">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="6,9 6,2 18,2 18,9"/><path d="M6,18H4a2,2,0,0,1-2-2V11a2,2,0,0,1,2-2H20a2,2,0,0,1,2,2v5a2,2,0,0,1-2,2H18"/><rect x="6" y="14" width="12" height="8"/></svg>
            Download PDF
          </button>
        </div>
      </div>

      {/* Invoice Preview */}
      <div className={`max-w-4xl rounded-2xl border overflow-hidden ${dark ? 'bg-dark-800 border-dark-600' : 'bg-white border-gray-200 shadow-sm'}`}>
        {/* Invoice Header */}
        <div className={`p-6 border-b ${dark ? 'bg-dark-700/50 border-dark-600' : 'bg-gray-50 border-gray-100'}`}>
          <div className="flex justify-between">
            <div>
              <h2 className={`font-display font-bold text-2xl ${dark ? 'text-white' : 'text-gray-900'}`}>TAX INVOICE</h2>
              <p className={`text-xs mt-1 ${dark ? 'text-dark-400' : 'text-gray-500'}`}>Original for Recipient</p>
            </div>
            <div className="text-right">
              <div className="w-12 h-12 rounded-xl bg-primary-600 flex items-center justify-center mb-2 ml-auto">
                <span className="text-white font-display font-bold">BIC</span>
              </div>
              <p className={`font-display font-bold text-sm ${dark ? 'text-white' : 'text-gray-900'}`}>BIC Industries Private Limited</p>
              <p className={`text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{settings?.address}</p>
              <p className={`text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>GSTIN: {settings?.gstin}</p>
            </div>
          </div>
        </div>

        <div className="p-6">
          {/* Invoice Meta */}
          <div className="grid grid-cols-2 gap-6 mb-6">
            <div>
              <p className={`text-xs font-bold mb-1 ${dark ? 'text-dark-400' : 'text-gray-400'}`}>BILL TO</p>
              <p className={`font-semibold text-sm ${dark ? 'text-white' : 'text-gray-900'}`}>{invoice.customer_name}</p>
              <p className={`text-xs whitespace-pre-line ${dark ? 'text-dark-300' : 'text-gray-600'}`}>{invoice.billing_address}</p>
              {invoice.customer_gstin && <p className={`text-xs font-mono mt-1 ${dark ? 'text-dark-300' : 'text-gray-600'}`}>GSTIN: {invoice.customer_gstin}</p>}
            </div>
            <div className="text-right">
              <div className="space-y-1">
                {[
                  ['Invoice No.', invoice.invoice_number],
                  ['Date', invoice.invoice_date],
                  ['Due Date', invoice.due_date || '-'],
                  ['Payment', invoice.payment_mode],
                ].map(([k, v]) => (
                  <div key={k} className="flex justify-between gap-4 text-xs">
                    <span className={dark ? 'text-dark-400' : 'text-gray-500'}>{k}:</span>
                    <span className={`font-medium ${dark ? 'text-white' : 'text-gray-900'}`}>{v}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Items Table */}
          <table className="w-full text-xs mb-6">
            <thead>
              <tr className={`border-y ${dark ? 'border-dark-600 bg-dark-700/30' : 'border-gray-100 bg-gray-50'}`}>
                <th className={`text-left py-2.5 px-2 font-semibold ${dark ? 'text-dark-300' : 'text-gray-600'}`}>#</th>
                <th className={`text-left py-2.5 px-2 font-semibold ${dark ? 'text-dark-300' : 'text-gray-600'}`}>Item Description</th>
                <th className={`text-center py-2.5 px-2 font-semibold ${dark ? 'text-dark-300' : 'text-gray-600'}`}>HSN</th>
                <th className={`text-center py-2.5 px-2 font-semibold ${dark ? 'text-dark-300' : 'text-gray-600'}`}>Qty</th>
                <th className={`text-right py-2.5 px-2 font-semibold ${dark ? 'text-dark-300' : 'text-gray-600'}`}>Rate</th>
                <th className={`text-right py-2.5 px-2 font-semibold ${dark ? 'text-dark-300' : 'text-gray-600'}`}>Taxable Amt</th>
                <th className={`text-right py-2.5 px-2 font-semibold ${dark ? 'text-dark-300' : 'text-gray-600'}`}>GST</th>
                <th className={`text-right py-2.5 px-2 font-semibold ${dark ? 'text-dark-300' : 'text-gray-600'}`}>Total</th>
              </tr>
            </thead>
            <tbody>
              {(invoice.items || []).map((item, i) => (
                <tr key={i} className={`border-b ${dark ? 'border-dark-700/50' : 'border-gray-50'}`}>
                  <td className={`py-2.5 px-2 ${dark ? 'text-dark-400' : 'text-gray-400'}`}>{i + 1}</td>
                  <td className={`py-2.5 px-2 ${dark ? 'text-white' : 'text-gray-900'}`}>{item.item_name}</td>
                  <td className={`py-2.5 px-2 text-center font-mono ${dark ? 'text-dark-300' : 'text-gray-600'}`}>{item.hsn_sac}</td>
                  <td className={`py-2.5 px-2 text-center ${dark ? 'text-dark-300' : 'text-gray-600'}`}>{item.quantity} {item.unit}</td>
                  <td className={`py-2.5 px-2 text-right ${dark ? 'text-dark-300' : 'text-gray-600'}`}>{fmt2(item.rate)}</td>
                  <td className={`py-2.5 px-2 text-right ${dark ? 'text-dark-300' : 'text-gray-600'}`}>{fmt2(item.taxable_amount)}</td>
                  <td className={`py-2.5 px-2 text-right ${dark ? 'text-dark-300' : 'text-gray-600'}`}>
                    {item.igst_amount > 0 ? `IGST ${fmt2(item.igst_amount)}` : `C+S ${fmt2((item.cgst_amount || 0) + (item.sgst_amount || 0))}`}
                  </td>
                  <td className={`py-2.5 px-2 text-right font-semibold ${dark ? 'text-white' : 'text-gray-900'}`}>{fmt2(item.total_amount)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Totals */}
          <div className="flex justify-end">
            <div className="w-60 space-y-1.5">
              {[
                ['Subtotal', invoice.subtotal],
                ...(invoice.cgst_amount > 0 ? [['CGST', invoice.cgst_amount]] : []),
                ...(invoice.sgst_amount > 0 ? [['SGST', invoice.sgst_amount]] : []),
                ...(invoice.igst_amount > 0 ? [['IGST', invoice.igst_amount]] : []),
                ...(invoice.round_off !== 0 ? [['Round Off', invoice.round_off]] : []),
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between text-xs">
                  <span className={dark ? 'text-dark-400' : 'text-gray-500'}>{k}</span>
                  <span className={dark ? 'text-dark-200' : 'text-gray-700'}>₹{fmt2(v)}</span>
                </div>
              ))}
              <div className={`flex justify-between pt-2 border-t font-bold text-sm ${dark ? 'border-dark-500 text-white' : 'border-gray-200 text-gray-900'}`}>
                <span>Grand Total</span>
                <span className="text-primary-400">₹{fmt2(invoice.grand_total)}</span>
              </div>
            </div>
          </div>

          {/* Transport */}
          {(invoice.transport_name || invoice.vehicle_number || invoice.eway_bill) && (
            <div className={`mt-6 p-4 rounded-xl border ${dark ? 'bg-dark-700/30 border-dark-600' : 'bg-gray-50 border-gray-100'}`}>
              <p className={`text-xs font-bold mb-2 ${dark ? 'text-dark-300' : 'text-gray-500'}`}>TRANSPORT DETAILS</p>
              <div className="grid grid-cols-4 gap-3 text-xs">
                {[['Logistics', invoice.transport_name], ['Vehicle', invoice.vehicle_number], ['LR No.', invoice.lr_number], ['E-Way Bill', invoice.eway_bill]].filter(([, v]) => v).map(([k, v]) => (
                  <div key={k}><span className={dark ? 'text-dark-400' : 'text-gray-400'}>{k}: </span><span className={dark ? 'text-white' : 'text-gray-900'}>{v}</span></div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Mock data for browser preview
const MOCK_INVOICES = [
  { id: 1, invoice_number: 'BIC/2024-25/0045', invoice_date: '2024-05-10', customer_name: 'Sharma Photography', grand_total: 45200, balance_due: 0, payment_status: 'PAID' },
  { id: 2, invoice_number: 'BIC/2024-25/0044', invoice_date: '2024-05-09', customer_name: 'Kolkata Print House', grand_total: 82500, balance_due: 82500, payment_status: 'PENDING' },
  { id: 3, invoice_number: 'BIC/2024-25/0043', invoice_date: '2024-05-08', customer_name: 'Royal Studios', grand_total: 31800, balance_due: 15000, payment_status: 'PARTIAL' },
];
const MOCK_CUSTOMERS = [
  { id: 1, name: 'Sharma Photography', company_name: 'Sharma Photo Studio', gstin: '19ABCDE1234F1Z5', mobile: '9876543210', city: 'Durgapur', state: 'West Bengal', address_line1: '45 Station Road', pincode: '713201' },
  { id: 2, name: 'Kolkata Print House', company_name: 'KPH Pvt Ltd', gstin: '19XYZAA5678B2Z3', mobile: '8765432109', city: 'Kolkata', state: 'West Bengal', address_line1: '12 Park Street', pincode: '700016' },
];
const MOCK_INVOICES_DETAIL = [{
  id: 1, invoice_number: 'BIC/2024-25/0045', invoice_date: '2024-05-10', due_date: '2024-05-25', customer_name: 'Sharma Photography',
  customer_gstin: '19ABCDE1234F1Z5', billing_address: 'Sharma Photography\n45 Station Road\nDurgapur, West Bengal - 713201',
  subtotal: 38305, cgst_amount: 3445, sgst_amount: 3445, igst_amount: 0, total_tax: 6890, round_off: 5, grand_total: 45200,
  balance_due: 0, payment_mode: 'BANK_TRANSFER', payment_status: 'PAID', transport_name: 'DTDC Courier',
  vehicle_number: 'WB 05G 1234', lr_number: 'LR-2024-05001', eway_bill: '431045678901',
  items: [
    { item_name: 'A4 Photo Paper (500 sheets)', hsn_sac: '4802', quantity: 5, unit: 'PKT', rate: 4500, taxable_amount: 22500, gst_rate: 18, cgst_rate: 9, sgst_rate: 9, cgst_amount: 2025, sgst_amount: 2025, igst_amount: 0, total_amount: 26550 },
    { item_name: 'Photo Ink Set (6 Colors)', hsn_sac: '3215', quantity: 3, unit: 'SET', rate: 2600, taxable_amount: 7800, gst_rate: 12, cgst_rate: 6, sgst_rate: 6, cgst_amount: 468, sgst_amount: 468, igst_amount: 0, total_amount: 8736 },
    { item_name: 'Packaging Material', hsn_sac: '4819', quantity: 50, unit: 'NOS', rate: 160, taxable_amount: 8000, gst_rate: 12, cgst_rate: 6, sgst_rate: 6, cgst_amount: 480, sgst_amount: 480, igst_amount: 0, total_amount: 8960 },
  ]
}];

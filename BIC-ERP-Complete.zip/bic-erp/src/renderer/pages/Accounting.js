import React, { useState, useEffect } from 'react';
import { useApp } from '../App';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const fmt = (n) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n || 0);
const fmtShort = (n) => {
  if (Math.abs(n) >= 1e7) return `₹${(n / 1e7).toFixed(2)}Cr`;
  if (Math.abs(n) >= 1e5) return `₹${(n / 1e5).toFixed(2)}L`;
  if (Math.abs(n) >= 1e3) return `₹${(n / 1e3).toFixed(1)}K`;
  return `₹${(n || 0).toFixed(0)}`;
};

const MOCK_PL = {
  period: '2024-25', from: '2024-04-01', to: '2025-03-31',
  totalRevenue: 4850000, gstCollected: 873000,
  expenseBreakdown: [
    { category: 'Inventory Purchase', total: 1820000 },
    { category: 'Salaries & Wages', total: 540000 },
    { category: 'Rent', total: 180000 },
    { category: 'Electricity', total: 98400 },
    { category: 'Transport & Logistics', total: 76000 },
    { category: 'Equipment Maintenance', total: 45000 },
    { category: 'Marketing & Advertising', total: 38000 },
    { category: 'Software & Subscriptions', total: 24000 },
    { category: 'Miscellaneous', total: 62000 },
  ],
  totalExpenses: 2883400, grossProfit: 2850000, netProfit: 1966600, ebitda: 2263090
};

const MOCK_MONTHLY = [
  { month: 4, year: 2024, sales: 380000, expenses: 210000, profit: 170000 },
  { month: 5, year: 2024, sales: 420000, expenses: 235000, profit: 185000 },
  { month: 6, year: 2024, sales: 390000, expenses: 220000, profit: 170000 },
  { month: 7, year: 2024, sales: 450000, expenses: 245000, profit: 205000 },
  { month: 8, year: 2024, sales: 410000, expenses: 228000, profit: 182000 },
  { month: 9, year: 2024, sales: 480000, expenses: 260000, profit: 220000 },
  { month: 10, year: 2024, sales: 435000, expenses: 240000, profit: 195000 },
  { month: 11, year: 2024, sales: 395000, expenses: 215000, profit: 180000 },
  { month: 12, year: 2024, sales: 510000, expenses: 275000, profit: 235000 },
  { month: 1, year: 2025, sales: 425000, expenses: 238000, profit: 187000 },
  { month: 2, year: 2025, sales: 405000, expenses: 222000, profit: 183000 },
  { month: 3, year: 2025, sales: 550000, expenses: 295000, profit: 255000 },
];

const MOCK_BALANCE = {
  assets: { inventory: 289000, fixedAssets: 785000, receivables: 124500, cash: 1966600 },
  liabilities: { gstPayable: 87300, otherPayables: 0 },
  equity: { retainedEarnings: 1966600 }
};

const MOCK_GST = {
  period: { from: '2024-05-01', to: '2024-05-31' },
  outward: { cgst: 145000, sgst: 145000, igst: 0, total: 290000 },
  inwardGST: 85000,
  netGSTPayable: 205000
};

const MONTHS = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'];

export default function Accounting() {
  const { theme } = useApp();
  const dark = theme === 'dark';
  const [activeTab, setActiveTab] = useState('pl');
  const [plData, setPlData] = useState(null);
  const [monthlyData, setMonthlyData] = useState([]);
  const [balanceData, setBalanceData] = useState(null);
  const [gstData, setGstData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [fy, setFy] = useState('2024-25');
  const [gstPeriod, setGstPeriod] = useState({ from: new Date().toISOString().slice(0, 8) + '01', to: new Date().toISOString().split('T')[0] });

  useEffect(() => { loadData(); }, [activeTab, fy]);

  const loadData = async () => {
    setLoading(true);
    try {
      if (window.electronAPI) {
        if (activeTab === 'pl') setPlData(await window.electronAPI.getProfitLoss(fy));
        if (activeTab === 'monthly') setMonthlyData(await window.electronAPI.getMonthlySummary(fy.split('-')[0]));
        if (activeTab === 'balance') setBalanceData(await window.electronAPI.getBalanceSheet());
        if (activeTab === 'gst') setGstData(await window.electronAPI.getGSTReport([gstPeriod.from, gstPeriod.to]));
      } else {
        setPlData(MOCK_PL); setMonthlyData(MOCK_MONTHLY); setBalanceData(MOCK_BALANCE); setGstData(MOCK_GST);
      }
    } catch { setPlData(MOCK_PL); setMonthlyData(MOCK_MONTHLY); setBalanceData(MOCK_BALANCE); setGstData(MOCK_GST); }
    setLoading(false);
  };

  const chartColors = dark ? { grid: '#1e293b', text: '#64748b' } : { grid: '#e2e8f0', text: '#94a3b8' };
  const cardCls = `rounded-2xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`;
  const secTitle = `font-display font-bold text-base mb-4 ${dark ? 'text-white' : 'text-gray-900'}`;
  const rowCls = `flex justify-between py-2 border-b text-xs ${dark ? 'border-dark-700/50' : 'border-gray-50'}`;
  const kCls = dark ? 'text-dark-400' : 'text-gray-500';
  const vCls = `font-semibold ${dark ? 'text-white' : 'text-gray-900'}`;

  const tabs = [
    { id: 'pl', label: '📊 Profit & Loss' },
    { id: 'monthly', label: '📅 Monthly Summary' },
    { id: 'balance', label: '⚖️ Balance Sheet' },
    { id: 'gst', label: '🏛️ GST Report' },
  ];

  return (
    <div className="p-6 space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className={`font-display font-bold text-2xl ${dark ? 'text-white' : 'text-gray-900'}`}>Accounting & Reports</h1>
          <p className={`text-sm ${dark ? 'text-dark-400' : 'text-gray-500'}`}>Financial statements and GST reports</p>
        </div>
        <div className="flex items-center gap-2">
          <select value={fy} onChange={e => setFy(e.target.value)}
            className={`px-3 py-2 rounded-xl text-xs border focus:outline-none ${dark ? 'bg-dark-800 border-dark-600 text-white' : 'bg-white border-gray-200 text-gray-900'}`}>
            {['2024-25', '2023-24', '2022-23'].map(y => <option key={y} value={y}>FY {y}</option>)}
          </select>
        </div>
      </div>

      {/* Tabs */}
      <div className={`flex gap-1 p-1 rounded-xl border w-fit ${dark ? 'bg-dark-800 border-dark-600' : 'bg-gray-100 border-gray-200'}`}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${activeTab === t.id ? 'bg-primary-600 text-white shadow' : dark ? 'text-dark-400 hover:text-white' : 'text-gray-500 hover:text-gray-900'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="w-8 h-8 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (
        <>
          {/* Profit & Loss */}
          {activeTab === 'pl' && plData && (
            <div className="grid grid-cols-3 gap-4">
              {/* Key Metrics */}
              <div className="col-span-3 grid grid-cols-5 gap-3">
                {[
                  { label: 'Total Revenue', value: fmtShort(plData.totalRevenue), color: 'text-green-400', bg: 'bg-green-500/10 border-green-500/20' },
                  { label: 'Total Expenses', value: fmtShort(plData.totalExpenses), color: 'text-red-400', bg: 'bg-red-500/10 border-red-500/20' },
                  { label: 'Gross Profit', value: fmtShort(plData.grossProfit), color: 'text-blue-400', bg: 'bg-blue-500/10 border-blue-500/20' },
                  { label: 'Net Profit', value: fmtShort(plData.netProfit), color: 'text-primary-400', bg: 'bg-primary-500/10 border-primary-500/20' },
                  { label: 'EBITDA', value: fmtShort(plData.ebitda), color: 'text-purple-400', bg: 'bg-purple-500/10 border-purple-500/20' },
                ].map((m, i) => (
                  <div key={i} className={`p-4 rounded-xl border ${m.bg}`}>
                    <p className={`text-xs font-medium ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{m.label}</p>
                    <p className={`font-display font-bold text-xl mt-1 ${m.color}`}>{m.value}</p>
                    <p className={`text-xs mt-1 ${dark ? 'text-dark-500' : 'text-gray-400'}`}>FY {fy}</p>
                  </div>
                ))}
              </div>

              {/* Income Statement */}
              <div className={`${cardCls} p-5`}>
                <h3 className={secTitle}>Income Statement</h3>
                <div className={`${rowCls} font-semibold`}><span className={dark ? 'text-green-400' : 'text-green-600'}>Gross Revenue</span><span className="text-green-400">{fmt(plData.totalRevenue)}</span></div>
                <div className={rowCls}><span className={kCls}>Less: GST Collected</span><span className={vCls}>({fmt(plData.gstCollected)})</span></div>
                <div className={`${rowCls} font-semibold`}><span className={dark ? 'text-white' : 'text-gray-900'}>Net Revenue (Taxable)</span><span className={vCls}>{fmt(plData.totalRevenue - plData.gstCollected)}</span></div>
                <div className={rowCls}><span className={kCls}>Less: Total Expenses</span><span className="text-red-400">({fmt(plData.totalExpenses)})</span></div>
                <div className={`flex justify-between pt-3 font-bold text-base`}>
                  <span className={dark ? 'text-white' : 'text-gray-900'}>Net Profit</span>
                  <span className={plData.netProfit >= 0 ? 'text-green-400' : 'text-red-400'}>{fmt(plData.netProfit)}</span>
                </div>
                <div className="mt-3 pt-3 border-t border-dashed" style={{ borderColor: dark ? '#334155' : '#e2e8f0' }}>
                  <div className="flex justify-between text-xs">
                    <span className={kCls}>Profit Margin</span>
                    <span className="text-green-400 font-semibold">{((plData.netProfit / plData.totalRevenue) * 100).toFixed(1)}%</span>
                  </div>
                  <div className="flex justify-between text-xs mt-1">
                    <span className={kCls}>EBITDA Margin</span>
                    <span className="text-purple-400 font-semibold">{((plData.ebitda / plData.totalRevenue) * 100).toFixed(1)}%</span>
                  </div>
                </div>
              </div>

              {/* Expense Breakdown */}
              <div className={`${cardCls} p-5`}>
                <h3 className={secTitle}>Expense Breakdown</h3>
                <div className="space-y-2">
                  {plData.expenseBreakdown.map((e, i) => {
                    const pct = (e.total / plData.totalExpenses) * 100;
                    return (
                      <div key={i}>
                        <div className="flex justify-between text-xs mb-1">
                          <span className={kCls}>{e.category}</span>
                          <span className={vCls}>{fmt(e.total)} <span className="text-dark-500 font-normal">({pct.toFixed(1)}%)</span></span>
                        </div>
                        <div className={`h-1 rounded-full overflow-hidden ${dark ? 'bg-dark-700' : 'bg-gray-100'}`}>
                          <div className="h-full rounded-full" style={{ width: `${pct}%`, background: `hsl(${220 - i * 15}, 70%, 60%)` }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Expense Chart */}
              <div className={`${cardCls} p-5`}>
                <h3 className={secTitle}>Expense Chart</h3>
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={plData.expenseBreakdown} layout="vertical" margin={{ left: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} horizontal={false} />
                    <XAxis type="number" tick={{ fill: chartColors.text, fontSize: 10 }} tickFormatter={v => fmtShort(v)} />
                    <YAxis type="category" dataKey="category" tick={{ fill: chartColors.text, fontSize: 9 }} width={110} />
                    <Tooltip formatter={(v) => [fmt(v)]} contentStyle={{ background: dark ? '#1e293b' : '#fff', border: `1px solid ${dark ? '#334155' : '#e2e8f0'}`, borderRadius: 8, fontSize: 11 }} />
                    <Bar dataKey="total" radius={[0, 4, 4, 0]}>
                      {plData.expenseBreakdown.map((_, i) => (
                        <Cell key={i} fill={`hsl(${220 - i * 15}, 70%, 60%)`} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Monthly Summary */}
          {activeTab === 'monthly' && (
            <div className="space-y-4">
              <div className={`${cardCls} p-5`}>
                <h3 className={secTitle}>Monthly Performance — FY {fy}</h3>
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={monthlyData.map(d => ({ ...d, monthName: MONTHS[d.month - 4 >= 0 ? d.month - 4 : d.month + 8] }))}>
                    <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
                    <XAxis dataKey="monthName" tick={{ fill: chartColors.text, fontSize: 11 }} />
                    <YAxis tick={{ fill: chartColors.text, fontSize: 11 }} tickFormatter={v => fmtShort(v)} />
                    <Tooltip formatter={(v) => [fmt(v)]} contentStyle={{ background: dark ? '#1e293b' : '#fff', border: `1px solid ${dark ? '#334155' : '#e2e8f0'}`, borderRadius: 8, fontSize: 11 }} />
                    <Bar dataKey="sales" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Sales" />
                    <Bar dataKey="expenses" fill="#ef4444" radius={[4, 4, 0, 0]} name="Expenses" />
                    <Bar dataKey="profit" fill="#10b981" radius={[4, 4, 0, 0]} name="Profit" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div className={`${cardCls} overflow-hidden`}>
                <table className="w-full">
                  <thead>
                    <tr className={`border-b text-xs font-semibold ${dark ? 'bg-dark-700/50 border-dark-600 text-dark-400' : 'bg-gray-50 border-gray-100 text-gray-500'}`}>
                      <th className="text-left px-4 py-3">Month</th>
                      <th className="text-right px-4 py-3">Sales</th>
                      <th className="text-right px-4 py-3">GST Collected</th>
                      <th className="text-right px-4 py-3">Expenses</th>
                      <th className="text-right px-4 py-3">Net Profit</th>
                      <th className="text-right px-4 py-3">Margin %</th>
                    </tr>
                  </thead>
                  <tbody className={`divide-y ${dark ? 'divide-dark-700/40' : 'divide-gray-50'}`}>
                    {monthlyData.map((d, i) => {
                      const margin = d.sales > 0 ? ((d.profit / d.sales) * 100).toFixed(1) : '0.0';
                      return (
                        <tr key={i} className={dark ? 'hover:bg-dark-700/30' : 'hover:bg-gray-50'}>
                          <td className={`px-4 py-2.5 text-xs font-semibold ${dark ? 'text-white' : 'text-gray-900'}`}>{MONTHS[d.month - 4 >= 0 ? d.month - 4 : d.month + 8]} {d.year}</td>
                          <td className={`px-4 py-2.5 text-xs text-right text-green-400 font-medium`}>{fmt(d.sales)}</td>
                          <td className={`px-4 py-2.5 text-xs text-right ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{fmt(d.gst || 0)}</td>
                          <td className={`px-4 py-2.5 text-xs text-right text-red-400`}>{fmt(d.expenses)}</td>
                          <td className={`px-4 py-2.5 text-xs text-right font-bold ${d.profit >= 0 ? 'text-green-400' : 'text-red-400'}`}>{fmt(d.profit)}</td>
                          <td className={`px-4 py-2.5 text-xs text-right ${parseFloat(margin) >= 20 ? 'text-green-400' : parseFloat(margin) >= 10 ? 'text-amber-400' : 'text-red-400'}`}>{margin}%</td>
                        </tr>
                      );
                    })}
                    <tr className={`font-bold border-t-2 ${dark ? 'bg-dark-700/50 border-dark-500' : 'bg-gray-50 border-gray-200'}`}>
                      <td className={`px-4 py-3 text-xs ${dark ? 'text-white' : 'text-gray-900'}`}>TOTAL (FY {fy})</td>
                      <td className="px-4 py-3 text-xs text-right text-green-400">{fmt(monthlyData.reduce((s, d) => s + d.sales, 0))}</td>
                      <td className="px-4 py-3 text-xs text-right text-purple-400">{fmt(monthlyData.reduce((s, d) => s + (d.gst || 0), 0))}</td>
                      <td className="px-4 py-3 text-xs text-right text-red-400">{fmt(monthlyData.reduce((s, d) => s + d.expenses, 0))}</td>
                      <td className="px-4 py-3 text-xs text-right text-green-400">{fmt(monthlyData.reduce((s, d) => s + d.profit, 0))}</td>
                      <td className="px-4 py-3 text-xs text-right text-primary-400">
                        {(() => { const ts = monthlyData.reduce((s, d) => s + d.sales, 0); const tp = monthlyData.reduce((s, d) => s + d.profit, 0); return ts > 0 ? ((tp / ts) * 100).toFixed(1) : 0; })()}%
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Balance Sheet */}
          {activeTab === 'balance' && balanceData && (
            <div className="grid grid-cols-2 gap-4">
              {/* Assets */}
              <div className={`${cardCls} p-5`}>
                <h3 className={secTitle}>Assets</h3>
                <div className="space-y-1">
                  <p className={`text-xs font-bold uppercase tracking-wider mb-2 ${dark ? 'text-dark-500' : 'text-gray-400'}`}>Current Assets</p>
                  <div className={rowCls}><span className={kCls}>Accounts Receivable</span><span className={vCls}>{fmt(balanceData.assets.receivables)}</span></div>
                  <div className={rowCls}><span className={kCls}>Inventory Value</span><span className={vCls}>{fmt(balanceData.assets.inventory)}</span></div>
                  <div className={rowCls}><span className={kCls}>Cash & Bank Balance</span><span className={vCls}>{fmt(balanceData.assets.cash)}</span></div>
                  <div className={`${rowCls} font-semibold`}><span>Total Current Assets</span><span className="text-blue-400">{fmt(balanceData.assets.receivables + balanceData.assets.inventory + balanceData.assets.cash)}</span></div>

                  <p className={`text-xs font-bold uppercase tracking-wider mt-4 mb-2 ${dark ? 'text-dark-500' : 'text-gray-400'}`}>Fixed Assets</p>
                  <div className={rowCls}><span className={kCls}>Equipment & Machinery</span><span className={vCls}>{fmt(balanceData.assets.fixedAssets)}</span></div>
                  <div className={`${rowCls} font-semibold`}><span>Total Fixed Assets</span><span className="text-blue-400">{fmt(balanceData.assets.fixedAssets)}</span></div>

                  <div className={`flex justify-between pt-3 font-bold text-sm border-t mt-2 ${dark ? 'border-dark-600' : 'border-gray-200'}`}>
                    <span className={dark ? 'text-white' : 'text-gray-900'}>TOTAL ASSETS</span>
                    <span className="text-green-400">{fmt(Object.values(balanceData.assets).reduce((s, v) => s + v, 0))}</span>
                  </div>
                </div>
              </div>

              {/* Liabilities & Equity */}
              <div className={`${cardCls} p-5`}>
                <h3 className={secTitle}>Liabilities & Equity</h3>
                <p className={`text-xs font-bold uppercase tracking-wider mb-2 ${dark ? 'text-dark-500' : 'text-gray-400'}`}>Current Liabilities</p>
                <div className={rowCls}><span className={kCls}>GST Payable</span><span className={vCls}>{fmt(balanceData.liabilities.gstPayable)}</span></div>
                <div className={rowCls}><span className={kCls}>Other Payables</span><span className={vCls}>{fmt(balanceData.liabilities.otherPayables)}</span></div>
                <div className={`${rowCls} font-semibold`}><span>Total Liabilities</span><span className="text-red-400">{fmt(Object.values(balanceData.liabilities).reduce((s, v) => s + v, 0))}</span></div>

                <p className={`text-xs font-bold uppercase tracking-wider mt-4 mb-2 ${dark ? 'text-dark-500' : 'text-gray-400'}`}>Owner's Equity</p>
                <div className={rowCls}><span className={kCls}>Retained Earnings</span><span className={vCls}>{fmt(balanceData.equity.retainedEarnings)}</span></div>
                <div className={`${rowCls} font-semibold`}><span>Total Equity</span><span className="text-purple-400">{fmt(balanceData.equity.retainedEarnings)}</span></div>

                <div className={`flex justify-between pt-3 font-bold text-sm border-t mt-2 ${dark ? 'border-dark-600' : 'border-gray-200'}`}>
                  <span className={dark ? 'text-white' : 'text-gray-900'}>TOTAL LIAB. + EQUITY</span>
                  <span className="text-green-400">{fmt(Object.values(balanceData.liabilities).reduce((s, v) => s + v, 0) + balanceData.equity.retainedEarnings)}</span>
                </div>
              </div>
            </div>
          )}

          {/* GST Report */}
          {activeTab === 'gst' && (
            <div className="space-y-4">
              <div className={`flex items-center gap-3 p-4 rounded-xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100'}`}>
                <span className={`text-xs font-medium ${dark ? 'text-dark-400' : 'text-gray-500'}`}>Period:</span>
                <input type="date" value={gstPeriod.from} onChange={e => setGstPeriod(p => ({ ...p, from: e.target.value }))}
                  className={`px-3 py-1.5 rounded-lg text-xs border focus:outline-none allow-select ${dark ? 'bg-dark-700 border-dark-600 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'}`} />
                <span className={`text-xs ${dark ? 'text-dark-500' : 'text-gray-400'}`}>to</span>
                <input type="date" value={gstPeriod.to} onChange={e => setGstPeriod(p => ({ ...p, to: e.target.value }))}
                  className={`px-3 py-1.5 rounded-lg text-xs border focus:outline-none allow-select ${dark ? 'bg-dark-700 border-dark-600 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'}`} />
                <button onClick={loadData} className="px-3 py-1.5 bg-primary-600 text-white rounded-lg text-xs font-semibold">Apply</button>
              </div>

              <div className="grid grid-cols-3 gap-4">
                {[
                  { label: 'Output GST (Collected)', sub: 'On sales invoices', value: gstData?.outward?.total || 0, color: 'text-green-400', bg: 'bg-green-500/10 border-green-500/20', items: gstData ? [['CGST', gstData.outward.cgst], ['SGST', gstData.outward.sgst], ['IGST', gstData.outward.igst]] : [] },
                  { label: 'Input GST (Paid)', sub: 'On purchases', value: gstData?.inwardGST || 0, color: 'text-blue-400', bg: 'bg-blue-500/10 border-blue-500/20', items: [] },
                  { label: 'Net GST Payable', sub: 'Output - Input', value: gstData?.netGSTPayable || 0, color: 'text-amber-400', bg: 'bg-amber-500/10 border-amber-500/20', items: [] },
                ].map((card, i) => (
                  <div key={i} className={`${cardCls} p-5 border ${card.bg}`}>
                    <p className={`text-xs font-medium ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{card.label}</p>
                    <p className={`text-xs ${dark ? 'text-dark-500' : 'text-gray-400'}`}>{card.sub}</p>
                    <p className={`font-display font-bold text-2xl mt-2 ${card.color}`}>{fmt(card.value)}</p>
                    {card.items.length > 0 && (
                      <div className="mt-3 space-y-1">
                        {card.items.filter(([, v]) => v > 0).map(([k, v]) => (
                          <div key={k} className={`flex justify-between text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>
                            <span>{k}</span><span className={vCls}>{fmt(v)}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <div className={`${cardCls} p-5`}>
                <h3 className={secTitle}>GST Reconciliation Summary</h3>
                <div className="space-y-1.5 max-w-sm">
                  {[
                    ['Total Output Tax (GSTR-1)', fmt(gstData?.outward?.total || 0), 'text-green-400'],
                    ['(-) Input Tax Credit (ITC)', `(${fmt(gstData?.inwardGST || 0)})`, 'text-blue-400'],
                    ['Net Tax Liability', fmt(gstData?.netGSTPayable || 0), 'text-amber-400 font-bold text-base'],
                  ].map(([k, v, cls], i) => (
                    <div key={i} className={`flex justify-between py-2 ${i < 2 ? `border-b ${dark ? 'border-dark-700' : 'border-gray-100'}` : `border-t-2 ${dark ? 'border-dark-500' : 'border-gray-200'} mt-1 pt-3`}`}>
                      <span className={`text-xs ${kCls}`}>{k}</span>
                      <span className={`text-xs font-semibold ${cls}`}>{v}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

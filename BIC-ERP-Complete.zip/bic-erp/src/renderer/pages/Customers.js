import React, { useState, useEffect } from 'react';
import { useApp } from '../App';

const INDIAN_STATES = [
  'Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Goa','Gujarat',
  'Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh',
  'Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab',
  'Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh',
  'Uttarakhand','West Bengal','Delhi','Jammu and Kashmir','Ladakh',
  'Andaman and Nicobar Islands','Chandigarh','Dadra and Nagar Haveli','Daman and Diu',
  'Lakshadweep','Puducherry'
];

const STATE_CODES = { 'West Bengal': '19', 'Maharashtra': '27', 'Delhi': '07', 'Karnataka': '29', 'Tamil Nadu': '33', 'Telangana': '36', 'Gujarat': '24', 'Rajasthan': '08', 'Uttar Pradesh': '09' };

const fmt = (n) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n || 0);

const MOCK_CUSTOMERS = [
  { id: 1, name: 'Sharma Photography', company_name: 'Sharma Photo Studio', gstin: '19ABCDE1234F1Z5', mobile: '9876543210', email: 'sharma@photo.com', city: 'Durgapur', state: 'West Bengal', outstanding_amount: 0, customer_type: 'B2B', is_active: 1 },
  { id: 2, name: 'Kolkata Print House', company_name: 'KPH Pvt Ltd', gstin: '19XYZAA5678B2Z3', mobile: '8765432109', email: 'kph@print.com', city: 'Kolkata', state: 'West Bengal', outstanding_amount: 82500, customer_type: 'B2B', is_active: 1 },
  { id: 3, name: 'Royal Studios', company_name: '', gstin: '', mobile: '7654321098', email: 'royal@studios.com', city: 'Asansol', state: 'West Bengal', outstanding_amount: 15000, customer_type: 'B2C', is_active: 1 },
  { id: 4, name: 'Pixel Perfect Labs', company_name: 'PPL Technologies', gstin: '19PQRST9012C3Z1', mobile: '6543210987', email: 'info@ppl.com', city: 'Durgapur', state: 'West Bengal', outstanding_amount: 0, customer_type: 'B2B', is_active: 1 },
];

const EMPTY_FORM = {
  name: '', company_name: '', gstin: '', pan: '', mobile: '', alternate_mobile: '',
  email: '', address_line1: '', address_line2: '', city: '', state: 'West Bengal',
  state_code: '19', pincode: '', customer_type: 'B2B', credit_limit: '', notes: ''
};

export default function Customers() {
  const { theme, addNotification } = useApp();
  const dark = theme === 'dark';
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editCustomer, setEditCustomer] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [selected, setSelected] = useState(null);

  useEffect(() => { loadCustomers(); }, [search]);

  const loadCustomers = async () => {
    setLoading(true);
    try {
      const data = window.electronAPI
        ? await window.electronAPI.getCustomers({ search })
        : MOCK_CUSTOMERS.filter(c => !search || c.name.toLowerCase().includes(search.toLowerCase()) || c.mobile.includes(search));
      setCustomers(data);
    } catch { setCustomers(MOCK_CUSTOMERS); }
    setLoading(false);
  };

  const openNew = () => { setForm(EMPTY_FORM); setEditCustomer(null); setShowModal(true); };
  const openEdit = (c) => {
    setForm({ ...EMPTY_FORM, ...c });
    setEditCustomer(c);
    setShowModal(true);
  };

  const f = (field) => (e) => {
    const val = e.target.value;
    setForm(prev => {
      const next = { ...prev, [field]: val };
      if (field === 'state') next.state_code = STATE_CODES[val] || '';
      return next;
    });
  };

  const handleSave = async () => {
    if (!form.name || !form.mobile) { addNotification('Name and mobile are required', 'error'); return; }
    setSaving(true);
    try {
      let result;
      if (window.electronAPI) {
        result = editCustomer
          ? await window.electronAPI.updateCustomer(editCustomer.id, form)
          : await window.electronAPI.createCustomer(form);
      } else { result = { success: true }; }
      if (result.success) {
        addNotification(editCustomer ? 'Customer updated!' : 'Customer added!', 'success');
        setShowModal(false); loadCustomers();
      }
    } catch { addNotification('Error saving customer', 'error'); }
    setSaving(false);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Deactivate this customer?')) return;
    try {
      if (window.electronAPI) await window.electronAPI.deleteCustomer(id);
      addNotification('Customer deactivated', 'success');
      loadCustomers(); if (selected?.id === id) setSelected(null);
    } catch { addNotification('Error', 'error'); }
  };

  const inputCls = `w-full px-3 py-2 rounded-lg text-xs border focus:outline-none focus:border-primary-500 transition-colors allow-select
    ${dark ? 'bg-dark-700 border-dark-600 text-white placeholder-dark-500' : 'bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400'}`;
  const labelCls = `block text-xs font-semibold mb-1 ${dark ? 'text-dark-300' : 'text-gray-600'}`;

  const stats = {
    total: customers.length,
    b2b: customers.filter(c => c.customer_type === 'B2B').length,
    outstanding: customers.reduce((s, c) => s + (c.outstanding_amount || 0), 0),
  };

  return (
    <div className="p-6 space-y-4 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className={`font-display font-bold text-2xl ${dark ? 'text-white' : 'text-gray-900'}`}>Customers</h1>
          <p className={`text-sm ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{stats.total} customers · {stats.b2b} B2B</p>
        </div>
        <button onClick={openNew} className="flex items-center gap-2 px-4 py-2 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-sm font-semibold transition-all shadow-lg shadow-primary-500/20">
          + Add Customer
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Total Customers', value: stats.total, color: 'text-primary-400' },
          { label: 'B2B Clients', value: stats.b2b, color: 'text-green-400' },
          { label: 'Total Outstanding', value: fmt(stats.outstanding), color: 'text-amber-400' },
        ].map((s, i) => (
          <div key={i} className={`p-4 rounded-xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100'}`}>
            <p className={`text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{s.label}</p>
            <p className={`font-display font-bold text-lg mt-1 ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Search */}
      <div className={`flex items-center gap-2 p-3 rounded-xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100'}`}>
        <div className="relative flex-1 max-w-sm">
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name, mobile, GSTIN..."
            className={`w-full pl-9 pr-4 py-2 rounded-lg text-sm border focus:outline-none focus:border-primary-500 transition-colors allow-select
              ${dark ? 'bg-dark-700 border-dark-600 text-white placeholder-dark-500' : 'bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400'}`} />
          <svg className={`absolute left-3 top-1/2 -translate-y-1/2 ${dark ? 'text-dark-400' : 'text-gray-400'}`} width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        </div>
      </div>

      {/* Main layout */}
      <div className="flex gap-4">
        {/* Table */}
        <div className={`flex-1 rounded-2xl border overflow-hidden ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
          <table className="w-full">
            <thead>
              <tr className={`border-b text-xs font-semibold ${dark ? 'bg-dark-700/50 border-dark-600 text-dark-400' : 'bg-gray-50 border-gray-100 text-gray-500'}`}>
                <th className="text-left px-4 py-3">Customer</th>
                <th className="text-left px-4 py-3">Mobile</th>
                <th className="text-left px-4 py-3">GSTIN</th>
                <th className="text-left px-4 py-3">City</th>
                <th className="text-left px-4 py-3">Type</th>
                <th className="text-right px-4 py-3">Outstanding</th>
                <th className="text-center px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody className={`divide-y ${dark ? 'divide-dark-700/40' : 'divide-gray-50'}`}>
              {loading ? (
                <tr><td colSpan={7} className="text-center py-12"><div className="w-6 h-6 border-2 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto" /></td></tr>
              ) : customers.length === 0 ? (
                <tr><td colSpan={7} className={`text-center py-12 text-sm ${dark ? 'text-dark-400' : 'text-gray-400'}`}>No customers found. Add your first customer!</td></tr>
              ) : customers.map(c => (
                <tr key={c.id} onClick={() => setSelected(c)}
                  className={`transition-colors cursor-pointer ${selected?.id === c.id ? dark ? 'bg-primary-600/10' : 'bg-primary-50' : dark ? 'hover:bg-dark-700/30' : 'hover:bg-gray-50'}`}>
                  <td className="px-4 py-3">
                    <p className={`text-xs font-semibold ${dark ? 'text-white' : 'text-gray-900'}`}>{c.name}</p>
                    {c.company_name && <p className={`text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{c.company_name}</p>}
                  </td>
                  <td className={`px-4 py-3 text-xs font-mono ${dark ? 'text-dark-300' : 'text-gray-600'}`}>{c.mobile}</td>
                  <td className={`px-4 py-3 text-xs font-mono ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{c.gstin || '—'}</td>
                  <td className={`px-4 py-3 text-xs ${dark ? 'text-dark-300' : 'text-gray-600'}`}>{c.city}</td>
                  <td className="px-4 py-3">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${c.customer_type === 'B2B' ? 'bg-blue-500/10 text-blue-400 border-blue-500/20' : 'bg-purple-500/10 text-purple-400 border-purple-500/20'}`}>
                      {c.customer_type}
                    </span>
                  </td>
                  <td className={`px-4 py-3 text-xs text-right font-semibold ${c.outstanding_amount > 0 ? 'text-amber-400' : dark ? 'text-dark-400' : 'text-gray-400'}`}>
                    {c.outstanding_amount > 0 ? fmt(c.outstanding_amount) : '—'}
                  </td>
                  <td className="px-4 py-3 text-center" onClick={e => e.stopPropagation()}>
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => openEdit(c)} className={`p-1.5 rounded-lg transition-colors ${dark ? 'hover:bg-dark-600 text-dark-400 hover:text-blue-400' : 'hover:bg-gray-100 text-gray-400 hover:text-blue-600'}`}>
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                      </button>
                      <button onClick={() => handleDelete(c.id)} className={`p-1.5 rounded-lg transition-colors ${dark ? 'hover:bg-dark-600 text-dark-400 hover:text-red-400' : 'hover:bg-gray-100 text-gray-400 hover:text-red-500'}`}>
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3,6 5,6 21,6"/><path d="M19,6l-1,14H6L5,6"/><path d="M10,11v6"/><path d="M14,11v6"/><path d="M9,6V4h6v2"/></svg>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Detail Panel */}
        {selected && (
          <div className={`w-72 shrink-0 rounded-2xl border p-5 space-y-4 animate-slide-in ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
            <div className="flex items-start justify-between">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center">
                <span className="text-white font-bold text-lg">{selected.name[0]}</span>
              </div>
              <button onClick={() => setSelected(null)} className={`p-1.5 rounded-lg ${dark ? 'hover:bg-dark-700 text-dark-400' : 'hover:bg-gray-100 text-gray-400'}`}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div>
              <p className={`font-bold text-base ${dark ? 'text-white' : 'text-gray-900'}`}>{selected.name}</p>
              {selected.company_name && <p className={`text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{selected.company_name}</p>}
            </div>
            <div className="space-y-2.5">
              {[
                ['📱 Mobile', selected.mobile],
                ['📧 Email', selected.email],
                ['🏛️ GSTIN', selected.gstin],
                ['📍 City', `${selected.city}, ${selected.state}`],
                ['📌 Pincode', selected.pincode],
              ].filter(([, v]) => v).map(([k, v]) => (
                <div key={k}>
                  <p className={`text-[10px] font-semibold ${dark ? 'text-dark-500' : 'text-gray-400'}`}>{k}</p>
                  <p className={`text-xs font-medium ${dark ? 'text-dark-200' : 'text-gray-700'}`}>{v}</p>
                </div>
              ))}
            </div>
            {selected.outstanding_amount > 0 && (
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20">
                <p className="text-xs font-semibold text-amber-400">Outstanding Due</p>
                <p className="text-lg font-bold text-amber-400">{fmt(selected.outstanding_amount)}</p>
              </div>
            )}
            <button onClick={() => openEdit(selected)} className="w-full py-2 bg-primary-600/10 hover:bg-primary-600/20 text-primary-400 border border-primary-500/30 rounded-xl text-xs font-semibold transition-colors">
              Edit Customer
            </button>
          </div>
        )}
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className={`w-full max-w-2xl rounded-2xl border shadow-2xl max-h-[90vh] overflow-y-auto ${dark ? 'bg-dark-800 border-dark-600' : 'bg-white border-gray-200'}`}>
            <div className={`flex items-center justify-between p-5 border-b sticky top-0 z-10 ${dark ? 'bg-dark-800 border-dark-600' : 'bg-white border-gray-100'}`}>
              <h2 className={`font-display font-bold text-lg ${dark ? 'text-white' : 'text-gray-900'}`}>
                {editCustomer ? 'Edit Customer' : 'Add New Customer'}
              </h2>
              <button onClick={() => setShowModal(false)} className={`p-2 rounded-xl transition-colors ${dark ? 'hover:bg-dark-700 text-dark-400' : 'hover:bg-gray-100 text-gray-400'}`}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-5 space-y-4">
              {/* Basic Info */}
              <div>
                <h3 className={`text-xs font-bold uppercase tracking-wider mb-3 ${dark ? 'text-dark-400' : 'text-gray-400'}`}>Basic Information</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div><label className={labelCls}>Full Name *</label><input value={form.name} onChange={f('name')} className={inputCls} placeholder="Customer name" /></div>
                  <div><label className={labelCls}>Company Name</label><input value={form.company_name} onChange={f('company_name')} className={inputCls} placeholder="Optional" /></div>
                  <div><label className={labelCls}>Mobile Number *</label><input value={form.mobile} onChange={f('mobile')} className={inputCls} placeholder="10-digit mobile" maxLength={10} /></div>
                  <div><label className={labelCls}>Alternate Mobile</label><input value={form.alternate_mobile} onChange={f('alternate_mobile')} className={inputCls} /></div>
                  <div><label className={labelCls}>Email Address</label><input type="email" value={form.email} onChange={f('email')} className={inputCls} /></div>
                  <div>
                    <label className={labelCls}>Customer Type</label>
                    <select value={form.customer_type} onChange={f('customer_type')} className={inputCls}>
                      <option value="B2B">B2B (Registered Business)</option>
                      <option value="B2C">B2C (Individual / Unregistered)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* GST & PAN */}
              <div>
                <h3 className={`text-xs font-bold uppercase tracking-wider mb-3 ${dark ? 'text-dark-400' : 'text-gray-400'}`}>Tax Information</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div><label className={labelCls}>GSTIN</label><input value={form.gstin} onChange={e => f('gstin')({ target: { value: e.target.value.toUpperCase() } })} className={`${inputCls} font-mono`} placeholder="15-digit GSTIN" maxLength={15} /></div>
                  <div><label className={labelCls}>PAN Number</label><input value={form.pan} onChange={e => f('pan')({ target: { value: e.target.value.toUpperCase() } })} className={`${inputCls} font-mono`} placeholder="AAAAA0000A" maxLength={10} /></div>
                  <div><label className={labelCls}>Credit Limit (₹)</label><input type="number" value={form.credit_limit} onChange={f('credit_limit')} className={inputCls} placeholder="0" /></div>
                </div>
              </div>

              {/* Address */}
              <div>
                <h3 className={`text-xs font-bold uppercase tracking-wider mb-3 ${dark ? 'text-dark-400' : 'text-gray-400'}`}>Address</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div className="col-span-2"><label className={labelCls}>Address Line 1</label><input value={form.address_line1} onChange={f('address_line1')} className={inputCls} placeholder="Street / Building" /></div>
                  <div className="col-span-2"><label className={labelCls}>Address Line 2</label><input value={form.address_line2} onChange={f('address_line2')} className={inputCls} placeholder="Area / Locality" /></div>
                  <div><label className={labelCls}>City</label><input value={form.city} onChange={f('city')} className={inputCls} /></div>
                  <div>
                    <label className={labelCls}>State</label>
                    <select value={form.state} onChange={f('state')} className={inputCls}>
                      {INDIAN_STATES.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                  <div><label className={labelCls}>State Code</label><input value={form.state_code} onChange={f('state_code')} className={inputCls} placeholder="e.g. 19" /></div>
                  <div><label className={labelCls}>Pincode</label><input value={form.pincode} onChange={f('pincode')} className={inputCls} maxLength={6} /></div>
                </div>
              </div>

              <div><label className={labelCls}>Notes</label><textarea value={form.notes} onChange={f('notes')} rows={2} className={`${inputCls} resize-none`} /></div>
            </div>

            <div className={`flex items-center justify-end gap-3 p-5 border-t sticky bottom-0 ${dark ? 'bg-dark-800 border-dark-600' : 'bg-white border-gray-100'}`}>
              <button onClick={() => setShowModal(false)} className={`px-4 py-2 rounded-xl text-sm font-medium border transition-colors ${dark ? 'border-dark-600 text-dark-300 hover:bg-dark-700' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}>
                Cancel
              </button>
              <button onClick={handleSave} disabled={saving} className="px-6 py-2 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-sm font-semibold transition-colors flex items-center gap-2">
                {saving && <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
                {editCustomer ? 'Update' : 'Add Customer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

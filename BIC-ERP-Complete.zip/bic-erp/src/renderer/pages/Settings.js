import React, { useState, useEffect } from 'react';
import { useApp } from '../App';

const INDIAN_STATES = [
  'Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Goa','Gujarat',
  'Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh',
  'Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab',
  'Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh',
  'Uttarakhand','West Bengal','Delhi','Jammu and Kashmir','Ladakh',
];

const STATE_CODES = {
  'West Bengal':'19','Maharashtra':'27','Delhi':'07','Karnataka':'29',
  'Tamil Nadu':'33','Telangana':'36','Gujarat':'24','Rajasthan':'08',
  'Uttar Pradesh':'09','Bihar':'10','Haryana':'06',
};

const DEFAULT_SETTINGS = {
  company_name: 'BIC Industries Private Limited',
  gstin: '19AABCB1234A1Z5', pan: 'AABCB1234A',
  address: '123, Industrial Area, Block A', city: 'Durgapur',
  state: 'West Bengal', state_code: '19', pincode: '713201',
  phone: '+91 9999999999', email: 'info@bicindustries.com',
  website: 'www.bicindustries.com',
  bank_name: 'State Bank of India', account_number: '12345678901',
  ifsc_code: 'SBIN0001234', account_holder: 'BIC Industries Private Limited',
  invoice_prefix: 'BIC', financial_year: '2024-25',
};

export default function Settings() {
  const { theme, toggleTheme, user, addNotification, loadSettings } = useApp();
  const dark = theme === 'dark';
  const [activeTab, setActiveTab] = useState('company');
  const [form, setForm] = useState(DEFAULT_SETTINGS);
  const [pwForm, setPwForm] = useState({ oldPassword: '', newPassword: '', confirmPassword: '' });
  const [saving, setSaving] = useState(false);
  const [savingPw, setSavingPw] = useState(false);

  useEffect(() => { fetchSettings(); }, []);

  const fetchSettings = async () => {
    try {
      const s = window.electronAPI ? await window.electronAPI.getSettings() : null;
      if (s) setForm({ ...DEFAULT_SETTINGS, ...s });
    } catch {}
  };

  const f = (field) => (e) => {
    const val = e.target.value;
    setForm(p => {
      const next = { ...p, [field]: val };
      if (field === 'state') next.state_code = STATE_CODES[val] || p.state_code;
      return next;
    });
  };

  const handleSave = async () => {
    if (!form.company_name || !form.gstin) { addNotification('Company name and GSTIN are required', 'error'); return; }
    setSaving(true);
    try {
      if (window.electronAPI) await window.electronAPI.updateSettings(form);
      addNotification('Settings saved successfully!', 'success');
      await loadSettings();
    } catch { addNotification('Error saving settings', 'error'); }
    setSaving(false);
  };

  const handleChangePassword = async () => {
    if (!pwForm.oldPassword || !pwForm.newPassword) { addNotification('All fields required', 'error'); return; }
    if (pwForm.newPassword !== pwForm.confirmPassword) { addNotification('New passwords do not match', 'error'); return; }
    if (pwForm.newPassword.length < 6) { addNotification('Password must be at least 6 characters', 'error'); return; }
    setSavingPw(true);
    try {
      const result = window.electronAPI
        ? await window.electronAPI.changePassword({ userId: user?.id, ...pwForm })
        : { success: true };
      if (result.success) {
        addNotification('Password changed successfully!', 'success');
        setPwForm({ oldPassword: '', newPassword: '', confirmPassword: '' });
      } else { addNotification(result.message || 'Error changing password', 'error'); }
    } catch { addNotification('Error', 'error'); }
    setSavingPw(false);
  };

  const inputCls = `w-full px-3 py-2 rounded-xl text-sm border focus:outline-none focus:border-primary-500 transition-colors allow-select
    ${dark ? 'bg-dark-700 border-dark-600 text-white placeholder-dark-500' : 'bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400'}`;
  const labelCls = `block text-xs font-semibold mb-1.5 ${dark ? 'text-dark-300' : 'text-gray-600'}`;
  const sectionCls = `space-y-4 ${dark ? '' : ''}`;
  const subHeadCls = `text-xs font-bold uppercase tracking-wider mb-3 ${dark ? 'text-dark-500' : 'text-gray-400'}`;

  const tabs = [
    { id: 'company', label: '🏢 Company', icon: '🏢' },
    { id: 'bank', label: '🏦 Banking', icon: '🏦' },
    { id: 'invoice', label: '🧾 Invoice', icon: '🧾' },
    { id: 'account', label: '👤 Account', icon: '👤' },
    { id: 'appearance', label: '🎨 Appearance', icon: '🎨' },
    { id: 'about', label: 'ℹ️ About', icon: 'ℹ️' },
  ];

  return (
    <div className="p-6 space-y-4 animate-fade-in">
      <div>
        <h1 className={`font-display font-bold text-2xl ${dark ? 'text-white' : 'text-gray-900'}`}>Settings</h1>
        <p className={`text-sm ${dark ? 'text-dark-400' : 'text-gray-500'}`}>Configure your ERP system</p>
      </div>

      <div className="flex gap-5">
        {/* Sidebar Tabs */}
        <div className={`w-44 shrink-0 rounded-2xl border p-2 space-y-0.5 h-fit ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all text-left
                ${activeTab === t.id ? 'bg-primary-600 text-white shadow' : dark ? 'text-dark-400 hover:text-white hover:bg-dark-700' : 'text-gray-500 hover:text-gray-900 hover:bg-gray-50'}`}>
              <span>{t.icon}</span> {t.label.split(' ')[1]}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1">
          {/* Company Info */}
          {activeTab === 'company' && (
            <div className={`rounded-2xl border p-6 space-y-5 ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
              <h2 className={`font-display font-bold text-lg ${dark ? 'text-white' : 'text-gray-900'}`}>Company Information</h2>

              <div className={sectionCls}>
                <p className={subHeadCls}>Basic Details</p>
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <label className={labelCls}>Company Name *</label>
                    <input value={form.company_name} onChange={f('company_name')} className={inputCls} />
                  </div>
                  <div>
                    <label className={labelCls}>GSTIN *</label>
                    <input value={form.gstin} onChange={e => f('gstin')({ target: { value: e.target.value.toUpperCase() } })} className={`${inputCls} font-mono`} placeholder="15-digit GSTIN" maxLength={15} />
                  </div>
                  <div>
                    <label className={labelCls}>PAN Number</label>
                    <input value={form.pan} onChange={e => f('pan')({ target: { value: e.target.value.toUpperCase() } })} className={`${inputCls} font-mono`} placeholder="AAAAA0000A" maxLength={10} />
                  </div>
                  <div>
                    <label className={labelCls}>Phone</label>
                    <input value={form.phone} onChange={f('phone')} className={inputCls} placeholder="+91 XXXXXXXXXX" />
                  </div>
                  <div>
                    <label className={labelCls}>Email</label>
                    <input type="email" value={form.email} onChange={f('email')} className={inputCls} />
                  </div>
                  <div className="col-span-2">
                    <label className={labelCls}>Website</label>
                    <input value={form.website} onChange={f('website')} className={inputCls} placeholder="www.yourcompany.com" />
                  </div>
                </div>
              </div>

              <div className={sectionCls}>
                <p className={subHeadCls}>Registered Address</p>
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <label className={labelCls}>Street Address</label>
                    <input value={form.address} onChange={f('address')} className={inputCls} placeholder="Street / Building / Area" />
                  </div>
                  <div>
                    <label className={labelCls}>City</label>
                    <input value={form.city} onChange={f('city')} className={inputCls} />
                  </div>
                  <div>
                    <label className={labelCls}>State</label>
                    <select value={form.state} onChange={f('state')} className={inputCls}>
                      {INDIAN_STATES.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className={labelCls}>State Code</label>
                    <input value={form.state_code} onChange={f('state_code')} className={`${inputCls} font-mono`} placeholder="19" />
                  </div>
                  <div>
                    <label className={labelCls}>Pincode</label>
                    <input value={form.pincode} onChange={f('pincode')} className={inputCls} maxLength={6} />
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button onClick={handleSave} disabled={saving}
                  className="flex items-center gap-2 px-6 py-2.5 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-sm font-semibold transition-all shadow-lg shadow-primary-500/20">
                  {saving && <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
                  Save Company Info
                </button>
              </div>
            </div>
          )}

          {/* Bank Details */}
          {activeTab === 'bank' && (
            <div className={`rounded-2xl border p-6 space-y-5 ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
              <h2 className={`font-display font-bold text-lg ${dark ? 'text-white' : 'text-gray-900'}`}>Bank Details</h2>
              <p className={`text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>These details appear on your invoices for payment.</p>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={labelCls}>Bank Name</label>
                  <input value={form.bank_name} onChange={f('bank_name')} className={inputCls} placeholder="e.g. State Bank of India" />
                </div>
                <div>
                  <label className={labelCls}>Account Holder Name</label>
                  <input value={form.account_holder} onChange={f('account_holder')} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>Account Number</label>
                  <input value={form.account_number} onChange={f('account_number')} className={`${inputCls} font-mono`} />
                </div>
                <div>
                  <label className={labelCls}>IFSC Code</label>
                  <input value={form.ifsc_code} onChange={e => f('ifsc_code')({ target: { value: e.target.value.toUpperCase() } })} className={`${inputCls} font-mono`} placeholder="SBIN0001234" />
                </div>
              </div>

              {/* Preview card */}
              <div className={`p-4 rounded-xl border-2 border-dashed ${dark ? 'border-dark-600 bg-dark-700/30' : 'border-gray-200 bg-gray-50'}`}>
                <p className={`text-xs font-bold mb-3 ${dark ? 'text-dark-300' : 'text-gray-600'}`}>Invoice Preview</p>
                <div className="space-y-1">
                  {[['Bank', form.bank_name], ['A/C', form.account_number], ['IFSC', form.ifsc_code], ['Holder', form.account_holder]].map(([k, v]) => (
                    <div key={k} className="flex gap-2 text-xs">
                      <span className={`w-12 font-semibold ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{k}:</span>
                      <span className={`font-mono ${dark ? 'text-white' : 'text-gray-900'}`}>{v || '—'}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button onClick={handleSave} disabled={saving}
                  className="flex items-center gap-2 px-6 py-2.5 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-sm font-semibold transition-all shadow-lg shadow-primary-500/20">
                  {saving && <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
                  Save Bank Details
                </button>
              </div>
            </div>
          )}

          {/* Invoice Settings */}
          {activeTab === 'invoice' && (
            <div className={`rounded-2xl border p-6 space-y-5 ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
              <h2 className={`font-display font-bold text-lg ${dark ? 'text-white' : 'text-gray-900'}`}>Invoice Configuration</h2>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={labelCls}>Invoice Prefix</label>
                  <input value={form.invoice_prefix} onChange={f('invoice_prefix')} className={`${inputCls} font-mono`} placeholder="BIC" />
                  <p className={`text-xs mt-1 ${dark ? 'text-dark-500' : 'text-gray-400'}`}>Invoice numbers will be: {form.invoice_prefix}/{form.financial_year}/0001</p>
                </div>
                <div>
                  <label className={labelCls}>Current Financial Year</label>
                  <select value={form.financial_year} onChange={f('financial_year')} className={inputCls}>
                    {['2024-25', '2025-26', '2023-24', '2022-23'].map(y => <option key={y} value={y}>{y}</option>)}
                  </select>
                </div>
              </div>

              {/* Preview */}
              <div className={`p-4 rounded-xl ${dark ? 'bg-dark-700/50 border border-dark-600' : 'bg-blue-50 border border-blue-100'}`}>
                <p className={`text-xs font-semibold mb-2 ${dark ? 'text-primary-400' : 'text-primary-600'}`}>Sample Invoice Number</p>
                <p className={`font-mono text-2xl font-bold ${dark ? 'text-white' : 'text-gray-900'}`}>
                  {form.invoice_prefix}/{form.financial_year}/0001
                </p>
              </div>

              <div className="flex justify-end pt-2">
                <button onClick={handleSave} disabled={saving}
                  className="flex items-center gap-2 px-6 py-2.5 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-sm font-semibold transition-all shadow-lg shadow-primary-500/20">
                  {saving && <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
                  Save Invoice Settings
                </button>
              </div>
            </div>
          )}

          {/* Account / Password */}
          {activeTab === 'account' && (
            <div className="space-y-4">
              {/* User Info */}
              <div className={`rounded-2xl border p-6 ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
                <h2 className={`font-display font-bold text-lg mb-4 ${dark ? 'text-white' : 'text-gray-900'}`}>Account Information</h2>
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center">
                    <span className="text-white font-bold text-2xl">{user?.full_name?.[0] || 'A'}</span>
                  </div>
                  <div>
                    <p className={`font-bold text-lg ${dark ? 'text-white' : 'text-gray-900'}`}>{user?.full_name || 'Administrator'}</p>
                    <p className={`text-sm ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{user?.username} · {user?.role}</p>
                    <p className={`text-xs mt-1 ${dark ? 'text-dark-500' : 'text-gray-400'}`}>{user?.email || 'No email set'}</p>
                  </div>
                </div>
              </div>

              {/* Change Password */}
              <div className={`rounded-2xl border p-6 ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
                <h2 className={`font-display font-bold text-lg mb-2 ${dark ? 'text-white' : 'text-gray-900'}`}>Change Password</h2>
                <p className={`text-xs mb-5 ${dark ? 'text-dark-400' : 'text-gray-500'}`}>Use a strong password with letters, numbers and symbols.</p>
                <div className="space-y-3 max-w-sm">
                  {[
                    ['Current Password', 'oldPassword'],
                    ['New Password', 'newPassword'],
                    ['Confirm New Password', 'confirmPassword'],
                  ].map(([label, field]) => (
                    <div key={field}>
                      <label className={labelCls}>{label}</label>
                      <input type="password" value={pwForm[field]} onChange={e => setPwForm(p => ({ ...p, [field]: e.target.value }))}
                        className={inputCls} placeholder="••••••••" />
                    </div>
                  ))}
                </div>
                <div className="flex justify-start pt-4">
                  <button onClick={handleChangePassword} disabled={savingPw}
                    className="flex items-center gap-2 px-6 py-2.5 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-sm font-semibold transition-all shadow-lg shadow-primary-500/20">
                    {savingPw && <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
                    Update Password
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Appearance */}
          {activeTab === 'appearance' && (
            <div className={`rounded-2xl border p-6 space-y-6 ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
              <h2 className={`font-display font-bold text-lg ${dark ? 'text-white' : 'text-gray-900'}`}>Appearance</h2>

              <div>
                <p className={labelCls}>Theme Mode</p>
                <div className="flex gap-3 mt-2">
                  {[['dark', '🌙 Dark Mode', 'bg-dark-900 border-dark-600'], ['light', '☀️ Light Mode', 'bg-white border-gray-200']].map(([t, label, preview]) => (
                    <button key={t} onClick={() => { if (theme !== t) toggleTheme(); }}
                      className={`flex-1 max-w-[160px] p-4 rounded-xl border-2 transition-all ${theme === t ? 'border-primary-500 ring-2 ring-primary-500/30' : dark ? 'border-dark-600 hover:border-dark-500' : 'border-gray-200 hover:border-gray-300'}`}>
                      <div className={`w-full h-12 rounded-lg ${preview} border mb-3`} />
                      <p className={`text-xs font-semibold text-center ${dark ? 'text-white' : 'text-gray-900'}`}>{label}</p>
                      {theme === t && <p className="text-[10px] text-primary-400 text-center mt-0.5">Active</p>}
                    </button>
                  ))}
                </div>
              </div>

              <div className={`p-4 rounded-xl ${dark ? 'bg-dark-700/50 border border-dark-600' : 'bg-blue-50 border border-blue-100'}`}>
                <p className={`text-xs font-semibold ${dark ? 'text-primary-400' : 'text-primary-600'}`}>💡 Tip</p>
                <p className={`text-xs mt-1 ${dark ? 'text-dark-300' : 'text-gray-600'}`}>You can also toggle the theme anytime from the top title bar using the sun/moon icon.</p>
              </div>
            </div>
          )}

          {/* About */}
          {activeTab === 'about' && (
            <div className={`rounded-2xl border p-6 space-y-6 ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center shadow-lg shadow-primary-500/30">
                  <span className="text-white font-display font-bold text-xl">BIC</span>
                </div>
                <div>
                  <h2 className={`font-display font-bold text-2xl ${dark ? 'text-white' : 'text-gray-900'}`}>BIC ERP</h2>
                  <p className={`text-sm ${dark ? 'text-dark-400' : 'text-gray-500'}`}>Version 1.0.0 · Build 2024</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {[
                  ['Platform', 'Electron JS + React'],
                  ['Database', 'SQLite (Local)'],
                  ['Invoice Format', 'Indian GST Tax Invoice'],
                  ['PDF Engine', 'jsPDF + AutoTable'],
                  ['OCR Engine', 'Tesseract.js'],
                  ['Framework', 'Tailwind CSS'],
                ].map(([k, v]) => (
                  <div key={k} className={`p-3 rounded-xl ${dark ? 'bg-dark-700/50' : 'bg-gray-50'}`}>
                    <p className={`text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{k}</p>
                    <p className={`text-xs font-semibold mt-0.5 ${dark ? 'text-white' : 'text-gray-900'}`}>{v}</p>
                  </div>
                ))}
              </div>

              <div className={`p-4 rounded-xl border ${dark ? 'bg-dark-700/30 border-dark-600' : 'bg-gray-50 border-gray-100'}`}>
                <p className={`text-sm font-semibold ${dark ? 'text-white' : 'text-gray-900'}`}>BIC Industries Private Limited</p>
                <p className={`text-xs mt-1 ${dark ? 'text-dark-400' : 'text-gray-500'}`}>Durgapur, West Bengal, India</p>
                <p className={`text-xs mt-1 ${dark ? 'text-dark-500' : 'text-gray-400'}`}>© 2024 All Rights Reserved · Proprietary Software</p>
              </div>

              <div className={`p-4 rounded-xl bg-amber-500/10 border border-amber-500/20`}>
                <p className="text-xs font-semibold text-amber-400">⚠️ Data Security Notice</p>
                <p className="text-xs text-amber-300/80 mt-1">All data is stored locally on your computer in an encrypted SQLite database. No data is transmitted to external servers. Regular backups are recommended.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

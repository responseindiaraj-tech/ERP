import React, { useState, useEffect } from 'react';
import { useApp } from '../App';
import Modal, { ModalFooter } from '../components/Shared/Modal';
import {
  Field, Input, Select, Textarea, FormGrid, FormSection, SectionCard,
  PageHeader, EmptyState, LoadingSpinner, StatusBadge
} from '../components/Shared/FormFields';
import { fmtINR0, fmtDate, isValidGSTIN } from '../utils/numberUtils';

const MOCK_VENDORS = [
  { id:1, name:'Rajkamal Traders', company_name:'Rajkamal Trading Co', gstin:'19RAJKA1234F1Z5', mobile:'9800000001', email:'raj@traders.com', city:'Durgapur', state:'West Bengal', is_active:1 },
  { id:2, name:'DVC Power',         company_name:'Damodar Valley Corporation', gstin:'', mobile:'033-0000000', email:'', city:'Kolkata', state:'West Bengal', is_active:1 },
  { id:3, name:'DTDC Courier',      company_name:'DTDC Express Ltd', gstin:'29DTDCE5678B2Z3', mobile:'1800-123-3456', email:'', city:'Bangalore', state:'Karnataka', is_active:1 },
  { id:4, name:'Canon India',       company_name:'Canon India Pvt Ltd', gstin:'07CANON9012C3Z1', mobile:'1800-180-3366', email:'support@canon.co.in', city:'Delhi', state:'Delhi', is_active:1 },
];

const EMPTY = {
  name:'', company_name:'', gstin:'', pan:'', mobile:'', email:'',
  address:'', city:'', state:'West Bengal', pincode:'',
  bank_name:'', account_number:'', ifsc_code:'', credit_period:30, notes:''
};

export default function Vendors() {
  const { theme, addNotification } = useApp();
  const dark = theme === 'dark';
  const [vendors, setVendors]       = useState([]);
  const [loading, setLoading]       = useState(true);
  const [search, setSearch]         = useState('');
  const [showModal, setShowModal]   = useState(false);
  const [editVendor, setEditVendor] = useState(null);
  const [form, setForm]             = useState(EMPTY);
  const [saving, setSaving]         = useState(false);
  const [selected, setSelected]     = useState(null);
  const [gstError, setGstError]     = useState('');

  useEffect(() => { loadVendors(); }, [search]);

  const loadVendors = async () => {
    setLoading(true);
    try {
      const data = window.electronAPI
        ? await window.electronAPI.getVendors()
        : MOCK_VENDORS.filter(v => !search || v.name.toLowerCase().includes(search.toLowerCase()));
      setVendors(data);
    } catch { setVendors(MOCK_VENDORS); }
    setLoading(false);
  };

  const openNew  = () => { setForm(EMPTY); setEditVendor(null); setGstError(''); setShowModal(true); };
  const openEdit = (v) => { setForm({ ...EMPTY, ...v }); setEditVendor(v); setGstError(''); setShowModal(true); };

  const f = (field) => (e) => setForm(p => ({ ...p, [field]: e.target.value }));

  const handleGSTIN = (e) => {
    const val = e.target.value.toUpperCase();
    setForm(p => ({ ...p, gstin: val }));
    if (val && !isValidGSTIN(val)) setGstError('Invalid GSTIN format');
    else setGstError('');
  };

  const handleSave = async () => {
    if (!form.name) { addNotification('Vendor name is required', 'error'); return; }
    if (form.gstin && !isValidGSTIN(form.gstin)) { addNotification('Invalid GSTIN format', 'error'); return; }
    setSaving(true);
    try {
      let result;
      if (window.electronAPI) {
        result = editVendor
          ? await window.electronAPI.updateVendor?.(editVendor.id, form) || { success: true }
          : await window.electronAPI.createVendor(form);
      } else { result = { success: true }; }
      if (result.success) {
        addNotification(editVendor ? 'Vendor updated!' : 'Vendor added!', 'success');
        setShowModal(false); loadVendors();
      }
    } catch { addNotification('Error saving vendor', 'error'); }
    setSaving(false);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Deactivate this vendor?')) return;
    try {
      if (window.electronAPI) await window.electronAPI.deleteVendor?.(id);
      addNotification('Vendor removed', 'success');
      loadVendors(); if (selected?.id === id) setSelected(null);
    } catch { addNotification('Error', 'error'); }
  };

  const cardCls = `rounded-2xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`;

  return (
    <div className="p-6 space-y-4 animate-fade-in">
      <PageHeader title="Vendors / Suppliers" subtitle={`${vendors.length} vendors · Manage your supplier database`}>
        <button onClick={openNew} className="flex items-center gap-2 px-4 py-2 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-sm font-semibold transition-all shadow-lg shadow-primary-500/20">
          + Add Vendor
        </button>
      </PageHeader>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Total Vendors', value: vendors.length,                                   color: 'text-primary-400' },
          { label: 'With GSTIN',    value: vendors.filter(v => v.gstin).length,              color: 'text-green-400'  },
          { label: 'Active',        value: vendors.filter(v => v.is_active).length,          color: 'text-cyan-400'   },
        ].map((s, i) => (
          <div key={i} className={`p-4 rounded-xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100'}`}>
            <p className={`text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{s.label}</p>
            <p className={`font-display font-bold text-xl mt-1 ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Search */}
      <div className={`flex items-center gap-2 p-3 rounded-xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100'}`}>
        <div className="relative flex-1 max-w-sm">
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search vendors..."
            className={`w-full pl-9 pr-4 py-2 rounded-lg text-sm border focus:outline-none focus:border-primary-500 transition-colors allow-select
              ${dark ? 'bg-dark-700 border-dark-600 text-white placeholder-dark-500' : 'bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400'}`} />
          <svg className={`absolute left-3 top-1/2 -translate-y-1/2 ${dark ? 'text-dark-400' : 'text-gray-400'}`} width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        </div>
      </div>

      {/* Table + detail */}
      <div className="flex gap-4">
        <div className={`flex-1 rounded-2xl border overflow-hidden ${cardCls}`}>
          {loading ? <LoadingSpinner /> : vendors.length === 0 ? (
            <EmptyState icon="🏪" title="No vendors found" subtitle="Add your first vendor or supplier" action={<button onClick={openNew} className="btn-primary px-4 py-2 bg-primary-600 text-white rounded-xl text-sm font-semibold">Add Vendor</button>} />
          ) : (
            <table className="w-full">
              <thead>
                <tr className={`border-b text-xs font-semibold ${dark ? 'bg-dark-700/50 border-dark-600 text-dark-400' : 'bg-gray-50 border-gray-100 text-gray-500'}`}>
                  <th className="text-left px-4 py-3">Vendor</th>
                  <th className="text-left px-4 py-3">Mobile</th>
                  <th className="text-left px-4 py-3">GSTIN</th>
                  <th className="text-left px-4 py-3">City</th>
                  <th className="text-left px-4 py-3">Credit Days</th>
                  <th className="text-center px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody className={`divide-y ${dark ? 'divide-dark-700/40' : 'divide-gray-50'}`}>
                {vendors.map(v => (
                  <tr key={v.id} onClick={() => setSelected(v)}
                    className={`transition-colors cursor-pointer ${selected?.id === v.id ? dark ? 'bg-primary-600/10' : 'bg-primary-50' : dark ? 'hover:bg-dark-700/30' : 'hover:bg-gray-50'}`}>
                    <td className="px-4 py-3">
                      <p className={`text-xs font-semibold ${dark ? 'text-white' : 'text-gray-900'}`}>{v.name}</p>
                      {v.company_name && <p className={`text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{v.company_name}</p>}
                    </td>
                    <td className={`px-4 py-3 text-xs font-mono ${dark ? 'text-dark-300' : 'text-gray-600'}`}>{v.mobile || '—'}</td>
                    <td className={`px-4 py-3 text-xs font-mono ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{v.gstin || '—'}</td>
                    <td className={`px-4 py-3 text-xs ${dark ? 'text-dark-300' : 'text-gray-600'}`}>{v.city || '—'}</td>
                    <td className="px-4 py-3 text-xs">
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-semibold ${dark ? 'bg-dark-700 text-dark-300' : 'bg-gray-100 text-gray-600'}`}>
                        {v.credit_period || 30} days
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center" onClick={e => e.stopPropagation()}>
                      <div className="flex items-center justify-center gap-1">
                        <button onClick={() => openEdit(v)} className={`p-1.5 rounded-lg transition-colors ${dark ? 'hover:bg-dark-600 text-dark-400 hover:text-blue-400' : 'hover:bg-gray-100 text-gray-400 hover:text-blue-600'}`}>
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                        </button>
                        <button onClick={() => handleDelete(v.id)} className={`p-1.5 rounded-lg transition-colors ${dark ? 'hover:bg-dark-600 text-dark-400 hover:text-red-400' : 'hover:bg-gray-100 text-gray-400 hover:text-red-500'}`}>
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3,6 5,6 21,6"/><path d="M19,6l-1,14H6L5,6"/><path d="M10,11v6"/><path d="M14,11v6"/><path d="M9,6V4h6v2"/></svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Detail panel */}
        {selected && (
          <div className={`w-64 shrink-0 rounded-2xl border p-5 space-y-4 animate-slide-in ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
            <div className="flex items-start justify-between">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center">
                <span className="text-white font-bold text-lg">{selected.name[0]}</span>
              </div>
              <button onClick={() => setSelected(null)} className={`p-1.5 rounded-lg ${dark ? 'hover:bg-dark-700 text-dark-400' : 'hover:bg-gray-100 text-gray-400'}`}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div>
              <p className={`font-bold text-sm ${dark ? 'text-white' : 'text-gray-900'}`}>{selected.name}</p>
              {selected.company_name && <p className={`text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{selected.company_name}</p>}
            </div>
            <div className="space-y-2">
              {[
                ['📱 Mobile', selected.mobile],
                ['📧 Email',  selected.email],
                ['🏛️ GSTIN',  selected.gstin],
                ['📍 City',   `${selected.city || ''}, ${selected.state || ''}`],
                ['🏦 Bank',   selected.bank_name],
                ['💳 IFSC',   selected.ifsc_code],
              ].filter(([,v]) => v && v.trim() !== ', ').map(([k,v]) => (
                <div key={k}>
                  <p className={`text-[10px] font-semibold ${dark ? 'text-dark-500' : 'text-gray-400'}`}>{k}</p>
                  <p className={`text-xs font-medium ${dark ? 'text-dark-200' : 'text-gray-700'}`}>{v}</p>
                </div>
              ))}
            </div>
            <button onClick={() => openEdit(selected)} className="w-full py-2 bg-primary-600/10 hover:bg-primary-600/20 text-primary-400 border border-primary-500/30 rounded-xl text-xs font-semibold transition-colors">
              Edit Vendor
            </button>
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      <Modal
        open={showModal}
        onClose={() => setShowModal(false)}
        title={editVendor ? 'Edit Vendor' : 'Add New Vendor'}
        size="lg"
        footer={<ModalFooter onCancel={() => setShowModal(false)} onConfirm={handleSave} loading={saving} confirmLabel={editVendor ? 'Update Vendor' : 'Add Vendor'} />}
      >
        <div className="space-y-5">
          <FormSection title="Basic Information">
            <FormGrid cols={2}>
              <Field label="Vendor Name" required><Input value={form.name} onChange={f('name')} placeholder="Vendor / supplier name" /></Field>
              <Field label="Company Name"><Input value={form.company_name} onChange={f('company_name')} placeholder="Optional" /></Field>
              <Field label="Mobile"><Input value={form.mobile} onChange={f('mobile')} placeholder="10-digit mobile" /></Field>
              <Field label="Email"><Input type="email" value={form.email} onChange={f('email')} /></Field>
            </FormGrid>
          </FormSection>

          <FormSection title="Tax Information">
            <FormGrid cols={2}>
              <Field label="GSTIN" error={gstError}>
                <Input value={form.gstin} onChange={handleGSTIN} mono placeholder="22AAAAA0000A1Z5" maxLength={15} className={gstError ? 'border-red-500' : ''} />
              </Field>
              <Field label="PAN Number"><Input value={form.pan} onChange={e => f('pan')({ target:{ value: e.target.value.toUpperCase() } })} mono placeholder="AAAAA0000A" maxLength={10} /></Field>
            </FormGrid>
          </FormSection>

          <FormSection title="Address">
            <FormGrid cols={2}>
              <Field label="Address" className="col-span-2"><Input value={form.address} onChange={f('address')} placeholder="Street / Building / Area" /></Field>
              <Field label="City"><Input value={form.city} onChange={f('city')} /></Field>
              <Field label="State"><Input value={form.state} onChange={f('state')} /></Field>
              <Field label="Pincode"><Input value={form.pincode} onChange={f('pincode')} maxLength={6} /></Field>
              <Field label="Credit Period (days)"><Input type="number" value={form.credit_period} onChange={f('credit_period')} /></Field>
            </FormGrid>
          </FormSection>

          <FormSection title="Bank Details">
            <FormGrid cols={2}>
              <Field label="Bank Name"><Input value={form.bank_name} onChange={f('bank_name')} /></Field>
              <Field label="Account Number"><Input value={form.account_number} onChange={f('account_number')} mono /></Field>
              <Field label="IFSC Code"><Input value={form.ifsc_code} onChange={e => f('ifsc_code')({ target:{ value: e.target.value.toUpperCase() } })} mono /></Field>
            </FormGrid>
          </FormSection>

          <Field label="Notes"><Textarea value={form.notes} onChange={f('notes')} rows={2} placeholder="Any notes about this vendor..." /></Field>
        </div>
      </Modal>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../App';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell } from 'recharts';

const fmt = (n) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n || 0);
const fmtShort = (n) => {
  if (n >= 1e7) return `₹${(n / 1e7).toFixed(1)}Cr`;
  if (n >= 1e5) return `₹${(n / 1e5).toFixed(1)}L`;
  if (n >= 1e3) return `₹${(n / 1e3).toFixed(0)}K`;
  return `₹${n || 0}`;
};

const COLORS = ['#3b82f6', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444', '#06b6d4'];

const MOCK_DATA = {
  totalSales: 847500, totalExpenses: 312400, netProfit: 535100, ebitda: 615365,
  pendingAmount: 124500, pendingCount: 8, inventoryValue: 289000, salesGrowth: 12.4,
  taxCollected: 152550, taxPaid: 56232, lowStockCount: 3,
  monthlyData: [
    { month: 'Dec', sales: 620000, expenses: 280000, profit: 340000 },
    { month: 'Jan', sales: 710000, expenses: 295000, profit: 415000 },
    { month: 'Feb', sales: 680000, expenses: 310000, profit: 370000 },
    { month: 'Mar', sales: 750000, expenses: 290000, profit: 460000 },
    { month: 'Apr', sales: 820000, expenses: 305000, profit: 515000 },
    { month: 'May', sales: 847500, expenses: 312400, profit: 535100 },
  ],
  topCustomers: [
    { customer_name: 'Sharma Photography', total: 245000 },
    { customer_name: 'Kolkata Print House', total: 189000 },
    { customer_name: 'Royal Studios', total: 156000 },
    { customer_name: 'Pixel Perfect Labs', total: 124000 },
    { customer_name: 'Durgapur Digitals', total: 98000 },
  ],
  expenseBreakdown: [
    { category: 'Inventory', total: 128000 },
    { category: 'Utilities', total: 45000 },
    { category: 'Salaries', total: 85000 },
    { category: 'Transport', total: 32000 },
    { category: 'Miscellaneous', total: 22400 },
  ],
  recentInvoices: [
    { id: 1, invoice_number: 'BIC/2024-25/0045', invoice_date: '2024-05-10', customer_name: 'Sharma Photography', grand_total: 45200, payment_status: 'PAID' },
    { id: 2, invoice_number: 'BIC/2024-25/0044', invoice_date: '2024-05-09', customer_name: 'Kolkata Print House', grand_total: 82500, payment_status: 'PENDING' },
    { id: 3, invoice_number: 'BIC/2024-25/0043', invoice_date: '2024-05-08', customer_name: 'Royal Studios', grand_total: 31800, payment_status: 'PARTIAL' },
    { id: 4, invoice_number: 'BIC/2024-25/0042', invoice_date: '2024-05-07', customer_name: 'Pixel Perfect Labs', grand_total: 67400, payment_status: 'PAID' },
    { id: 5, invoice_number: 'BIC/2024-25/0041', invoice_date: '2024-05-06', customer_name: 'Durgapur Digitals', grand_total: 28900, payment_status: 'PENDING' },
  ]
};

export default function Dashboard() {
  const { theme } = useApp();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [period, setPeriod] = useState('month');
  const [loading, setLoading] = useState(true);
  const dark = theme === 'dark';

  useEffect(() => {
    loadData();
  }, [period]);

  const loadData = async () => {
    setLoading(true);
    try {
      if (window.electronAPI) {
        const d = await window.electronAPI.getDashboardStats(period);
        setData(d);
      } else {
        setData(MOCK_DATA);
      }
    } catch { setData(MOCK_DATA); }
    setLoading(false);
  };

  if (loading) return <LoadingSkeleton dark={dark} />;
  if (!data) return null;

  const statCards = [
    { label: 'Total Sales', value: fmtShort(data.totalSales), sub: 'This period', color: 'blue', icon: '📈', growth: data.salesGrowth },
    { label: 'Total Expenses', value: fmtShort(data.totalExpenses), sub: 'This period', color: 'red', icon: '📊', growth: null },
    { label: 'Net Profit', value: fmtShort(data.netProfit), sub: 'After expenses', color: 'green', icon: '💰', growth: data.salesGrowth },
    { label: 'EBITDA', value: fmtShort(data.ebitda), sub: 'Estimated', color: 'purple', icon: '📉', growth: null },
    { label: 'Pending Dues', value: fmtShort(data.pendingAmount), sub: `${data.pendingCount} invoices`, color: 'amber', icon: '⏳', growth: null },
    { label: 'Inventory Value', value: fmtShort(data.inventoryValue), sub: 'Current stock', color: 'cyan', icon: '📦', growth: null },
  ];

  const colors = {
    blue: { bg: 'bg-blue-500/10', border: 'border-blue-500/20', text: 'text-blue-400', glow: '#3b82f6' },
    red: { bg: 'bg-red-500/10', border: 'border-red-500/20', text: 'text-red-400', glow: '#ef4444' },
    green: { bg: 'bg-green-500/10', border: 'border-green-500/20', text: 'text-green-400', glow: '#10b981' },
    purple: { bg: 'bg-purple-500/10', border: 'border-purple-500/20', text: 'text-purple-400', glow: '#8b5cf6' },
    amber: { bg: 'bg-amber-500/10', border: 'border-amber-500/20', text: 'text-amber-400', glow: '#f59e0b' },
    cyan: { bg: 'bg-cyan-500/10', border: 'border-cyan-500/20', text: 'text-cyan-400', glow: '#06b6d4' },
  };

  const chartColors = dark ? { grid: '#1e293b', text: '#64748b', bg: '#0f172a' } : { grid: '#e2e8f0', text: '#94a3b8', bg: '#f8fafc' };

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className={`font-display font-bold text-2xl ${dark ? 'text-white' : 'text-gray-900'}`}>Dashboard</h1>
          <p className={`text-sm mt-0.5 ${dark ? 'text-dark-400' : 'text-gray-500'}`}>
            {new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {data.lowStockCount > 0 && (
            <button onClick={() => navigate('/inventory')} className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-lg text-xs font-medium hover:bg-amber-500/20 transition-colors">
              ⚠️ {data.lowStockCount} Low Stock
            </button>
          )}
          <div className={`flex items-center rounded-xl border overflow-hidden text-xs ${dark ? 'bg-dark-800 border-dark-600' : 'bg-white border-gray-200'}`}>
            {['week', 'month', 'year'].map(p => (
              <button key={p} onClick={() => setPeriod(p)}
                className={`px-3 py-1.5 font-medium transition-colors capitalize ${period === p ? 'bg-primary-600 text-white' : dark ? 'text-dark-400 hover:text-white' : 'text-gray-500 hover:text-gray-900'}`}>
                {p}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-6 gap-4">
        {statCards.map((card, i) => {
          const c = colors[card.color];
          return (
            <div key={i} className={`rounded-2xl border p-4 transition-all hover:scale-[1.02] cursor-default ${dark ? `bg-dark-800/50 border-dark-600/50 hover:border-dark-500` : 'bg-white border-gray-100 hover:border-gray-200 shadow-sm'}`}>
              <div className="flex items-start justify-between mb-3">
                <div className={`w-9 h-9 rounded-xl ${c.bg} border ${c.border} flex items-center justify-center text-base`}>
                  {card.icon}
                </div>
                {card.growth !== null && (
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${card.growth >= 0 ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
                    {card.growth >= 0 ? '↑' : '↓'} {Math.abs(card.growth).toFixed(1)}%
                  </span>
                )}
              </div>
              <p className={`font-display font-bold text-xl ${dark ? 'text-white' : 'text-gray-900'}`}>{card.value}</p>
              <p className={`text-xs mt-0.5 font-medium ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{card.label}</p>
              <p className={`text-xs mt-0.5 ${dark ? 'text-dark-500' : 'text-gray-400'}`}>{card.sub}</p>
            </div>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-3 gap-4">
        {/* Revenue & Expenses Chart */}
        <div className={`col-span-2 rounded-2xl border p-5 ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className={`font-semibold text-sm ${dark ? 'text-white' : 'text-gray-900'}`}>Revenue vs Expenses</h3>
              <p className={`text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>Last 6 months performance</p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-primary-500 inline-block rounded" /> Sales</span>
              <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-red-400 inline-block rounded" /> Expenses</span>
              <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-green-400 inline-block rounded" /> Profit</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={data.monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
              <XAxis dataKey="month" tick={{ fill: chartColors.text, fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: chartColors.text, fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => fmtShort(v)} />
              <Tooltip formatter={(v) => [fmt(v)]} contentStyle={{ background: dark ? '#1e293b' : '#fff', border: `1px solid ${dark ? '#334155' : '#e2e8f0'}`, borderRadius: 12, fontSize: 12 }} />
              <Line type="monotone" dataKey="sales" stroke="#3b82f6" strokeWidth={2.5} dot={{ fill: '#3b82f6', r: 4 }} activeDot={{ r: 6 }} />
              <Line type="monotone" dataKey="expenses" stroke="#ef4444" strokeWidth={2} dot={{ fill: '#ef4444', r: 3 }} strokeDasharray="4 2" />
              <Line type="monotone" dataKey="profit" stroke="#10b981" strokeWidth={2} dot={{ fill: '#10b981', r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Expense Breakdown */}
        <div className={`rounded-2xl border p-5 ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
          <h3 className={`font-semibold text-sm mb-1 ${dark ? 'text-white' : 'text-gray-900'}`}>Expense Breakdown</h3>
          <p className={`text-xs mb-4 ${dark ? 'text-dark-400' : 'text-gray-500'}`}>By category</p>
          <ResponsiveContainer width="100%" height={140}>
            <PieChart>
              <Pie data={data.expenseBreakdown} dataKey="total" nameKey="category" cx="50%" cy="50%" outerRadius={60} innerRadius={35}>
                {data.expenseBreakdown.map((_, i) => (
                  <Cell key={i} fill={COLORS[i % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(v) => [fmt(v)]} contentStyle={{ background: dark ? '#1e293b' : '#fff', border: `1px solid ${dark ? '#334155' : '#e2e8f0'}`, borderRadius: 8, fontSize: 11 }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1.5 mt-2">
            {data.expenseBreakdown.slice(0, 4).map((e, i) => (
              <div key={i} className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full" style={{ background: COLORS[i] }} />
                  <span className={dark ? 'text-dark-300' : 'text-gray-600'}>{e.category}</span>
                </span>
                <span className={`font-medium ${dark ? 'text-dark-200' : 'text-gray-700'}`}>{fmtShort(e.total)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-2 gap-4">
        {/* Recent Invoices */}
        <div className={`rounded-2xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
          <div className="flex items-center justify-between p-4 border-b border-dark-700/30">
            <h3 className={`font-semibold text-sm ${dark ? 'text-white' : 'text-gray-900'}`}>Recent Invoices</h3>
            <button onClick={() => navigate('/invoices')} className="text-xs text-primary-400 hover:text-primary-300 transition-colors">View All →</button>
          </div>
          <div className="divide-y divide-dark-700/20">
            {data.recentInvoices.map(inv => (
              <div key={inv.id} className={`flex items-center justify-between px-4 py-2.5 hover:${dark ? 'bg-dark-700/30' : 'bg-gray-50'} transition-colors cursor-pointer`}
                onClick={() => navigate(`/invoices/${inv.id}`)}>
                <div className="min-w-0">
                  <p className={`text-xs font-semibold truncate ${dark ? 'text-white' : 'text-gray-900'}`}>{inv.invoice_number}</p>
                  <p className={`text-xs truncate ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{inv.customer_name} · {inv.invoice_date}</p>
                </div>
                <div className="flex items-center gap-2 ml-3 shrink-0">
                  <span className={`text-xs font-semibold ${dark ? 'text-white' : 'text-gray-900'}`}>{fmtShort(inv.grand_total)}</span>
                  <StatusBadge status={inv.payment_status} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Customers */}
        <div className={`rounded-2xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
          <div className="flex items-center justify-between p-4 border-b border-dark-700/30">
            <h3 className={`font-semibold text-sm ${dark ? 'text-white' : 'text-gray-900'}`}>Top Customers</h3>
            <button onClick={() => navigate('/customers')} className="text-xs text-primary-400 hover:text-primary-300 transition-colors">View All →</button>
          </div>
          <div className="p-4 space-y-3">
            {data.topCustomers.map((c, i) => {
              const maxVal = data.topCustomers[0].total;
              const pct = (c.total / maxVal) * 100;
              return (
                <div key={i}>
                  <div className="flex items-center justify-between mb-1">
                    <span className={`text-xs font-medium truncate ${dark ? 'text-dark-200' : 'text-gray-700'}`}>{c.customer_name}</span>
                    <span className={`text-xs font-semibold ${dark ? 'text-white' : 'text-gray-900'}`}>{fmtShort(c.total)}</span>
                  </div>
                  <div className={`h-1.5 rounded-full overflow-hidden ${dark ? 'bg-dark-700' : 'bg-gray-100'}`}>
                    <div className="h-full bg-gradient-to-r from-primary-600 to-primary-400 rounded-full transition-all" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ status }) {
  const map = {
    PAID: 'bg-green-500/10 text-green-400 border-green-500/20',
    PENDING: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    PARTIAL: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    CANCELLED: 'bg-red-500/10 text-red-400 border-red-500/20',
  };
  return (
    <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-md border ${map[status] || map.PENDING}`}>
      {status}
    </span>
  );
}

function LoadingSkeleton({ dark }) {
  return (
    <div className="p-6 space-y-6">
      <div className={`h-8 w-48 rounded-xl shimmer ${dark ? 'bg-dark-700' : 'bg-gray-200'}`} />
      <div className="grid grid-cols-6 gap-4">
        {Array(6).fill(0).map((_, i) => (
          <div key={i} className={`h-28 rounded-2xl shimmer ${dark ? 'bg-dark-800' : 'bg-gray-100'}`} />
        ))}
      </div>
      <div className="grid grid-cols-3 gap-4">
        <div className={`col-span-2 h-72 rounded-2xl shimmer ${dark ? 'bg-dark-800' : 'bg-gray-100'}`} />
        <div className={`h-72 rounded-2xl shimmer ${dark ? 'bg-dark-800' : 'bg-gray-100'}`} />
      </div>
    </div>
  );
}

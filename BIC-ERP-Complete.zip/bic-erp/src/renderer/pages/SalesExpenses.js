import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../App';

const fmt = (n) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n || 0);

const EXPENSE_CATEGORIES = ['Inventory Purchase', 'Rent', 'Electricity', 'Internet & Phone', 'Salaries & Wages', 'Transport & Logistics', 'Equipment Maintenance', 'Software & Subscriptions', 'Marketing & Advertising', 'Office Supplies', 'GST & Taxes', 'Bank Charges', 'Professional Fees', 'Miscellaneous'];

const MOCK_SALES = [
  { id: 1, sale_date: '2024-05-10', customer_name: 'Sharma Photography', description: 'Invoice BIC/2024-25/0045', amount: 38305, gst_amount: 6895, payment_mode: 'BANK_TRANSFER', payment_status: 'RECEIVED' },
  { id: 2, sale_date: '2024-05-09', customer_name: 'Kolkata Print House', description: 'Invoice BIC/2024-25/0044', amount: 70085, gst_amount: 12415, payment_mode: 'CHEQUE', payment_status: 'PENDING' },
  { id: 3, sale_date: '2024-05-07', customer_name: 'Royal Studios', description: 'Invoice BIC/2024-25/0043', amount: 27000, gst_amount: 4800, payment_mode: 'CASH', payment_status: 'RECEIVED' },
];

const MOCK_EXPENSES = [
  { id: 1, expense_date: '2024-05-08', category: 'Inventory Purchase', description: 'A4 Photo Paper bulk order', vendor_name: 'Rajkamal Traders', amount: 42500, gst_amount: 5100, net_amount: 42500, payment_mode: 'BANK_TRANSFER', payment_status: 'PAID' },
  { id: 2, expense_date: '2024-05-05', category: 'Electricity', description: 'Monthly electricity bill', vendor_name: 'DVC', amount: 8200, gst_amount: 0, net_amount: 8200, payment_mode: 'ONLINE', payment_status: 'PAID' },
  { id: 3, expense_date: '2024-05-01', category: 'Salaries & Wages', description: 'Staff salary - April 2024', vendor_name: '', amount: 45000, gst_amount: 0, net_amount: 45000, payment_mode: 'BANK_TRANSFER', payment_status: 'PAID' },
  { id: 4, expense_date: '2024-04-28', category: 'Transport & Logistics', description: 'DTDC courier charges', vendor_name: 'DTDC', amount: 3200, gst_amount: 576, net_amount: 3200, payment_mode: 'CASH', payment_status: 'PAID' },
];

const EMPTY_EXPENSE = { expense_date: new Date().toISOString().split('T')[0], category: '', sub_category: '', description: '', vendor_name: '', vendor_invoice_number: '', amount: '', gst_amount: '', net_amount: '', payment_mode: 'CASH', payment_status: 'PAID', notes: '' };
const EMPTY_SALE = { sale_date: new Date().toISOString().split('T')[0], customer_name: '', description: '', amount: '', gst_amount: '', payment_mode: 'CASH', payment_status: 'RECEIVED', notes: '' };

export default function SalesExpenses() {
  const { theme, addNotification } = useApp();
  const dark = theme === 'dark';
  const [tab, setTab] = useState('expenses');
  const [sales, setSales] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editEntry, setEditEntry] = useState(null);
  const [form, setForm] = useState({});
  const [saving, setSaving] = useState(false);
  const [ocrProcessing, setOcrProcessing] = useState(false);
  const [ocrResult, setOcrResult] = useState(null);
  const fileRef = useRef();
  const [dateRange, setDateRange] = useState({ from: '', to: '' });

  useEffect(() => { loadData(); }, [tab, dateRange]);

  const loadData = async () => {
    setLoading(true);
    try {
      if (window.electronAPI) {
        const filters = { from_date: dateRange.from, to_date: dateRange.to };
        if (tab === 'sales') setSales(await window.electronAPI.getSales(filters));
        else setExpenses(await window.electronAPI.getExpenses(filters));
      } else {
        if (tab === 'sales') setSales(MOCK_SALES);
        else setExpenses(MOCK_EXPENSES);
      }
    } catch { tab === 'sales' ? setSales(MOCK_SALES) : setExpenses(MOCK_EXPENSES); }
    setLoading(false);
  };

  const openNew = () => {
    setForm(tab === 'sales' ? EMPTY_SALE : EMPTY_EXPENSE);
    setEditEntry(null); setOcrResult(null); setShowModal(true);
  };

  const openEdit = (entry) => {
    setForm({ ...entry });
    setEditEntry(entry); setShowModal(true);
  };

  const f = (field) => (e) => {
    const val = e.target.value;
    setForm(prev => {
      const next = { ...prev, [field]: val };
      if (field === 'amount' || field === 'gst_amount') {
        const amt = parseFloat(next.amount) || 0;
        next.net_amount = amt;
      }
      return next;
    });
  };

  const handleSave = async () => {
    if (!form.amount) { addNotification('Amount is required', 'error'); return; }
    setSaving(true);
    try {
      let result;
      if (window.electronAPI) {
        if (tab === 'sales') {
          result = editEntry ? await window.electronAPI.updateSale(editEntry.id, form) : await window.electronAPI.createSale(form);
        } else {
          result = editEntry ? await window.electronAPI.updateExpense(editEntry.id, form) : await window.electronAPI.createExpense(form);
        }
      } else { result = { success: true }; }
      if (result.success) {
        addNotification(editEntry ? 'Entry updated!' : 'Entry added!', 'success');
        setShowModal(false); loadData();
      }
    } catch { addNotification('Error saving entry', 'error'); }
    setSaving(false);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this entry?')) return;
    try {
      if (window.electronAPI) {
        tab === 'sales' ? await window.electronAPI.deleteSale(id) : await window.electronAPI.deleteExpense(id);
      }
      addNotification('Deleted', 'success'); loadData();
    } catch { addNotification('Error', 'error'); }
  };

  const handleOCR = async (file) => {
    if (!file) return;
    setOcrProcessing(true);
    try {
      let result;
      if (window.electronAPI) {
        result = await window.electronAPI.processOCR(file.path);
      } else {
        // Simulate OCR for browser preview
        result = { success: true, parsed: { vendor_name: 'Sample Vendor Pvt Ltd', gstin: '19ABCDE1234F1Z5', invoice_number: 'INV-2024-001', invoice_date: '2024-05-08', amount: 15000, gst_amount: 2700 } };
      }
      if (result.success) {
        setOcrResult(result.parsed);
        setForm(prev => ({
          ...prev,
          vendor_name: result.parsed.vendor_name || prev.vendor_name,
          vendor_invoice_number: result.parsed.invoice_number || prev.vendor_invoice_number,
          expense_date: result.parsed.invoice_date || prev.expense_date,
          amount: result.parsed.amount || prev.amount,
          gst_amount: result.parsed.gst_amount || prev.gst_amount,
          net_amount: result.parsed.amount || prev.net_amount,
          description: `Invoice from ${result.parsed.vendor_name || 'Vendor'}`,
        }));
        addNotification('OCR extraction complete!', 'success');
      }
    } catch (err) { addNotification('OCR failed: ' + err.message, 'error'); }
    setOcrProcessing(false);
  };

  const data = tab === 'sales' ? sales : expenses;
  const totalAmt = data.reduce((s, e) => s + (e.amount || 0), 0);
  const totalGST = data.reduce((s, e) => s + (e.gst_amount || 0), 0);

  const inputCls = `w-full px-3 py-2 rounded-lg text-xs border focus:outline-none focus:border-primary-500 transition-colors allow-select
    ${dark ? 'bg-dark-700 border-dark-600 text-white placeholder-dark-500' : 'bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400'}`;
  const labelCls = `block text-xs font-semibold mb-1 ${dark ? 'text-dark-300' : 'text-gray-600'}`;

  return (
    <div className="p-6 space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className={`font-display font-bold text-2xl ${dark ? 'text-white' : 'text-gray-900'}`}>Sales & Expenses</h1>
          <p className={`text-sm ${dark ? 'text-dark-400' : 'text-gray-500'}`}>Track income and expenditure</p>
        </div>
        <button onClick={openNew} className="flex items-center gap-2 px-4 py-2 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-sm font-semibold transition-all shadow-lg shadow-primary-500/20">
          + Add {tab === 'sales' ? 'Sale' : 'Expense'}
        </button>
      </div>

      {/* Tabs */}
      <div className={`flex items-center gap-1 p-1 rounded-xl border w-fit ${dark ? 'bg-dark-800 border-dark-600' : 'bg-gray-100 border-gray-200'}`}>
        {[['expenses', '📊 Expenses'], ['sales', '📈 Sales']].map(([t, label]) => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${tab === t ? 'bg-primary-600 text-white shadow' : dark ? 'text-dark-400 hover:text-white' : 'text-gray-500 hover:text-gray-900'}`}>
            {label}
          </button>
        ))}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: tab === 'sales' ? 'Total Revenue' : 'Total Expenses', value: fmt(totalAmt), color: tab === 'sales' ? 'text-green-400' : 'text-red-400' },
          { label: 'GST Component', value: fmt(totalGST), color: 'text-purple-400' },
          { label: 'Net Amount', value: fmt(totalAmt - totalGST), color: 'text-primary-400' },
          { label: 'Entries', value: data.length, color: 'text-cyan-400' },
        ].map((s, i) => (
          <div key={i} className={`p-4 rounded-xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100'}`}>
            <p className={`text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{s.label}</p>
            <p className={`font-display font-bold text-lg mt-1 ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Date filter */}
      <div className={`flex items-center gap-3 p-3 rounded-xl border ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100'}`}>
        <span className={`text-xs font-medium ${dark ? 'text-dark-400' : 'text-gray-500'}`}>Filter:</span>
        <input type="date" value={dateRange.from} onChange={e => setDateRange(d => ({ ...d, from: e.target.value }))}
          className={`px-3 py-1.5 rounded-lg text-xs border focus:outline-none allow-select ${dark ? 'bg-dark-700 border-dark-600 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'}`} />
        <span className={`text-xs ${dark ? 'text-dark-500' : 'text-gray-400'}`}>to</span>
        <input type="date" value={dateRange.to} onChange={e => setDateRange(d => ({ ...d, to: e.target.value }))}
          className={`px-3 py-1.5 rounded-lg text-xs border focus:outline-none allow-select ${dark ? 'bg-dark-700 border-dark-600 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'}`} />
        {(dateRange.from || dateRange.to) && (
          <button onClick={() => setDateRange({ from: '', to: '' })} className="text-xs text-red-400 hover:text-red-300 transition-colors">Clear</button>
        )}
      </div>

      {/* Table */}
      <div className={`rounded-2xl border overflow-hidden ${dark ? 'bg-dark-800/50 border-dark-600/50' : 'bg-white border-gray-100 shadow-sm'}`}>
        <table className="w-full">
          <thead>
            <tr className={`border-b text-xs font-semibold ${dark ? 'bg-dark-700/50 border-dark-600 text-dark-400' : 'bg-gray-50 border-gray-100 text-gray-500'}`}>
              <th className="text-left px-4 py-3">Date</th>
              <th className="text-left px-4 py-3">{tab === 'sales' ? 'Customer' : 'Category'}</th>
              <th className="text-left px-4 py-3">Description</th>
              {tab === 'expenses' && <th className="text-left px-4 py-3">Vendor</th>}
              <th className="text-right px-4 py-3">Amount</th>
              <th className="text-right px-4 py-3">GST</th>
              <th className="text-left px-4 py-3">Mode</th>
              <th className="text-center px-4 py-3">Status</th>
              <th className="text-center px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody className={`divide-y ${dark ? 'divide-dark-700/40' : 'divide-gray-50'}`}>
            {loading ? (
              <tr><td colSpan={9} className="text-center py-12"><div className="w-6 h-6 border-2 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto" /></td></tr>
            ) : data.length === 0 ? (
              <tr><td colSpan={9} className={`text-center py-12 text-sm ${dark ? 'text-dark-400' : 'text-gray-400'}`}>No entries found.</td></tr>
            ) : data.map(entry => (
              <tr key={entry.id} className={`transition-colors ${dark ? 'hover:bg-dark-700/30' : 'hover:bg-gray-50'}`}>
                <td className={`px-4 py-3 text-xs ${dark ? 'text-dark-300' : 'text-gray-600'}`}>{entry.expense_date || entry.sale_date}</td>
                <td className={`px-4 py-3 text-xs font-medium ${dark ? 'text-white' : 'text-gray-900'}`}>{tab === 'sales' ? entry.customer_name : entry.category}</td>
                <td className={`px-4 py-3 text-xs ${dark ? 'text-dark-300' : 'text-gray-500'}`}>{entry.description}</td>
                {tab === 'expenses' && <td className={`px-4 py-3 text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{entry.vendor_name || '—'}</td>}
                <td className={`px-4 py-3 text-xs text-right font-semibold ${dark ? 'text-white' : 'text-gray-900'}`}>{fmt(entry.amount)}</td>
                <td className={`px-4 py-3 text-xs text-right ${dark ? 'text-dark-400' : 'text-gray-400'}`}>{entry.gst_amount > 0 ? fmt(entry.gst_amount) : '—'}</td>
                <td className={`px-4 py-3 text-xs ${dark ? 'text-dark-400' : 'text-gray-500'}`}>{entry.payment_mode}</td>
                <td className="px-4 py-3 text-center">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${
                    (entry.payment_status === 'PAID' || entry.payment_status === 'RECEIVED') ? 'bg-green-500/10 text-green-400 border-green-500/20' :
                    entry.payment_status === 'PENDING' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
                    'bg-red-500/10 text-red-400 border-red-500/20'}`}>
                    {entry.payment_status}
                  </span>
                </td>
                <td className="px-4 py-3 text-center">
                  <div className="flex items-center justify-center gap-1">
                    <button onClick={() => openEdit(entry)} className={`p-1.5 rounded-lg transition-colors ${dark ? 'hover:bg-dark-600 text-dark-400 hover:text-blue-400' : 'hover:bg-gray-100 text-gray-400 hover:text-blue-600'}`}>
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                    </button>
                    <button onClick={() => handleDelete(entry.id)} className={`p-1.5 rounded-lg transition-colors ${dark ? 'hover:bg-dark-600 text-dark-400 hover:text-red-400' : 'hover:bg-gray-100 text-gray-400 hover:text-red-500'}`}>
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3,6 5,6 21,6"/><path d="M19,6l-1,14H6L5,6"/><path d="M10,11v6"/><path d="M14,11v6"/><path d="M9,6V4h6v2"/></svg>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className={`w-full max-w-xl rounded-2xl border shadow-2xl max-h-[90vh] overflow-y-auto ${dark ? 'bg-dark-800 border-dark-600' : 'bg-white border-gray-200'}`}>
            <div className={`flex items-center justify-between p-5 border-b sticky top-0 z-10 ${dark ? 'bg-dark-800 border-dark-600' : 'bg-white border-gray-100'}`}>
              <h2 className={`font-display font-bold text-lg ${dark ? 'text-white' : 'text-gray-900'}`}>
                {editEntry ? 'Edit' : 'Add'} {tab === 'sales' ? 'Sale Entry' : 'Expense Entry'}
              </h2>
              <button onClick={() => setShowModal(false)} className={`p-2 rounded-xl ${dark ? 'hover:bg-dark-700 text-dark-400' : 'hover:bg-gray-100 text-gray-400'}`}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-5 space-y-4">
              {/* OCR Upload (expenses only) */}
              {tab === 'expenses' && !editEntry && (
                <div className={`p-4 rounded-xl border-2 border-dashed text-center transition-colors ${dark ? 'border-dark-600 hover:border-primary-500/50' : 'border-gray-200 hover:border-primary-400'}`}>
                  <input type="file" ref={fileRef} className="hidden" accept="image/*,.pdf" onChange={e => handleOCR(e.target.files[0])} />
                  <button onClick={() => fileRef.current?.click()} className="w-full" disabled={ocrProcessing}>
                    <div className="text-2xl mb-1">{ocrProcessing ? '⏳' : '🔍'}</div>
                    <p className={`text-xs font-semibold ${dark ? 'text-dark-300' : 'text-gray-600'}`}>
                      {ocrProcessing ? 'Processing OCR...' : 'Upload Bill / Invoice for Auto-Fill (OCR)'}
                    </p>
                    <p className={`text-xs mt-0.5 ${dark ? 'text-dark-500' : 'text-gray-400'}`}>Supports JPG, PNG, PDF</p>
                  </button>
                  {ocrResult && (
                    <div className="mt-2 p-2 rounded-lg bg-green-500/10 border border-green-500/20 text-left">
                      <p className="text-xs text-green-400 font-semibold">✓ OCR Extracted:</p>
                      {ocrResult.vendor_name && <p className="text-xs text-green-300">Vendor: {ocrResult.vendor_name}</p>}
                      {ocrResult.amount > 0 && <p className="text-xs text-green-300">Amount: ₹{ocrResult.amount}</p>}
                    </div>
                  )}
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelCls}>{tab === 'sales' ? 'Sale Date' : 'Expense Date'} *</label>
                  <input type="date" value={form.sale_date || form.expense_date || ''} onChange={e => setForm(p => ({ ...p, [tab === 'sales' ? 'sale_date' : 'expense_date']: e.target.value }))} className={inputCls} />
                </div>

                {tab === 'expenses' ? (
                  <>
                    <div>
                      <label className={labelCls}>Category *</label>
                      <select value={form.category} onChange={f('category')} className={inputCls}>
                        <option value="">Select category</option>
                        {EXPENSE_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                    <div><label className={labelCls}>Vendor Name</label><input value={form.vendor_name || ''} onChange={f('vendor_name')} className={inputCls} /></div>
                    <div><label className={labelCls}>Vendor Invoice #</label><input value={form.vendor_invoice_number || ''} onChange={f('vendor_invoice_number')} className={`${inputCls} font-mono`} /></div>
                  </>
                ) : (
                  <div><label className={labelCls}>Customer Name</label><input value={form.customer_name || ''} onChange={f('customer_name')} className={inputCls} /></div>
                )}

                <div className="col-span-2">
                  <label className={labelCls}>Description</label>
                  <input value={form.description || ''} onChange={f('description')} className={inputCls} placeholder="Brief description" />
                </div>

                <div>
                  <label className={labelCls}>Amount (₹) *</label>
                  <input type="number" min="0" value={form.amount || ''} onChange={f('amount')} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>GST Amount (₹)</label>
                  <input type="number" min="0" value={form.gst_amount || ''} onChange={f('gst_amount')} className={inputCls} />
                </div>

                <div>
                  <label className={labelCls}>Payment Mode</label>
                  <select value={form.payment_mode || 'CASH'} onChange={f('payment_mode')} className={inputCls}>
                    {['CASH', 'BANK_TRANSFER', 'CHEQUE', 'UPI', 'ONLINE', 'CREDIT'].map(m => <option key={m} value={m}>{m}</option>)}
                  </select>
                </div>
                <div>
                  <label className={labelCls}>Status</label>
                  <select value={form.payment_status || (tab === 'sales' ? 'RECEIVED' : 'PAID')} onChange={f('payment_status')} className={inputCls}>
                    {tab === 'sales' ? ['RECEIVED', 'PENDING', 'PARTIAL'] : ['PAID', 'PENDING', 'PARTIAL']}
                    {(tab === 'sales' ? ['RECEIVED', 'PENDING', 'PARTIAL'] : ['PAID', 'PENDING', 'PARTIAL']).map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>

                <div className="col-span-2"><label className={labelCls}>Notes</label><textarea value={form.notes || ''} onChange={f('notes')} rows={2} className={`${inputCls} resize-none`} /></div>
              </div>
            </div>
            <div className={`flex gap-3 p-5 border-t ${dark ? 'border-dark-600' : 'border-gray-100'}`}>
              <button onClick={() => setShowModal(false)} className={`flex-1 py-2 rounded-xl text-sm font-medium border transition-colors ${dark ? 'border-dark-600 text-dark-300 hover:bg-dark-700' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}>Cancel</button>
              <button onClick={handleSave} disabled={saving} className="flex-1 py-2 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-sm font-semibold transition-colors flex items-center justify-center gap-2">
                {saving && <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
                {editEntry ? 'Update' : 'Save Entry'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import { jsPDF } from 'jspdf';
import 'jspdf-autotable';

const INR = (n) => new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2 }).format(n || 0);

function numberToWords(n) {
  const a = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
    'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  const num = Math.round(n);
  if (num === 0) return 'Zero';
  if (num < 20) return a[num];
  if (num < 100) return b[Math.floor(num / 10)] + (num % 10 ? ' ' + a[num % 10] : '');
  if (num < 1000) return a[Math.floor(num / 100)] + ' Hundred' + (num % 100 ? ' ' + numberToWords(num % 100) : '');
  if (num < 100000) return numberToWords(Math.floor(num / 1000)) + ' Thousand' + (num % 1000 ? ' ' + numberToWords(num % 1000) : '');
  if (num < 10000000) return numberToWords(Math.floor(num / 100000)) + ' Lakh' + (num % 100000 ? ' ' + numberToWords(num % 100000) : '');
  return numberToWords(Math.floor(num / 10000000)) + ' Crore' + (num % 10000000 ? ' ' + numberToWords(num % 10000000) : '');
}

export async function generateInvoicePDF(invoice, settings = {}) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const W = 210, M = 12;
  let y = M;

  const co = { primary: [30, 64, 175], dark: [15, 23, 42], mid: [71, 85, 105], light: [148, 163, 184], border: [226, 232, 240], bg: [248, 250, 252] };

  // ─── HEADER ──────────────────────────────────────────────────────────
  // Blue header bar
  doc.setFillColor(...co.primary);
  doc.rect(0, 0, W, 28, 'F');

  // Company name
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text(settings.company_name || 'BIC Industries Private Limited', M, 11);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  const compAddr = [settings.address, settings.city, settings.state].filter(Boolean).join(', ');
  doc.text(compAddr || 'Durgapur, West Bengal', M, 17);
  doc.text(`GSTIN: ${settings.gstin || 'N/A'}  |  Ph: ${settings.phone || 'N/A'}  |  ${settings.email || ''}`, M, 22);

  // TAX INVOICE label (right)
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('TAX INVOICE', W - M, 14, { align: 'right' });
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text('Original for Recipient', W - M, 20, { align: 'right' });

  y = 34;

  // ─── INVOICE META ────────────────────────────────────────────────────
  doc.setFillColor(...co.bg);
  doc.roundedRect(M, y, W - 2 * M, 20, 2, 2, 'F');
  doc.setDrawColor(...co.border);
  doc.roundedRect(M, y, W - 2 * M, 20, 2, 2, 'S');

  doc.setTextColor(...co.mid);
  doc.setFontSize(7);
  doc.text('INVOICE NO.', M + 4, y + 5);
  doc.text('DATE', 75, y + 5);
  doc.text('DUE DATE', 115, y + 5);
  doc.text('PAYMENT MODE', 155, y + 5);

  doc.setTextColor(...co.dark);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text(invoice.invoice_number || '', M + 4, y + 12);
  doc.setFont('helvetica', 'normal');
  doc.text(invoice.invoice_date || '', 75, y + 12);
  doc.text(invoice.due_date || '-', 115, y + 12);
  doc.text(invoice.payment_mode || 'CASH', 155, y + 12);

  y += 26;

  // ─── BILL TO / SHIP TO ───────────────────────────────────────────────
  const colW = (W - 2 * M) / 2 - 3;

  // Bill To
  doc.setFillColor(...co.primary);
  doc.rect(M, y, colW, 6, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'bold');
  doc.text('BILL TO', M + 3, y + 4.2);

  doc.setFillColor(240, 245, 255);
  doc.rect(M, y + 6, colW, 26, 'F');
  doc.setDrawColor(...co.border);
  doc.rect(M, y, colW, 32, 'S');

  doc.setTextColor(...co.dark);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text(invoice.customer_name || '', M + 3, y + 12);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(...co.mid);
  const billLines = (invoice.billing_address || '').split('\n').slice(0, 3);
  billLines.forEach((line, i) => doc.text(line, M + 3, y + 18 + i * 5));
  if (invoice.customer_gstin) {
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(...co.dark);
    doc.text(`GSTIN: ${invoice.customer_gstin}`, M + 3, y + 33);
  }

  // Ship To
  const sx = M + colW + 6;
  doc.setFillColor(...co.primary);
  doc.rect(sx, y, colW, 6, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text('SHIP TO', sx + 3, y + 4.2);

  doc.setFillColor(240, 245, 255);
  doc.rect(sx, y + 6, colW, 26, 'F');
  doc.setDrawColor(...co.border);
  doc.rect(sx, y, colW, 32, 'S');

  doc.setTextColor(...co.dark);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text(invoice.customer_name || '', sx + 3, y + 12);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(...co.mid);
  const shipLines = (invoice.shipping_address || invoice.billing_address || '').split('\n').slice(0, 3);
  shipLines.forEach((line, i) => doc.text(line, sx + 3, y + 18 + i * 5));

  y += 38;

  // ─── ITEMS TABLE ─────────────────────────────────────────────────────
  const items = invoice.items || [];
  const useIGST = items.some(i => (i.igst_amount || 0) > 0);

  const headStyles = { fillColor: co.primary, textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 7.5, cellPadding: 2.5 };
  const bodyStyles = { fontSize: 7.5, cellPadding: 2.5, textColor: co.dark };
  const altStyles = { fillColor: [248, 250, 252] };

  const columns = [
    { header: '#', dataKey: 'sn' },
    { header: 'Description', dataKey: 'desc' },
    { header: 'HSN/SAC', dataKey: 'hsn' },
    { header: 'Qty', dataKey: 'qty' },
    { header: 'Rate (₹)', dataKey: 'rate' },
    { header: 'Taxable Amt', dataKey: 'taxable' },
    ...(useIGST
      ? [{ header: 'IGST', dataKey: 'igst' }]
      : [{ header: 'CGST', dataKey: 'cgst' }, { header: 'SGST', dataKey: 'sgst' }]),
    { header: 'Total (₹)', dataKey: 'total' },
  ];

  const rows = items.map((item, i) => ({
    sn: i + 1,
    desc: item.item_name + (item.description ? `\n${item.description}` : ''),
    hsn: item.hsn_sac || '',
    qty: `${item.quantity} ${item.unit || ''}`,
    rate: INR(item.rate),
    taxable: INR(item.taxable_amount),
    ...(useIGST
      ? { igst: `${item.igst_rate || 0}%\n₹${INR(item.igst_amount)}` }
      : { cgst: `${item.cgst_rate || 0}%\n₹${INR(item.cgst_amount)}`, sgst: `${item.sgst_rate || 0}%\n₹${INR(item.sgst_amount)}` }),
    total: INR(item.total_amount),
  }));

  doc.autoTable({
    startY: y,
    columns,
    body: rows,
    headStyles,
    bodyStyles,
    alternateRowStyles: altStyles,
    columnStyles: {
      sn: { cellWidth: 8, halign: 'center' },
      desc: { cellWidth: 55 },
      hsn: { cellWidth: 18, halign: 'center' },
      qty: { cellWidth: 18, halign: 'center' },
      rate: { cellWidth: 22, halign: 'right' },
      taxable: { cellWidth: 26, halign: 'right' },
      cgst: { cellWidth: 18, halign: 'right' },
      sgst: { cellWidth: 18, halign: 'right' },
      igst: { cellWidth: 22, halign: 'right' },
      total: { cellWidth: 26, halign: 'right', fontStyle: 'bold' },
    },
    margin: { left: M, right: M },
    theme: 'grid',
    tableLineColor: co.border,
    tableLineWidth: 0.3,
  });

  y = doc.lastAutoTable.finalY + 4;

  // ─── TOTALS ──────────────────────────────────────────────────────────
  const totW = 75, totX = W - M - totW;
  const totRows = [
    ['Subtotal (Taxable Value)', `₹${INR(invoice.subtotal)}`],
    ...(invoice.cgst_amount > 0 ? [[`CGST`, `₹${INR(invoice.cgst_amount)}`]] : []),
    ...(invoice.sgst_amount > 0 ? [[`SGST`, `₹${INR(invoice.sgst_amount)}`]] : []),
    ...(invoice.igst_amount > 0 ? [[`IGST`, `₹${INR(invoice.igst_amount)}`]] : []),
    ...(invoice.round_off && invoice.round_off !== 0 ? [[`Round Off`, `₹${INR(invoice.round_off)}`]] : []),
  ];

  totRows.forEach(([k, v], i) => {
    const ty = y + i * 7;
    doc.setFillColor(...(i % 2 === 0 ? co.bg : [255, 255, 255]));
    doc.rect(totX, ty, totW, 7, 'F');
    doc.setDrawColor(...co.border);
    doc.rect(totX, ty, totW, 7, 'S');
    doc.setTextColor(...co.mid);
    doc.setFontSize(7.5);
    doc.setFont('helvetica', 'normal');
    doc.text(k, totX + 3, ty + 4.8);
    doc.setTextColor(...co.dark);
    doc.text(v, totX + totW - 3, ty + 4.8, { align: 'right' });
  });

  const grandY = y + totRows.length * 7;
  doc.setFillColor(...co.primary);
  doc.rect(totX, grandY, totW, 9, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('GRAND TOTAL', totX + 3, grandY + 6);
  doc.text(`₹${INR(invoice.grand_total)}`, totX + totW - 3, grandY + 6, { align: 'right' });

  // Amount in words
  doc.setTextColor(...co.mid);
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(7.5);
  doc.text(`Amount in Words: ${numberToWords(Math.round(invoice.grand_total))} Rupees Only`, M, grandY + 6);

  y = grandY + 16;

  // ─── TRANSPORT ───────────────────────────────────────────────────────
  if (invoice.transport_name || invoice.vehicle_number || invoice.eway_bill) {
    doc.setFillColor(...co.bg);
    doc.roundedRect(M, y, W - 2 * M, 16, 2, 2, 'F');
    doc.setDrawColor(...co.border);
    doc.roundedRect(M, y, W - 2 * M, 16, 2, 2, 'S');

    doc.setTextColor(...co.primary);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    doc.text('TRANSPORT DETAILS', M + 4, y + 5);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(...co.mid);
    const tFields = [
      ['Transporter', invoice.transport_name],
      ['Vehicle No.', invoice.vehicle_number],
      ['LR No.', invoice.lr_number],
      ['E-Way Bill', invoice.eway_bill],
    ].filter(([, v]) => v);
    tFields.forEach(([k, v], i) => {
      const tx = M + 4 + i * 46;
      doc.setTextColor(...co.mid);
      doc.text(k + ':', tx, y + 11);
      doc.setTextColor(...co.dark);
      doc.setFont('helvetica', 'bold');
      doc.text(v || '', tx + 18, y + 11);
      doc.setFont('helvetica', 'normal');
    });
    y += 22;
  }

  // ─── BANK + TERMS ────────────────────────────────────────────────────
  const bW = (W - 2 * M) / 2 - 3;

  // Bank Details
  if (settings.bank_name || settings.account_number) {
    doc.setFillColor(...co.bg);
    doc.rect(M, y, bW, 28, 'F');
    doc.setDrawColor(...co.border);
    doc.rect(M, y, bW, 28, 'S');

    doc.setTextColor(...co.primary);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.text('BANK DETAILS', M + 3, y + 5);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    [
      ['Bank', settings.bank_name],
      ['A/C No.', settings.account_number],
      ['IFSC', settings.ifsc_code],
      ['A/C Holder', settings.account_holder],
    ].filter(([, v]) => v).forEach(([k, v], i) => {
      doc.setTextColor(...co.mid);
      doc.text(`${k}:`, M + 3, y + 12 + i * 5);
      doc.setTextColor(...co.dark);
      doc.setFont('helvetica', 'bold');
      doc.text(v, M + 22, y + 12 + i * 5);
      doc.setFont('helvetica', 'normal');
    });
  }

  // Terms
  const tx2 = M + bW + 6;
  doc.setFillColor(...co.bg);
  doc.rect(tx2, y, bW, 28, 'F');
  doc.setDrawColor(...co.border);
  doc.rect(tx2, y, bW, 28, 'S');
  doc.setTextColor(...co.primary);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text('TERMS & CONDITIONS', tx2 + 3, y + 5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...co.mid);
  const terms = (invoice.terms_conditions || '1. Goods once sold will not be taken back.\n2. Interest @ 18% p.a. on overdue.').split('\n');
  terms.slice(0, 4).forEach((line, i) => doc.text(line, tx2 + 3, y + 12 + i * 5));

  y += 34;

  // ─── SIGNATURE ───────────────────────────────────────────────────────
  doc.setDrawColor(...co.border);
  doc.line(W - M - 60, y + 16, W - M, y + 16);
  doc.setTextColor(...co.mid);
  doc.setFontSize(7.5);
  doc.text('Authorised Signatory', W - M - 30, y + 21, { align: 'center' });
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...co.dark);
  doc.text(settings.company_name || 'BIC Industries Private Limited', W - M - 30, y + 26, { align: 'center' });

  // Footer
  doc.setFillColor(...co.primary);
  doc.rect(0, 287, W, 10, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.text('This is a computer generated invoice.', W / 2, 293, { align: 'center' });

  // Save or open
  const filename = `${invoice.invoice_number?.replace(/\//g, '-')}.pdf`;
  doc.save(filename);
}

/**
 * BIC ERP — Shared formatting & calculation utilities
 * Import from any page: import { fmtINR, fmtShort, calcGST, numberToWords } from '../utils/numberUtils';
 */

// ── Currency formatting ───────────────────────────────────────────────────────
export const fmtINR = (n = 0, decimals = 2) =>
  new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(n);

export const fmtINR0 = (n = 0) => fmtINR(n, 0);

export const fmtShort = (n = 0) => {
  const abs = Math.abs(n);
  const sign = n < 0 ? '-' : '';
  if (abs >= 1e7) return `${sign}₹${(abs / 1e7).toFixed(2)}Cr`;
  if (abs >= 1e5) return `${sign}₹${(abs / 1e5).toFixed(2)}L`;
  if (abs >= 1e3) return `${sign}₹${(abs / 1e3).toFixed(1)}K`;
  return `${sign}₹${abs.toFixed(0)}`;
};

export const fmtNum = (n = 0) =>
  new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 }).format(n);

// ── Percentage ───────────────────────────────────────────────────────────────
export const fmtPct = (n = 0, decimals = 1) => `${(n).toFixed(decimals)}%`;

export const growthBadge = (curr, prev) => {
  if (!prev) return null;
  const pct = ((curr - prev) / Math.abs(prev)) * 100;
  return { pct, positive: pct >= 0, label: `${pct >= 0 ? '↑' : '↓'} ${Math.abs(pct).toFixed(1)}%` };
};

// ── GST calculator ────────────────────────────────────────────────────────────
/**
 * Calculate GST on a line item.
 * @param {number} taxableAmount  — value after discount
 * @param {number} gstRate        — total GST % (e.g. 18)
 * @param {boolean} isInterState  — IGST if true, else CGST+SGST
 * @returns {{ cgst, sgst, igst, total }}
 */
export const calcGST = (taxableAmount, gstRate, isInterState = false) => {
  const rate = parseFloat(gstRate) || 0;
  if (isInterState) {
    const igst = (taxableAmount * rate) / 100;
    return { cgst: 0, sgst: 0, igst, total: igst, cgstRate: 0, sgstRate: 0, igstRate: rate };
  }
  const half = rate / 2;
  const cgst = (taxableAmount * half) / 100;
  const sgst = (taxableAmount * half) / 100;
  return { cgst, sgst, igst: 0, total: cgst + sgst, cgstRate: half, sgstRate: half, igstRate: 0 };
};

/**
 * Compute a full invoice line item from raw inputs.
 */
export const calcLineItem = (item, isInterState = false) => {
  const qty     = parseFloat(item.quantity)        || 0;
  const rate    = parseFloat(item.rate)            || 0;
  const discPct = parseFloat(item.discount_percent) || 0;
  const gstRate = parseFloat(item.gst_rate)        || 18;

  const gross        = qty * rate;
  const discAmt      = (gross * discPct) / 100;
  const taxable      = gross - discAmt;
  const gst          = calcGST(taxable, gstRate, isInterState);
  const totalAmount  = taxable + gst.total;

  return {
    ...item,
    discount_amount : discAmt,
    taxable_amount  : taxable,
    cgst_rate       : gst.cgstRate,
    sgst_rate       : gst.sgstRate,
    igst_rate       : gst.igstRate,
    cgst_amount     : gst.cgst,
    sgst_amount     : gst.sgst,
    igst_amount     : gst.igst,
    total_amount    : totalAmount,
  };
};

/**
 * Sum all line items into invoice-level totals.
 */
export const sumLineItems = (items) =>
  items.reduce(
    (acc, i) => ({
      subtotal : acc.subtotal + (i.taxable_amount  || 0),
      cgst     : acc.cgst    + (i.cgst_amount      || 0),
      sgst     : acc.sgst    + (i.sgst_amount      || 0),
      igst     : acc.igst    + (i.igst_amount      || 0),
      total    : acc.total   + (i.total_amount     || 0),
    }),
    { subtotal: 0, cgst: 0, sgst: 0, igst: 0, total: 0 }
  );

// ── Number to words (Indian system) ──────────────────────────────────────────
const ones  = ['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine',
                'Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen',
                'Seventeen','Eighteen','Nineteen'];
const tens  = ['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety'];

function _words(n) {
  if (n === 0)  return '';
  if (n < 20)   return ones[n];
  if (n < 100)  return tens[Math.floor(n / 10)] + (n % 10 ? ' ' + ones[n % 10] : '');
  if (n < 1000) return ones[Math.floor(n / 100)] + ' Hundred' + (n % 100 ? ' ' + _words(n % 100) : '');
  if (n < 1e5)  return _words(Math.floor(n / 1000)) + ' Thousand' + (n % 1000 ? ' ' + _words(n % 1000) : '');
  if (n < 1e7)  return _words(Math.floor(n / 1e5))  + ' Lakh'     + (n % 1e5  ? ' ' + _words(n % 1e5)  : '');
  return          _words(Math.floor(n / 1e7))        + ' Crore'    + (n % 1e7  ? ' ' + _words(n % 1e7)  : '');
}

export const numberToWords = (n) => {
  const rounded = Math.round(Math.abs(n || 0));
  if (rounded === 0) return 'Zero Rupees Only';
  const rupees  = Math.floor(rounded);
  const paise   = Math.round((Math.abs(n) - rupees) * 100);
  let result    = (_words(rupees) || 'Zero') + ' Rupees';
  if (paise > 0) result += ' and ' + _words(paise) + ' Paise';
  return result + ' Only';
};

// ── Date helpers ──────────────────────────────────────────────────────────────
export const today = () => new Date().toISOString().split('T')[0];

export const addDays = (dateStr, days) => {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + days);
  return d.toISOString().split('T')[0];
};

export const fmtDate = (dateStr) => {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
};

export const currentFY = () => {
  const now = new Date();
  const year = now.getMonth() >= 3 ? now.getFullYear() : now.getFullYear() - 1;
  return `${year}-${String(year + 1).slice(2)}`;
};

export const fyDateRange = (fy) => {
  const [startY] = fy.split('-');
  return {
    from : `${startY}-04-01`,
    to   : `${parseInt(startY) + 1}-03-31`,
  };
};

// ── GSTIN validator ───────────────────────────────────────────────────────────
export const isValidGSTIN = (gstin) =>
  /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[A-Z0-9]{1}[Z]{1}[A-Z0-9]{1}$/.test(gstin || '');

export const isValidPAN = (pan) =>
  /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(pan || '');

export const isValidMobile = (mob) =>
  /^[6-9]\d{9}$/.test(mob || '');

// ── State code lookup ─────────────────────────────────────────────────────────
export const STATE_CODES = {
  'Andhra Pradesh':'37','Arunachal Pradesh':'12','Assam':'18','Bihar':'10',
  'Chhattisgarh':'22','Goa':'30','Gujarat':'24','Haryana':'06',
  'Himachal Pradesh':'02','Jharkhand':'20','Karnataka':'29','Kerala':'32',
  'Madhya Pradesh':'23','Maharashtra':'27','Manipur':'14','Meghalaya':'17',
  'Mizoram':'15','Nagaland':'13','Odisha':'21','Punjab':'03','Rajasthan':'08',
  'Sikkim':'11','Tamil Nadu':'33','Telangana':'36','Tripura':'16',
  'Uttar Pradesh':'09','Uttarakhand':'05','West Bengal':'19','Delhi':'07',
  'Jammu and Kashmir':'01','Ladakh':'38',
  'Andaman and Nicobar Islands':'35','Chandigarh':'04',
  'Dadra and Nagar Haveli':'26','Daman and Diu':'25',
  'Lakshadweep':'31','Puducherry':'34',
};

export const INDIAN_STATES = Object.keys(STATE_CODES);

const { app, BrowserWindow, ipcMain, dialog, shell, Menu } = require('electron');
const path = require('path');

const isDev  = !!process.env.ELECTRON_START_URL;
const isProd = app.isPackaged;

// ── Database ──────────────────────────────────────────────────────────────────
const db = require('../database/db');

// ── IPC Handlers ──────────────────────────────────────────────────────────────
const invoiceHandlers   = require('./handlers/invoiceHandlers');
const customerHandlers  = require('./handlers/customerHandlers');
const inventoryHandlers = require('./handlers/inventoryHandlers');
const salesHandlers     = require('./handlers/salesHandlers');
const authHandlers      = require('./handlers/authHandlers');
const reportHandlers    = require('./handlers/reportHandlers');
const ocrHandlers       = require('./handlers/ocrHandlers');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1200,
    minHeight: 700,
    frame: false,
    titleBarStyle: 'hidden',
    icon: path.join(__dirname, isProd ? '../../icon.ico' : '../../public/icon.ico'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
      preload: path.join(__dirname, 'preload.js'),
      webSecurity: true,
    },
    backgroundColor: '#0f172a',
    show: false,
    autoHideMenuBar: true,
  });

  if (isProd) Menu.setApplicationMenu(null);

  const startURL = process.env.ELECTRON_START_URL
    || `file://${path.join(__dirname, '../../build/index.html')}`;
  mainWindow.loadURL(startURL);

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    mainWindow.focus();
    if (isDev) mainWindow.webContents.openDevTools({ mode: 'detach' });
  });

  mainWindow.on('closed', () => { mainWindow = null; });

  // Window controls
  ipcMain.on('window-minimize', () => mainWindow?.minimize());
  ipcMain.on('window-maximize', () => {
    if (mainWindow?.isMaximized()) mainWindow.restore();
    else mainWindow?.maximize();
  });
  ipcMain.on('window-close', () => mainWindow?.close());
  ipcMain.handle('window-is-maximized', () => mainWindow?.isMaximized() || false);
  mainWindow.on('maximize',   () => mainWindow?.webContents.send('window-maximized', true));
  mainWindow.on('unmaximize', () => mainWindow?.webContents.send('window-maximized', false));

  // File dialogs
  ipcMain.handle('dialog:openFile', async (_, filters) => {
    return dialog.showOpenDialog(mainWindow, {
      properties: ['openFile'],
      filters: filters || [
        { name: 'Images & PDFs', extensions: ['jpg','jpeg','png','pdf'] },
        { name: 'All Files', extensions: ['*'] },
      ],
    });
  });
  ipcMain.handle('dialog:saveFile',      async (_, opts) => dialog.showSaveDialog(mainWindow, opts));
  ipcMain.handle('dialog:openDirectory', async ()       => dialog.showOpenDialog(mainWindow, { properties: ['openDirectory'] }));

  ipcMain.handle('shell:openExternal',     (_, url)  => shell.openExternal(url));
  ipcMain.handle('shell:showItemInFolder', (_, fPath) => shell.showItemInFolder(fPath));

  ipcMain.handle('app:getVersion',  () => app.getVersion());
  ipcMain.handle('app:getUserData', () => app.getPath('userData'));
  ipcMain.handle('app:getPath',     (_, name) => app.getPath(name));

  // Register module handlers
  invoiceHandlers(ipcMain, db);
  customerHandlers(ipcMain, db);
  inventoryHandlers(ipcMain, db);
  salesHandlers(ipcMain, db);
  authHandlers(ipcMain, db);
  reportHandlers(ipcMain, db);
  ocrHandlers(ipcMain);
}

app.whenReady().then(() => {
  try {
    db.initialize();
    console.log('✅ Database ready');
  } catch (err) {
    console.error('❌ Database init failed:', err);
    dialog.showErrorBox('Database Error',
      `Failed to initialise database:\n${err.message}\n\nThe app will close.`);
    app.quit();
    return;
  }
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

process.on('uncaughtException', (err) => {
  console.error('Uncaught exception:', err);
  if (mainWindow) {
    dialog.showErrorBox('Unexpected Error',
      `An unexpected error occurred:\n${err.message}\n\nPlease restart the application.`);
  }
});

const { contextBridge, ipcRenderer } = require('electron');

// Expose safe APIs to renderer process
contextBridge.exposeInMainWorld('electronAPI', {
  // Window controls
  minimizeWindow: () => ipcRenderer.send('window-minimize'),
  maximizeWindow: () => ipcRenderer.send('window-maximize'),
  closeWindow: () => ipcRenderer.send('window-close'),

  // Auth
  login: (credentials) => ipcRenderer.invoke('auth:login', credentials),
  logout: () => ipcRenderer.invoke('auth:logout'),
  changePassword: (data) => ipcRenderer.invoke('auth:changePassword', data),

  // Customers
  getCustomers: (filters) => ipcRenderer.invoke('customers:getAll', filters),
  getCustomer: (id) => ipcRenderer.invoke('customers:getOne', id),
  createCustomer: (data) => ipcRenderer.invoke('customers:create', data),
  updateCustomer: (id, data) => ipcRenderer.invoke('customers:update', id, data),
  deleteCustomer: (id) => ipcRenderer.invoke('customers:delete', id),
  searchCustomers: (query) => ipcRenderer.invoke('customers:search', query),

  // Invoices
  getInvoices: (filters) => ipcRenderer.invoke('invoices:getAll', filters),
  getInvoice: (id) => ipcRenderer.invoke('invoices:getOne', id),
  createInvoice: (data) => ipcRenderer.invoke('invoices:create', data),
  updateInvoice: (id, data) => ipcRenderer.invoke('invoices:update', id, data),
  deleteInvoice: (id) => ipcRenderer.invoke('invoices:delete', id),
  getNextInvoiceNumber: () => ipcRenderer.invoke('invoices:nextNumber'),
  generateInvoicePDF: (id) => ipcRenderer.invoke('invoices:generatePDF', id),

  // Inventory
  getInventory: (filters) => ipcRenderer.invoke('inventory:getAll', filters),
  getInventoryItem: (id) => ipcRenderer.invoke('inventory:getOne', id),
  createInventoryItem: (data) => ipcRenderer.invoke('inventory:create', data),
  updateInventoryItem: (id, data) => ipcRenderer.invoke('inventory:update', id, data),
  deleteInventoryItem: (id) => ipcRenderer.invoke('inventory:delete', id),
  stockMovement: (data) => ipcRenderer.invoke('inventory:stockMovement', data),
  getStockMovements: (itemId) => ipcRenderer.invoke('inventory:getMovements', itemId),
  getLowStockItems: () => ipcRenderer.invoke('inventory:getLowStock'),

  // Sales & Expenses
  getSales: (filters) => ipcRenderer.invoke('sales:getAll', filters),
  createSale: (data) => ipcRenderer.invoke('sales:create', data),
  updateSale: (id, data) => ipcRenderer.invoke('sales:update', id, data),
  deleteSale: (id) => ipcRenderer.invoke('sales:delete', id),
  getExpenses: (filters) => ipcRenderer.invoke('expenses:getAll', filters),
  createExpense: (data) => ipcRenderer.invoke('expenses:create', data),
  updateExpense: (id, data) => ipcRenderer.invoke('expenses:update', id, data),
  deleteExpense: (id) => ipcRenderer.invoke('expenses:delete', id),
  getVendors: () => ipcRenderer.invoke('vendors:getAll'),
  createVendor: (data) => ipcRenderer.invoke('vendors:create', data),

  // Reports & Dashboard
  getDashboardStats: (period) => ipcRenderer.invoke('reports:dashboard', period),
  getProfitLoss: (period) => ipcRenderer.invoke('reports:profitLoss', period),
  getBalanceSheet: () => ipcRenderer.invoke('reports:balanceSheet'),
  getGSTReport: (period) => ipcRenderer.invoke('reports:gst', period),
  getMonthlySummary: (year) => ipcRenderer.invoke('reports:monthly', year),

  // OCR
  processOCR: (filePath) => ipcRenderer.invoke('ocr:process', filePath),

  // File dialogs
  openFileDialog: (filters) => ipcRenderer.invoke('dialog:openFile', filters),
  saveFileDialog: (options) => ipcRenderer.invoke('dialog:saveFile', options),
  openExternal: (url) => ipcRenderer.invoke('shell:openExternal', url),

  // Company settings
  getSettings: () => ipcRenderer.invoke('settings:get'),
  updateSettings: (data) => ipcRenderer.invoke('settings:update', data),
});

module.exports = function salesHandlers(ipcMain, db) {
  // Sales
  ipcMain.handle('sales:getAll', async (_, filters = {}) => {
    let sql = 'SELECT * FROM sales_entries WHERE 1=1';
    const params = [];
    if (filters.from_date) { sql += ' AND sale_date >= ?'; params.push(filters.from_date); }
    if (filters.to_date) { sql += ' AND sale_date <= ?'; params.push(filters.to_date); }
    sql += ' ORDER BY sale_date DESC';
    return db.query(sql, params);
  });

  ipcMain.handle('sales:create', async (_, data) => {
    const result = db.run(
      `INSERT INTO sales_entries (sale_date, customer_id, customer_name, invoice_id, description, amount, gst_amount, payment_mode, payment_status, notes, financial_year) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      [data.sale_date, data.customer_id, data.customer_name, data.invoice_id, data.description,
       data.amount, data.gst_amount || 0, data.payment_mode || 'CASH', data.payment_status || 'RECEIVED',
       data.notes, data.financial_year]
    );
    return { success: true, id: result.lastInsertRowid };
  });

  ipcMain.handle('sales:update', async (_, id, data) => {
    const fields = Object.keys(data).map(k => `${k} = ?`).join(', ');
    db.run(`UPDATE sales_entries SET ${fields} WHERE id = ?`, [...Object.values(data), id]);
    return { success: true };
  });

  ipcMain.handle('sales:delete', async (_, id) => {
    db.run('DELETE FROM sales_entries WHERE id = ?', [id]);
    return { success: true };
  });

  // Expenses
  ipcMain.handle('expenses:getAll', async (_, filters = {}) => {
    let sql = `SELECT e.*, v.name as vendor_display_name FROM expenses e 
               LEFT JOIN vendors v ON e.vendor_id = v.id WHERE 1=1`;
    const params = [];
    if (filters.from_date) { sql += ' AND e.expense_date >= ?'; params.push(filters.from_date); }
    if (filters.to_date) { sql += ' AND e.expense_date <= ?'; params.push(filters.to_date); }
    if (filters.category) { sql += ' AND e.category = ?'; params.push(filters.category); }
    sql += ' ORDER BY e.expense_date DESC';
    return db.query(sql, params);
  });

  ipcMain.handle('expenses:create', async (_, data) => {
    const result = db.run(
      `INSERT INTO expenses (expense_date, expense_number, category, sub_category, description, vendor_id, vendor_name, vendor_invoice_number, amount, gst_amount, tds_amount, net_amount, payment_mode, payment_status, bill_image_path, notes, financial_year)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [data.expense_date, data.expense_number, data.category, data.sub_category, data.description,
       data.vendor_id, data.vendor_name, data.vendor_invoice_number, data.amount, data.gst_amount || 0,
       data.tds_amount || 0, data.net_amount || data.amount, data.payment_mode || 'CASH',
       data.payment_status || 'PAID', data.bill_image_path, data.notes, data.financial_year]
    );
    return { success: true, id: result.lastInsertRowid };
  });

  ipcMain.handle('expenses:update', async (_, id, data) => {
    const fields = Object.keys(data).map(k => `${k} = ?`).join(', ');
    db.run(`UPDATE expenses SET ${fields}, updated_at = datetime('now') WHERE id = ?`, [...Object.values(data), id]);
    return { success: true };
  });

  ipcMain.handle('expenses:delete', async (_, id) => {
    db.run('DELETE FROM expenses WHERE id = ?', [id]);
    return { success: true };
  });

  // Vendors
  ipcMain.handle('vendors:getAll', async () => {
    return db.query('SELECT * FROM vendors WHERE is_active = 1 ORDER BY name');
  });

  ipcMain.handle('vendors:create', async (_, data) => {
    const result = db.run(
      `INSERT INTO vendors (name, company_name, gstin, pan, mobile, email, address, city, state, pincode, bank_name, account_number, ifsc_code, notes)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [data.name, data.company_name, data.gstin, data.pan, data.mobile, data.email, data.address,
       data.city, data.state, data.pincode, data.bank_name, data.account_number, data.ifsc_code, data.notes]
    );
    return { success: true, id: result.lastInsertRowid };
  });
};

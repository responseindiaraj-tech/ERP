module.exports = function customerHandlers(ipcMain, db) {
  ipcMain.handle('customers:getAll', async (_, filters = {}) => {
    let sql = 'SELECT * FROM customers WHERE 1=1';
    const params = [];
    if (filters.search) {
      sql += ' AND (name LIKE ? OR mobile LIKE ? OR gstin LIKE ? OR company_name LIKE ?)';
      const s = `%${filters.search}%`;
      params.push(s, s, s, s);
    }
    if (filters.active !== undefined) { sql += ' AND is_active = ?'; params.push(filters.active ? 1 : 0); }
    sql += ' ORDER BY name ASC';
    return db.query(sql, params);
  });

  ipcMain.handle('customers:getOne', async (_, id) => {
    const customer = db.queryOne('SELECT * FROM customers WHERE id = ?', [id]);
    if (!customer) return null;
    customer.invoices = db.query('SELECT id, invoice_number, invoice_date, grand_total, payment_status FROM invoices WHERE customer_id = ? ORDER BY invoice_date DESC LIMIT 20', [id]);
    return customer;
  });

  ipcMain.handle('customers:create', async (_, data) => {
    const { name, company_name, gstin, pan, mobile, alternate_mobile, email,
            address_line1, address_line2, city, state, state_code, pincode,
            customer_type, credit_limit, notes } = data;
    const result = db.run(
      `INSERT INTO customers (name, company_name, gstin, pan, mobile, alternate_mobile, email, address_line1, address_line2, city, state, state_code, pincode, customer_type, credit_limit, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [name, company_name, gstin, pan, mobile, alternate_mobile, email, address_line1, address_line2, city, state, state_code, pincode, customer_type || 'B2B', credit_limit || 0, notes]
    );
    return { success: true, id: result.lastInsertRowid };
  });

  ipcMain.handle('customers:update', async (_, id, data) => {
    const fields = Object.keys(data).map(k => `${k} = ?`).join(', ');
    const values = [...Object.values(data), id];
    db.run(`UPDATE customers SET ${fields}, updated_at = datetime('now') WHERE id = ?`, values);
    return { success: true };
  });

  ipcMain.handle('customers:delete', async (_, id) => {
    db.run('UPDATE customers SET is_active = 0 WHERE id = ?', [id]);
    return { success: true };
  });

  ipcMain.handle('customers:search', async (_, query) => {
    const s = `%${query}%`;
    return db.query('SELECT id, name, company_name, mobile, gstin, city FROM customers WHERE is_active = 1 AND (name LIKE ? OR mobile LIKE ? OR company_name LIKE ?) ORDER BY name LIMIT 10', [s, s, s]);
  });
};

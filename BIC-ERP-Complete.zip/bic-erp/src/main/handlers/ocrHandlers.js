module.exports = function ocrHandlers(ipcMain) {
  ipcMain.handle('ocr:process', async (_, filePath) => {
    try {
      const { createWorker } = require('tesseract.js');
      const worker = await createWorker('eng');
      
      const { data: { text } } = await worker.recognize(filePath);
      await worker.terminate();

      // Parse extracted text for invoice fields
      const result = parseInvoiceText(text);
      return { success: true, rawText: text, parsed: result };
    } catch (err) {
      return { success: false, message: err.message };
    }
  });
};

function parseInvoiceText(text) {
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  const result = {
    vendor_name: '',
    gstin: '',
    invoice_number: '',
    invoice_date: '',
    amount: 0,
    gst_amount: 0,
    items: []
  };

  // GSTIN pattern: 15-char alphanumeric
  const gstinMatch = text.match(/\b\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1}\b/);
  if (gstinMatch) result.gstin = gstinMatch[0];

  // Invoice number patterns
  const invoiceMatch = text.match(/(?:invoice|bill|inv)[\s#.:no]+([A-Z0-9\-\/]+)/i);
  if (invoiceMatch) result.invoice_number = invoiceMatch[1];

  // Date patterns
  const dateMatch = text.match(/(\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4})/);
  if (dateMatch) {
    const parts = dateMatch[1].split(/[\/-]/);
    if (parts[2]?.length === 2) parts[2] = '20' + parts[2];
    if (parts.length === 3) result.invoice_date = `${parts[2]}-${parts[1].padStart(2,'0')}-${parts[0].padStart(2,'0')}`;
  }

  // Amount patterns
  const totalMatch = text.match(/(?:total|grand total|amount due|payable)[:\s]+(?:rs\.?|₹)?\s*([0-9,]+(?:\.\d{2})?)/i);
  if (totalMatch) result.amount = parseFloat(totalMatch[1].replace(/,/g, ''));

  // GST amount
  const gstMatch = text.match(/(?:gst|tax)[:\s]+(?:rs\.?|₹)?\s*([0-9,]+(?:\.\d{2})?)/i);
  if (gstMatch) result.gst_amount = parseFloat(gstMatch[1].replace(/,/g, ''));

  // Vendor name (usually first few lines)
  if (lines.length > 0) result.vendor_name = lines[0];

  return result;
}

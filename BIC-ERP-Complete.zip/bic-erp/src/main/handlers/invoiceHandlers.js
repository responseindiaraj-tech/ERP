const { app } = require('electron');
const path = require('path');

module.exports = function invoiceHandlers(ipcMain, db) {
  ipcMain.handle('invoices:getAll', async (_, filters = {}) => {
    let sql = `SELECT i.*, c.name as customer_display_name 
               FROM invoices i LEFT JOIN customers c ON i.customer_id = c.id WHERE 1=1`;
    const params = [];
    if (filters.search) {
      sql += ' AND (i.invoice_number LIKE ? OR i.customer_name LIKE ?)';
      const s = `%${filters.search}%`;
      params.push(s, s);
    }
    if (filters.status) { sql += ' AND i.payment_status = ?'; params.push(filters.status); }
    if (filters.from_date) { sql += ' AND i.invoice_date >= ?'; params.push(filters.from_date); }
    if (filters.to_date) { sql += ' AND i.invoice_date <= ?'; params.push(filters.to_date); }
    sql += ' ORDER BY i.invoice_date DESC, i.id DESC';
    return db.query(sql, params);
  });

  ipcMain.handle('invoices:getOne', async (_, id) => {
    const invoice = db.queryOne('SELECT * FROM invoices WHERE id = ?', [id]);
    if (!invoice) return null;
    invoice.items = db.query('SELECT * FROM invoice_items WHERE invoice_id = ? ORDER BY sort_order', [id]);
    return invoice;
  });

  ipcMain.handle('invoices:nextNumber', async () => {
    const settings = db.queryOne('SELECT invoice_prefix, invoice_counter, financial_year FROM settings WHERE id = 1');
    const counter = String(settings.invoice_counter).padStart(4, '0');
    return `${settings.invoice_prefix}/${settings.financial_year}/${counter}`;
  });

  ipcMain.handle('invoices:create', async (_, data) => {
    return db.transaction(() => {
      const { items, ...invoiceData } = data;
      
      // Auto-generate invoice number
      const settings = db.queryOne('SELECT invoice_prefix, invoice_counter, financial_year FROM settings WHERE id = 1');
      const counter = String(settings.invoice_counter).padStart(4, '0');
      invoiceData.invoice_number = invoiceData.invoice_number || `${settings.invoice_prefix}/${settings.financial_year}/${counter}`;

      const result = db.run(
        `INSERT INTO invoices (invoice_number, invoice_date, due_date, customer_id, customer_name, customer_gstin,
         billing_address, shipping_address, place_of_supply, invoice_type, supply_type, subtotal,
         cgst_amount, sgst_amount, igst_amount, total_tax, discount_amount, round_off, grand_total,
         amount_paid, balance_due, payment_mode, payment_status, transport_name, vehicle_number,
         lr_number, eway_bill, delivery_date, notes, terms_conditions, status)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [invoiceData.invoice_number, invoiceData.invoice_date, invoiceData.due_date,
         invoiceData.customer_id, invoiceData.customer_name, invoiceData.customer_gstin,
         invoiceData.billing_address, invoiceData.shipping_address, invoiceData.place_of_supply,
         invoiceData.invoice_type || 'TAX_INVOICE', invoiceData.supply_type || 'B2B',
         invoiceData.subtotal, invoiceData.cgst_amount, invoiceData.sgst_amount,
         invoiceData.igst_amount, invoiceData.total_tax, invoiceData.discount_amount || 0,
         invoiceData.round_off || 0, invoiceData.grand_total, invoiceData.amount_paid || 0,
         invoiceData.balance_due, invoiceData.payment_mode, invoiceData.payment_status || 'PENDING',
         invoiceData.transport_name, invoiceData.vehicle_number, invoiceData.lr_number,
         invoiceData.eway_bill, invoiceData.delivery_date, invoiceData.notes,
         invoiceData.terms_conditions, invoiceData.status || 'FINAL']
      );
      
      const invoiceId = result.lastInsertRowid;
      
      // Insert items
      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        db.run(
          `INSERT INTO invoice_items (invoice_id, item_name, description, hsn_sac, quantity, unit, rate,
           discount_percent, discount_amount, taxable_amount, gst_rate, cgst_rate, sgst_rate, igst_rate,
           cgst_amount, sgst_amount, igst_amount, total_amount, sort_order)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [invoiceId, item.item_name, item.description, item.hsn_sac, item.quantity, item.unit || 'NOS',
           item.rate, item.discount_percent || 0, item.discount_amount || 0, item.taxable_amount,
           item.gst_rate || 18, item.cgst_rate || 9, item.sgst_rate || 9, item.igst_rate || 0,
           item.cgst_amount || 0, item.sgst_amount || 0, item.igst_amount || 0, item.total_amount, i]
        );
      }

      // Update invoice counter and customer outstanding
      db.run('UPDATE settings SET invoice_counter = invoice_counter + 1 WHERE id = 1');
      if (invoiceData.customer_id && invoiceData.balance_due > 0) {
        db.run('UPDATE customers SET outstanding_amount = outstanding_amount + ? WHERE id = ?',
          [invoiceData.balance_due, invoiceData.customer_id]);
      }

      // Add to sales entries
      db.run(
        `INSERT INTO sales_entries (sale_date, customer_id, customer_name, invoice_id, description, amount, gst_amount, payment_mode, payment_status, financial_year)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [invoiceData.invoice_date, invoiceData.customer_id, invoiceData.customer_name, invoiceId,
         `Invoice ${invoiceData.invoice_number}`, invoiceData.subtotal, invoiceData.total_tax,
         invoiceData.payment_mode, invoiceData.payment_status || 'PENDING',
         db.queryOne('SELECT financial_year FROM settings WHERE id = 1')?.financial_year]
      );

      return { success: true, id: invoiceId, invoice_number: invoiceData.invoice_number };
    });
  });

  ipcMain.handle('invoices:update', async (_, id, data) => {
    const { items, ...invoiceData } = data;
    db.transaction(() => {
      const fields = Object.keys(invoiceData).map(k => `${k} = ?`).join(', ');
      db.run(`UPDATE invoices SET ${fields}, updated_at = datetime('now') WHERE id = ?`,
        [...Object.values(invoiceData), id]);
      if (items) {
        db.run('DELETE FROM invoice_items WHERE invoice_id = ?', [id]);
        for (let i = 0; i < items.length; i++) {
          const item = items[i];
          db.run(
            `INSERT INTO invoice_items (invoice_id, item_name, description, hsn_sac, quantity, unit, rate,
             discount_percent, discount_amount, taxable_amount, gst_rate, cgst_rate, sgst_rate, igst_rate,
             cgst_amount, sgst_amount, igst_amount, total_amount, sort_order) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
            [id, item.item_name, item.description, item.hsn_sac, item.quantity, item.unit,
             item.rate, item.discount_percent || 0, item.discount_amount || 0, item.taxable_amount,
             item.gst_rate, item.cgst_rate, item.sgst_rate, item.igst_rate,
             item.cgst_amount, item.sgst_amount, item.igst_amount, item.total_amount, i]
          );
        }
      }
    });
    return { success: true };
  });

  ipcMain.handle('invoices:delete', async (_, id) => {
    db.run('DELETE FROM invoices WHERE id = ?', [id]);
    return { success: true };
  });
};

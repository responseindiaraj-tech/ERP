module.exports = function inventoryHandlers(ipcMain, db) {
  ipcMain.handle('inventory:getAll', async (_, filters = {}) => {
    let sql = `SELECT i.*, c.name as category_name, c.color as category_color, c.icon as category_icon
               FROM inventory_items i LEFT JOIN inventory_categories c ON i.category_id = c.id WHERE i.is_active = 1`;
    const params = [];
    if (filters.category_id) { sql += ' AND i.category_id = ?'; params.push(filters.category_id); }
    if (filters.search) {
      sql += ' AND (i.name LIKE ? OR i.sku LIKE ?)';
      const s = `%${filters.search}%`;
      params.push(s, s);
    }
    if (filters.low_stock) sql += ' AND i.current_stock <= i.reorder_point AND i.reorder_point > 0';
    sql += ' ORDER BY i.name ASC';
    return db.query(sql, params);
  });

  ipcMain.handle('inventory:getOne', async (_, id) => {
    const item = db.queryOne(`SELECT i.*, c.name as category_name FROM inventory_items i LEFT JOIN inventory_categories c ON i.category_id = c.id WHERE i.id = ?`, [id]);
    if (!item) return null;
    item.movements = db.query('SELECT * FROM stock_movements WHERE item_id = ? ORDER BY movement_date DESC LIMIT 20', [id]);
    return item;
  });

  ipcMain.handle('inventory:create', async (_, data) => {
    const { name, sku, description, category_id, item_type, unit, current_stock, min_stock_level,
            max_stock_level, reorder_point, purchase_price, selling_price, hsn_sac, gst_rate,
            location, serial_number, asset_value, is_asset, notes } = data;
    const result = db.run(
      `INSERT INTO inventory_items (name, sku, description, category_id, item_type, unit, current_stock, min_stock_level, max_stock_level, reorder_point, purchase_price, selling_price, hsn_sac, gst_rate, location, serial_number, asset_value, is_asset, notes)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [name, sku, description, category_id, item_type || 'STOCK', unit || 'NOS', current_stock || 0,
       min_stock_level || 0, max_stock_level || 0, reorder_point || 0, purchase_price || 0,
       selling_price || 0, hsn_sac, gst_rate || 18, location, serial_number, asset_value || 0,
       is_asset ? 1 : 0, notes]
    );
    return { success: true, id: result.lastInsertRowid };
  });

  ipcMain.handle('inventory:update', async (_, id, data) => {
    const fields = Object.keys(data).map(k => `${k} = ?`).join(', ');
    db.run(`UPDATE inventory_items SET ${fields}, updated_at = datetime('now') WHERE id = ?`,
      [...Object.values(data), id]);
    return { success: true };
  });

  ipcMain.handle('inventory:delete', async (_, id) => {
    db.run('UPDATE inventory_items SET is_active = 0 WHERE id = ?', [id]);
    return { success: true };
  });

  ipcMain.handle('inventory:stockMovement', async (_, data) => {
    return db.transaction(() => {
      const { item_id, movement_type, quantity, unit_price, reference_type, reference_id, reference_number, vendor_name, notes } = data;
      const total_value = quantity * (unit_price || 0);
      
      db.run(
        `INSERT INTO stock_movements (item_id, movement_type, quantity, unit_price, total_value, reference_type, reference_id, reference_number, vendor_name, notes, movement_date)
         VALUES (?,?,?,?,?,?,?,?,?,?,datetime('now'))`,
        [item_id, movement_type, quantity, unit_price || 0, total_value, reference_type, reference_id, reference_number, vendor_name, notes]
      );

      const change = ['IN', 'PURCHASE', 'RETURN_IN', 'OPENING'].includes(movement_type) ? quantity : -quantity;
      db.run('UPDATE inventory_items SET current_stock = current_stock + ?, updated_at = datetime("now") WHERE id = ?',
        [change, item_id]);

      const item = db.queryOne('SELECT current_stock, name FROM inventory_items WHERE id = ?', [item_id]);
      return { success: true, current_stock: item.current_stock };
    });
  });

  ipcMain.handle('inventory:getMovements', async (_, itemId) => {
    return db.query('SELECT * FROM stock_movements WHERE item_id = ? ORDER BY movement_date DESC', [itemId]);
  });

  ipcMain.handle('inventory:getLowStock', async () => {
    return db.query(`SELECT i.*, c.name as category_name FROM inventory_items i 
      LEFT JOIN inventory_categories c ON i.category_id = c.id
      WHERE i.is_active = 1 AND i.current_stock <= i.reorder_point AND i.reorder_point > 0
      ORDER BY (i.current_stock / NULLIF(i.reorder_point, 0)) ASC`);
  });
};

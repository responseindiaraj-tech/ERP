const bcrypt = require('bcryptjs');

module.exports = function authHandlers(ipcMain, db) {
  ipcMain.handle('auth:login', async (_, { username, password }) => {
    try {
      const user = db.queryOne('SELECT * FROM users WHERE username = ? AND is_active = 1', [username]);
      if (!user) return { success: false, message: 'Invalid username or password' };
      
      const valid = bcrypt.compareSync(password, user.password_hash);
      if (!valid) return { success: false, message: 'Invalid username or password' };

      db.run('UPDATE users SET last_login = datetime("now") WHERE id = ?', [user.id]);
      
      return {
        success: true,
        user: { id: user.id, username: user.username, full_name: user.full_name, role: user.role, email: user.email }
      };
    } catch (err) {
      return { success: false, message: err.message };
    }
  });

  ipcMain.handle('auth:changePassword', async (_, { userId, oldPassword, newPassword }) => {
    try {
      const user = db.queryOne('SELECT * FROM users WHERE id = ?', [userId]);
      if (!user) return { success: false, message: 'User not found' };
      
      const valid = bcrypt.compareSync(oldPassword, user.password_hash);
      if (!valid) return { success: false, message: 'Current password is incorrect' };

      const hash = bcrypt.hashSync(newPassword, 10);
      db.run('UPDATE users SET password_hash = ? WHERE id = ?', [hash, userId]);
      return { success: true };
    } catch (err) {
      return { success: false, message: err.message };
    }
  });

  ipcMain.handle('settings:get', async () => {
    return db.queryOne('SELECT * FROM settings WHERE id = 1');
  });

  ipcMain.handle('settings:update', async (_, data) => {
    const fields = Object.keys(data).map(k => `${k} = ?`).join(', ');
    const values = [...Object.values(data), 1];
    db.run(`UPDATE settings SET ${fields}, updated_at = datetime('now') WHERE id = ?`, values);
    return { success: true };
  });
};

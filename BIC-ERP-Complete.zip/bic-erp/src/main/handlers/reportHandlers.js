module.exports = function reportHandlers(ipcMain, db) {
  ipcMain.handle('reports:dashboard', async (_, period = 'month') => {
    const now = new Date();
    let fromDate, prevFromDate, prevToDate;

    if (period === 'month') {
      fromDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`;
      const prevMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      prevFromDate = `${prevMonth.getFullYear()}-${String(prevMonth.getMonth() + 1).padStart(2, '0')}-01`;
      prevToDate = fromDate;
    } else if (period === 'year') {
      const fy = now.getMonth() >= 3 ? now.getFullYear() : now.getFullYear() - 1;
      fromDate = `${fy}-04-01`;
      prevFromDate = `${fy - 1}-04-01`;
      prevToDate = fromDate;
    } else {
      const weekAgo = new Date(now - 7 * 24 * 60 * 60 * 1000);
      fromDate = weekAgo.toISOString().split('T')[0];
      prevFromDate = new Date(weekAgo - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
      prevToDate = fromDate;
    }

    const toDate = now.toISOString().split('T')[0];

    const salesCurrent = db.queryOne('SELECT COALESCE(SUM(amount), 0) as total, COALESCE(SUM(gst_amount), 0) as gst FROM sales_entries WHERE sale_date >= ? AND sale_date <= ?', [fromDate, toDate]);
    const salesPrev = db.queryOne('SELECT COALESCE(SUM(amount), 0) as total FROM sales_entries WHERE sale_date >= ? AND sale_date < ?', [prevFromDate, prevToDate]);
    const expensesCurrent = db.queryOne('SELECT COALESCE(SUM(net_amount), 0) as total, COALESCE(SUM(gst_amount), 0) as gst FROM expenses WHERE expense_date >= ? AND expense_date <= ?', [fromDate, toDate]);
    const expensesPrev = db.queryOne('SELECT COALESCE(SUM(net_amount), 0) as total FROM expenses WHERE expense_date >= ? AND expense_date < ?', [prevFromDate, prevToDate]);
    const pendingPayments = db.queryOne('SELECT COALESCE(SUM(balance_due), 0) as total, COUNT(*) as count FROM invoices WHERE payment_status IN ("PENDING", "PARTIAL")', []);
    const inventoryValue = db.queryOne('SELECT COALESCE(SUM(current_stock * purchase_price), 0) as total FROM inventory_items WHERE is_active = 1', []);
    
    const totalSales = salesCurrent.total;
    const totalExpenses = expensesCurrent.total;
    const netProfit = totalSales - totalExpenses;
    const prevProfit = salesPrev.total - expensesPrev.total;
    const growthRate = prevProfit !== 0 ? ((netProfit - prevProfit) / Math.abs(prevProfit)) * 100 : 0;

    // Monthly chart data (last 6 months)
    const monthlyData = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const mFrom = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-01`;
      const dEnd = new Date(d.getFullYear(), d.getMonth() + 1, 0);
      const mTo = `${dEnd.getFullYear()}-${String(dEnd.getMonth() + 1).padStart(2, '0')}-${String(dEnd.getDate()).padStart(2, '0')}`;
      const s = db.queryOne('SELECT COALESCE(SUM(amount), 0) as v FROM sales_entries WHERE sale_date >= ? AND sale_date <= ?', [mFrom, mTo]);
      const e = db.queryOne('SELECT COALESCE(SUM(net_amount), 0) as v FROM expenses WHERE expense_date >= ? AND expense_date <= ?', [mFrom, mTo]);
      monthlyData.push({
        month: d.toLocaleString('default', { month: 'short' }),
        sales: s.v,
        expenses: e.v,
        profit: s.v - e.v
      });
    }

    // Top customers
    const topCustomers = db.query(`SELECT customer_name, COALESCE(SUM(amount), 0) as total FROM sales_entries WHERE sale_date >= ? GROUP BY customer_name ORDER BY total DESC LIMIT 5`, [fromDate]);

    // Expense breakdown
    const expenseBreakdown = db.query(`SELECT category, COALESCE(SUM(net_amount), 0) as total FROM expenses WHERE expense_date >= ? AND expense_date <= ? GROUP BY category ORDER BY total DESC`, [fromDate, toDate]);

    // Recent invoices
    const recentInvoices = db.query('SELECT id, invoice_number, invoice_date, customer_name, grand_total, payment_status FROM invoices ORDER BY created_at DESC LIMIT 5');

    // Low stock alerts
    const lowStockCount = db.queryOne('SELECT COUNT(*) as count FROM inventory_items WHERE is_active = 1 AND current_stock <= reorder_point AND reorder_point > 0').count;

    return {
      totalSales, totalExpenses, netProfit,
      ebitda: netProfit * 1.15, // simplified EBITDA
      pendingAmount: pendingPayments.total,
      pendingCount: pendingPayments.count,
      inventoryValue: inventoryValue.total,
      salesGrowth: growthRate,
      taxCollected: salesCurrent.gst,
      taxPaid: expensesCurrent.gst,
      monthlyData, topCustomers, expenseBreakdown, recentInvoices,
      lowStockCount
    };
  });

  ipcMain.handle('reports:monthly', async (_, year) => {
    const y = year || new Date().getFullYear();
    const data = [];
    for (let m = 1; m <= 12; m++) {
      const mStr = String(m).padStart(2, '0');
      const from = `${y}-${mStr}-01`;
      const d = new Date(y, m, 0);
      const to = `${y}-${mStr}-${String(d.getDate()).padStart(2, '0')}`;
      const sales = db.queryOne('SELECT COALESCE(SUM(amount),0) as s, COALESCE(SUM(gst_amount),0) as g FROM sales_entries WHERE sale_date >= ? AND sale_date <= ?', [from, to]);
      const expenses = db.queryOne('SELECT COALESCE(SUM(net_amount),0) as e FROM expenses WHERE expense_date >= ? AND expense_date <= ?', [from, to]);
      data.push({ month: m, year: y, sales: sales.s, gst: sales.g, expenses: expenses.e, profit: sales.s - expenses.e });
    }
    return data;
  });

  ipcMain.handle('reports:profitLoss', async (_, period) => {
    const fy = period || `${new Date().getFullYear()}-${new Date().getFullYear() + 1}`;
    const [startY] = fy.split('-');
    const from = `${startY}-04-01`;
    const to = `${parseInt(startY) + 1}-03-31`;

    const sales = db.queryOne('SELECT COALESCE(SUM(amount),0) as total, COALESCE(SUM(gst_amount),0) as gst FROM sales_entries WHERE sale_date >= ? AND sale_date <= ?', [from, to]);
    const expenses = db.query('SELECT category, COALESCE(SUM(net_amount),0) as total FROM expenses WHERE expense_date >= ? AND expense_date <= ? GROUP BY category', [from, to]);
    const totalExpenses = expenses.reduce((s, e) => s + e.total, 0);
    const grossProfit = sales.total - totalExpenses * 0.6;
    const netProfit = sales.total - totalExpenses;
    return { period: fy, from, to, totalRevenue: sales.total, gstCollected: sales.gst, expenseBreakdown: expenses, totalExpenses, grossProfit, netProfit, ebitda: netProfit * 1.15 };
  });

  ipcMain.handle('reports:gst', async (_, period) => {
    const [from, to] = period || [new Date().toISOString().split('T')[0].slice(0, 8) + '01', new Date().toISOString().split('T')[0]];
    const outward = db.queryOne('SELECT COALESCE(SUM(cgst_amount),0) as cgst, COALESCE(SUM(sgst_amount),0) as sgst, COALESCE(SUM(igst_amount),0) as igst, COALESCE(SUM(total_tax),0) as total FROM invoices WHERE invoice_date >= ? AND invoice_date <= ? AND status != "DRAFT"', [from, to]);
    const inward = db.queryOne('SELECT COALESCE(SUM(gst_amount),0) as total FROM expenses WHERE expense_date >= ? AND expense_date <= ?', [from, to]);
    return { period: { from, to }, outward, inwardGST: inward.total, netGSTPayable: outward.total - inward.total };
  });

  ipcMain.handle('reports:balanceSheet', async () => {
    const inventoryValue = db.queryOne('SELECT COALESCE(SUM(current_stock * purchase_price),0) as v FROM inventory_items WHERE is_active = 1').v;
    const assetValue = db.queryOne('SELECT COALESCE(SUM(asset_value),0) as v FROM inventory_items WHERE is_asset = 1 AND is_active = 1').v;
    const receivables = db.queryOne('SELECT COALESCE(SUM(balance_due),0) as v FROM invoices WHERE payment_status IN ("PENDING","PARTIAL")').v;
    const totalRevenue = db.queryOne('SELECT COALESCE(SUM(amount),0) as v FROM sales_entries').v;
    const totalExpenses = db.queryOne('SELECT COALESCE(SUM(net_amount),0) as v FROM expenses').v;
    return {
      assets: { inventory: inventoryValue, fixedAssets: assetValue, receivables, cash: totalRevenue - totalExpenses },
      liabilities: { gstPayable: 0, otherPayables: 0 },
      equity: { retainedEarnings: totalRevenue - totalExpenses }
    };
  });
};

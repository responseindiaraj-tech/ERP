/**
 * BIC ERP — Standalone Database Initializer
 * Run once before first launch:  node scripts/init-db.js
 * Or use npm run db-init
 */

const path = require('path');
const fs   = require('fs');
const os   = require('os');

// Resolve DB path the same way Electron does (AppData\Roaming\bic-erp on Windows)
const DATA_DIR = path.join(os.homedir(), 'AppData', 'Roaming', 'bic-erp');
const DB_PATH  = path.join(DATA_DIR, 'bic-erp.db');

// Fallback for non-Windows dev machines
const DEV_DB   = path.join(__dirname, '..', 'data', 'bic-erp.db');
const FINAL_PATH = process.platform === 'win32' ? DB_PATH : DEV_DB;

let Database;
try {
  Database = require('better-sqlite3');
} catch (e) {
  console.error('\n❌  better-sqlite3 is not installed.');
  console.error('    Run:  npm install  then  npx electron-rebuild -f -w better-sqlite3\n');
  process.exit(1);
}

let bcrypt;
try {
  bcrypt = require('bcryptjs');
} catch (e) {
  console.error('\n❌  bcryptjs is not installed. Run: npm install\n');
  process.exit(1);
}

// ── Ensure directory exists ──────────────────────────────────────────────────
const dir = path.dirname(FINAL_PATH);
if (!fs.existsSync(dir)) {
  fs.mkdirSync(dir, { recursive: true });
  console.log('📁  Created directory:', dir);
}

// ── Open / create DB ─────────────────────────────────────────────────────────
const db = new Database(FINAL_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
console.log('🗄️   Database:', FINAL_PATH);

// ── Schema ───────────────────────────────────────────────────────────────────
db.exec(`
  CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY,
    company_name TEXT DEFAULT 'BIC Industries Private Limited',
    gstin TEXT, pan TEXT, address TEXT, city TEXT, state TEXT,
    state_code TEXT, pincode TEXT, phone TEXT, email TEXT, website TEXT,
    bank_name TEXT, account_number TEXT, ifsc_code TEXT, account_holder TEXT,
    logo_path TEXT, invoice_prefix TEXT DEFAULT 'BIC',
    invoice_counter INTEGER DEFAULT 1, financial_year TEXT DEFAULT '2024-25',
    theme TEXT DEFAULT 'dark',
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
    full_name TEXT, role TEXT DEFAULT 'admin', email TEXT,
    is_active INTEGER DEFAULT 1, last_login TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL, company_name TEXT, gstin TEXT, pan TEXT,
    mobile TEXT, alternate_mobile TEXT, email TEXT,
    address_line1 TEXT, address_line2 TEXT, city TEXT, state TEXT,
    state_code TEXT, pincode TEXT, customer_type TEXT DEFAULT 'B2B',
    credit_limit REAL DEFAULT 0, outstanding_amount REAL DEFAULT 0,
    notes TEXT, is_active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS invoices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_number TEXT UNIQUE NOT NULL, invoice_date TEXT NOT NULL,
    due_date TEXT, customer_id INTEGER REFERENCES customers(id),
    customer_name TEXT, customer_gstin TEXT, billing_address TEXT,
    shipping_address TEXT, place_of_supply TEXT,
    invoice_type TEXT DEFAULT 'TAX_INVOICE',
    supply_type TEXT DEFAULT 'B2B',
    subtotal REAL DEFAULT 0, cgst_amount REAL DEFAULT 0,
    sgst_amount REAL DEFAULT 0, igst_amount REAL DEFAULT 0,
    total_tax REAL DEFAULT 0, discount_amount REAL DEFAULT 0,
    round_off REAL DEFAULT 0, grand_total REAL DEFAULT 0,
    amount_paid REAL DEFAULT 0, balance_due REAL DEFAULT 0,
    payment_mode TEXT DEFAULT 'CASH',
    payment_status TEXT DEFAULT 'PENDING',
    transport_name TEXT, vehicle_number TEXT, lr_number TEXT,
    eway_bill TEXT, delivery_date TEXT, notes TEXT,
    terms_conditions TEXT, status TEXT DEFAULT 'DRAFT',
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS invoice_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER REFERENCES invoices(id) ON DELETE CASCADE,
    item_name TEXT NOT NULL, description TEXT, hsn_sac TEXT,
    quantity REAL NOT NULL, unit TEXT DEFAULT 'NOS', rate REAL NOT NULL,
    discount_percent REAL DEFAULT 0, discount_amount REAL DEFAULT 0,
    taxable_amount REAL NOT NULL, gst_rate REAL DEFAULT 18,
    cgst_rate REAL DEFAULT 9, sgst_rate REAL DEFAULT 9,
    igst_rate REAL DEFAULT 0, cgst_amount REAL DEFAULT 0,
    sgst_amount REAL DEFAULT 0, igst_amount REAL DEFAULT 0,
    total_amount REAL NOT NULL, sort_order INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS inventory_categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL, description TEXT, icon TEXT, color TEXT,
    parent_id INTEGER REFERENCES inventory_categories(id),
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS inventory_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sku TEXT UNIQUE, name TEXT NOT NULL, description TEXT,
    category_id INTEGER REFERENCES inventory_categories(id),
    item_type TEXT DEFAULT 'STOCK', unit TEXT DEFAULT 'NOS',
    current_stock REAL DEFAULT 0, min_stock_level REAL DEFAULT 0,
    max_stock_level REAL DEFAULT 0, reorder_point REAL DEFAULT 0,
    purchase_price REAL DEFAULT 0, selling_price REAL DEFAULT 0,
    hsn_sac TEXT, gst_rate REAL DEFAULT 18, location TEXT,
    barcode TEXT, serial_number TEXT, asset_value REAL DEFAULT 0,
    is_asset INTEGER DEFAULT 0, notes TEXT, is_active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS stock_movements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id INTEGER REFERENCES inventory_items(id),
    movement_type TEXT NOT NULL, quantity REAL NOT NULL,
    unit_price REAL DEFAULT 0, total_value REAL DEFAULT 0,
    reference_type TEXT, reference_id INTEGER, reference_number TEXT,
    vendor_name TEXT, notes TEXT,
    movement_date TEXT DEFAULT (datetime('now')),
    created_by INTEGER REFERENCES users(id),
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS vendors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL, company_name TEXT, gstin TEXT, pan TEXT,
    mobile TEXT, email TEXT, address TEXT, city TEXT, state TEXT,
    pincode TEXT, bank_name TEXT, account_number TEXT, ifsc_code TEXT,
    credit_period INTEGER DEFAULT 30, notes TEXT, is_active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    expense_date TEXT NOT NULL, expense_number TEXT, category TEXT NOT NULL,
    sub_category TEXT, description TEXT,
    vendor_id INTEGER REFERENCES vendors(id), vendor_name TEXT,
    vendor_invoice_number TEXT, amount REAL NOT NULL,
    gst_amount REAL DEFAULT 0, tds_amount REAL DEFAULT 0,
    net_amount REAL NOT NULL, payment_mode TEXT DEFAULT 'CASH',
    payment_status TEXT DEFAULT 'PAID', bill_image_path TEXT, notes TEXT,
    financial_year TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS sales_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sale_date TEXT NOT NULL, customer_id INTEGER REFERENCES customers(id),
    customer_name TEXT, invoice_id INTEGER REFERENCES invoices(id),
    description TEXT, amount REAL NOT NULL, gst_amount REAL DEFAULT 0,
    payment_mode TEXT DEFAULT 'CASH',
    payment_status TEXT DEFAULT 'RECEIVED',
    notes TEXT, financial_year TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_invoices_date    ON invoices(invoice_date);
  CREATE INDEX IF NOT EXISTS idx_invoices_customer ON invoices(customer_id);
  CREATE INDEX IF NOT EXISTS idx_invoices_status  ON invoices(payment_status);
  CREATE INDEX IF NOT EXISTS idx_expenses_date    ON expenses(expense_date);
  CREATE INDEX IF NOT EXISTS idx_inventory_cat    ON inventory_items(category_id);
  CREATE INDEX IF NOT EXISTS idx_stock_item       ON stock_movements(item_id);
`);

// ── Seed default settings ─────────────────────────────────────────────────────
db.prepare(`
  INSERT OR IGNORE INTO settings (
    id, company_name, gstin, pan, address, city, state, state_code,
    pincode, phone, email, website, bank_name, account_number,
    ifsc_code, account_holder, invoice_prefix, financial_year
  ) VALUES (
    1,
    'BIC Industries Private Limited',
    '19AABCB1234A1Z5', 'AABCB1234A',
    '123, Industrial Area, Block A', 'Durgapur', 'West Bengal', '19',
    '713201', '+91 9999999999', 'info@bicindustries.com',
    'www.bicindustries.com', 'State Bank of India', '12345678901',
    'SBIN0001234', 'BIC Industries Private Limited', 'BIC', '2024-25'
  )
`).run();

// ── Seed inventory categories ─────────────────────────────────────────────────
const cats = [
  [1, 'Printing Materials',  'Papers, sheets and printing supplies', 'printer',    '#3b82f6'],
  [2, 'Ink & Consumables',   'Inks, toners and consumables',         'droplet',    '#8b5cf6'],
  [3, 'Packaging',           'Packaging materials and supplies',     'package',    '#f59e0b'],
  [4, 'Camera Equipment',    'Cameras, lenses and accessories',      'camera',     '#10b981'],
  [5, 'Lighting Equipment',  'Lights, stands and accessories',       'sun',        '#f97316'],
  [6, 'Storage Media',       'Hard disks, memory cards and storage', 'hard-drive', '#06b6d4'],
  [7, 'Other Assets',        'Miscellaneous business assets',        'box',        '#6b7280'],
];
const catStmt = db.prepare(
  `INSERT OR IGNORE INTO inventory_categories (id, name, description, icon, color)
   VALUES (?, ?, ?, ?, ?)`
);
cats.forEach(c => catStmt.run(...c));

// ── Seed sample inventory items ───────────────────────────────────────────────
const invItems = [
  ['PM-001','A4 Photo Paper 260gsm',1,'PKT',45,10,0,850,1200,'4802',12,0],
  ['PM-002','Album Sheets A3 (Pack of 50)',1,'PKT',8,15,0,1200,1800,'4802',12,0],
  ['INK-001','Canon Pro Ink Set (6 Colors)',2,'SET',12,5,0,3500,4800,'3215',18,0],
  ['PKG-001','Photo Frame Box (10x12")',3,'NOS',3,20,0,85,120,'4819',12,0],
  ['CAM-001','Canon EOS R6 Mark II',4,'NOS',2,1,245000,245000,0,'8525',18,1],
  ['CAM-002','Canon RF 24-70mm f/2.8L Lens',4,'NOS',3,1,165000,165000,0,'9002',18,1],
  ['LGT-001','Godox SL200W LED Light',5,'NOS',4,2,18500,18500,0,'9405',18,1],
  ['STR-001','WD 4TB External Hard Disk',6,'NOS',6,3,0,8500,9800,'8471',18,0],
  ['STR-002','SanDisk 128GB V60 Memory Card',6,'NOS',15,5,0,2800,3500,'8523',18,0],
];
const invStmt = db.prepare(`
  INSERT OR IGNORE INTO inventory_items
    (sku, name, category_id, unit, current_stock, reorder_point,
     asset_value, purchase_price, selling_price, hsn_sac, gst_rate, is_asset)
  VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
`);
invItems.forEach(i => invStmt.run(...i));

// ── Admin user ────────────────────────────────────────────────────────────────
const adminExists = db.prepare('SELECT id FROM users WHERE username = ?').get('admin');
if (!adminExists) {
  const hash = bcrypt.hashSync('admin123', 10);
  db.prepare(
    `INSERT INTO users (username, password_hash, full_name, role)
     VALUES ('admin', ?, 'Administrator', 'admin')`
  ).run(hash);
  console.log('👤  Default admin created  (username: admin  |  password: admin123)');
} else {
  console.log('👤  Admin user already exists — skipped');
}

db.close();

console.log('\n✅  BIC ERP database initialised successfully!');
console.log('   Run  npm start  to launch the application.\n');

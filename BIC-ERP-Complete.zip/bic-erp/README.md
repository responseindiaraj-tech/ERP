# BIC ERP — Setup Guide
## BIC Industries Private Limited | Durgapur, West Bengal

---

## ✅ Prerequisites

- **Node.js** v18 or higher → https://nodejs.org
- **npm** v8+ (comes with Node.js)
- **Windows 10/11** (64-bit)
- **Git** (optional)

---

## 🚀 Installation — Step by Step

### Step 1 — Copy project files
Place the entire `bic-erp` folder anywhere on your computer (e.g. `C:\BIC-ERP\`).

### Step 2 — Open terminal in the project folder
```
Right-click inside the folder → "Open in Terminal"
```

### Step 3 — Install dependencies
```bash
npm install
```
This installs all packages including Electron, React, SQLite, jsPDF, Tesseract.js (~5–10 min first time).

### Step 4 — Fix native modules for Electron (required for SQLite)
```bash
npm install --save-dev electron-rebuild
npx electron-rebuild -f -w better-sqlite3
```

### Step 5 — Start in Development Mode
```bash
npm start
```
This launches the React dev server on port 3000, then opens the Electron window.

---

## 🏗️ Build Windows Installer (.exe)

```bash
npm run build
```
This creates a distributable installer in the `dist/` folder:
`dist/BIC ERP Setup 1.0.0.exe`

---

## 🔑 Default Login Credentials

| Field    | Value      |
|----------|------------|
| Username | `admin`    |
| Password | `admin123` |

**Change the password immediately** after first login via Settings → Account.

---

## 📁 Project Structure

```
bic-erp/
├── src/
│   ├── main/                    # Electron main process
│   │   ├── main.js              # App entry, window creation
│   │   ├── preload.js           # Secure IPC bridge
│   │   └── handlers/            # IPC handlers (one per module)
│   │       ├── authHandlers.js
│   │       ├── invoiceHandlers.js
│   │       ├── customerHandlers.js
│   │       ├── inventoryHandlers.js
│   │       ├── salesHandlers.js
│   │       ├── reportHandlers.js
│   │       └── ocrHandlers.js
│   ├── database/
│   │   └── db.js                # SQLite schema + helpers
│   └── renderer/                # React frontend
│       ├── App.js               # Router + Context
│       ├── index.js             # React entry point
│       ├── index.css            # Tailwind + global styles
│       ├── pages/
│       │   ├── LoginPage.js
│       │   ├── Dashboard.js     # KPI cards + charts
│       │   ├── Invoices.js      # GST invoice CRUD + PDF
│       │   ├── Customers.js     # Customer database
│       │   ├── Inventory.js     # Stock + asset tracking
│       │   ├── SalesExpenses.js # Sales/expense tracker + OCR
│       │   ├── Accounting.js    # P&L, Balance Sheet, GST
│       │   └── Settings.js      # Company config
│       ├── components/
│       │   └── Shared/
│       │       └── MainLayout.js  # Sidebar + titlebar
│       └── utils/
│           └── pdfGenerator.js    # jsPDF invoice generator
├── public/
│   └── index.html
├── package.json
├── tailwind.config.js
└── postcss.config.js
```

---

## 🗄️ Database

- Auto-created on first launch at:
  `C:\Users\<YourName>\AppData\Roaming\bic-erp\bic-erp.db`
- All data stored **locally** — no internet required
- Use [DB Browser for SQLite](https://sqlitebrowser.org/) to inspect/backup

### Backup your database
```
Copy: C:\Users\<Name>\AppData\Roaming\bic-erp\bic-erp.db
To:   D:\Backups\bic-erp-backup-YYYYMMDD.db
```

---

## 🧾 GST Invoice Features

- **CGST + SGST** for intrastate (West Bengal → West Bengal)
- **IGST** for interstate supplies
- HSN/SAC codes per line item
- Auto invoice number: `BIC/2024-25/0001`
- E-Way Bill field
- Transport / Vehicle / LR number
- jsPDF export with Indian format layout
- Amount in words (Rupees)
- Company logo, GSTIN, bank details on PDF

---

## 📊 Financial Year

Default FY is **2024-25** (April 2024 – March 2025).
Change in **Settings → Invoice → Financial Year** each April.
Invoice counter resets with the new prefix.

---

## 🔍 OCR — Invoice Scanning

1. Go to **Sales & Expenses → Add Expense**
2. Click "Upload Bill / Invoice for Auto-Fill (OCR)"
3. Upload JPG, PNG, or PDF of vendor bill
4. Tesseract.js reads: vendor name, GSTIN, amount, date
5. Fields auto-populate — review and save

---

## 🛠️ Troubleshooting

### "better-sqlite3 not found" error
```bash
npm install better-sqlite3
npx electron-rebuild -f -w better-sqlite3
```

### App window is blank / white
```bash
# Make sure React dev server is running first:
npm run react-start
# Then in a second terminal:
npm run electron-dev
```

### Port 3000 already in use
```bash
# Kill the process using port 3000, then restart
npx kill-port 3000
npm start
```

### PDF not generating
- Ensure `jspdf` and `jspdf-autotable` are installed
- Check browser console (F12) for errors

---

## 📦 Key Dependencies

| Package | Purpose |
|---------|---------|
| `electron` | Windows desktop shell |
| `react` + `react-dom` | UI framework |
| `better-sqlite3` | Local database |
| `bcryptjs` | Password hashing |
| `jspdf` + `jspdf-autotable` | PDF generation |
| `tesseract.js` | OCR for bill scanning |
| `recharts` | Dashboard charts |
| `react-router-dom` | Page routing |
| `tailwindcss` | Styling |
| `uuid` | Unique IDs |

---

## 🔒 Security

- Passwords are **bcrypt hashed** (salt rounds: 10)
- `contextIsolation: true` + `nodeIntegration: false` in Electron
- All IPC calls go through typed preload bridge
- Database stored in OS user profile (not world-readable)

---

## 📞 Support

**BIC Industries Private Limited**
Durgapur, West Bengal — 713201
